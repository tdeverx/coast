import {getDb,getSql,closeDb} from '../../../../../src/lib/server/db';
import {changeContinue} from '../../../../../src/lib/core/tracking/continue.server';
import {setUpNext} from '../../../../../src/lib/core/lists/up-next.server';
import * as s from '../../../../../src/lib/server/db/schema';
import {sql as q} from 'drizzle-orm';
import {PgDialect} from 'drizzle-orm/pg-core';
import {createHash} from 'node:crypto';
const url=new URL(process.env.DATABASE_URL!),runId=process.env.COAST_AVATAR_RUN_ID!;
if(process.env.COAST_AUDIT_MATCHED_AVATAR_COPY!=='1'||url.hostname!=='127.0.0.1'||url.port!=='55432'||!/^\/coast_audit_fix_actual_[a-f0-9]{32}$/.test(url.pathname))throw Error('Owned actual copy required');
const db=getDb(),sql=getSql(),original=db.transaction.bind(db),dialect=new PgDialect();const result:any={runId,status:'running',boundary:'Bounded controlled admin queue schedules on owned disposable actual-data copy; actual admin/catalogue, native commands, no providers.',checks:{},comparisons:[],externalCalls:0};
const check=(v:any,k:string)=>{result.checks[k]=!!v;if(!v)throw Error(k)};
const hash=(v:string)=>createHash('sha256').update(v).digest('hex');
const source=await Bun.file(new URL('../found-implementation-02/queue-consumption/continue.before.ts.txt',import.meta.url)).text(),base=new URL('../../../../../src/lib/core/tracking/continue.server.ts',import.meta.url);
const code=new Bun.Transpiler({loader:'ts'}).transformSync(source).replace(/from\s*(['"])([^'"]+)\1/g,(_m,_quote,p)=>`from ${JSON.stringify(p.startsWith('.')?new URL(p,base).pathname:p.startsWith('$lib/')?new URL('../../../../../src/lib/'+p.slice(5),import.meta.url).pathname:import.meta.resolve(p))}`);
const modulePath=process.env.COAST_DATA_DIR!+'/continue-concurrency-default.js';await Bun.write(modulePath,code);const prior=await import(modulePath);
result.sourceHashes={default:hash(source),current:hash(await Bun.file(base).text()),queue:hash(await Bun.file(new URL('../../../../../src/lib/core/lists/up-next.server.ts',import.meta.url)).text())};
const oldFetch=globalThis.fetch;globalThis.fetch=(async()=>{result.externalCalls++;throw Error('external forbidden')})as any;
function latch(){let release!:()=>void;return{promise:new Promise<void>(r=>release=r),release}}
try{
 const [marker]=await sql`select shobj_description(oid,'pg_database') as marker from pg_database where datname=current_database()`;check(marker.marker==='coast-avatar-copy:'+runId,'exact-copy-run-marker');
 const [admin]=await sql`select id from users where username='admin' and role='admin' and not disabled and coast_feature_enabled(id,'screen')`;check(admin,'real-admin');
 const media=await sql`select m.id from media m where m.kind='movie' and not exists(select 1 from tracking_events e where e.user_id=${admin.id} and e.media_id=m.id) and not exists(select 1 from tracking_state t where t.user_id=${admin.id} and t.media_id=m.id) order by m.id limit 2`;check(media.length===2,'two-real-untracked-movies');const target=media[0].id,other=media[1].id;
 const queue=()=>sql`select media_id,created_at from up_next where user_id=${admin.id} order by created_at,media_id`;
 for(const schedule of ['dequeue-after-snapshot','enqueue-after-snapshot','enqueue-during-undo-admission']){
  const pair:any[]=[];
  for(const version of ['default','current']){
   await sql`delete from up_next where user_id=${admin.id}`;await sql`delete from tracking_events where user_id=${admin.id} and media_id=${target}`;await sql`delete from tracking_state where user_id=${admin.id} and media_id=${target}`;
   await sql`insert into up_next(user_id,media_id,created_at) values(${admin.id},${other},'2026-01-01T00:00:00Z')`;
   if(schedule!=='enqueue-after-snapshot')await sql`insert into up_next(user_id,media_id,created_at) values(${admin.id},${target},'2026-01-02T00:00:00Z')`;
   const before=await queue(),owner=version==='default'?prior.changeContinue:changeContinue;let phase='remove',paused=false;const entered=latch(),release=latch();let ownerPid=0,competitorPid=0;
   (db as any).transaction=(fn:any)=>original(async tx=>{
    await tx.execute(q`set local statement_timeout='15s'`);await tx.execute(q`set local lock_timeout='3s'`);
    const pid=(await tx.execute<any>(q`select pg_backend_pid() as pid`))[0].pid;
    const isOwner=!paused;if(isOwner)ownerPid=pid;else competitorPid=pid;
    if(isOwner&&schedule!=='enqueue-during-undo-admission'){
     const select=tx.select.bind(tx);(tx as any).select=(...args:any[])=>{const b=select(...args),from=b.from.bind(b);b.from=(table:any)=>{const builder=from(table);if(table!==s.upNext)return builder;const where=builder.where.bind(builder);builder.where=(cond:any)=>{const query=where(cond),then=query.then.bind(query);query.then=(ok:any,bad:any)=>then(async(rows:any)=>{paused=true;entered.release();await release.promise;return ok?ok(rows):rows},bad);return query};return builder};return b};
    }
    if(isOwner&&schedule==='enqueue-during-undo-admission'&&phase==='undo'){
     const execute=tx.execute.bind(tx);(tx as any).execute=async(query:any)=>{const text=dialect.sqlToQuery(query).sql,answer=await execute(query);if(text.includes('pg_advisory_xact_lock(hashtextextended(')){paused=true;entered.release();await release.promise;}return answer};
    }
    return fn(tx);
   });
   let removed:any;
   if(schedule==='enqueue-during-undo-admission'){
    removed=await owner(admin.id,{mediaId:target,action:'remove'});phase='undo';paused=false;
   }
   const pending=owner(admin.id,schedule==='enqueue-during-undo-admission'?{mediaId:target,action:'undo',eventId:removed.eventId,previous:removed.previous}:{mediaId:target,action:'remove'});
   const deadline=setTimeout(()=>release.release(),6000);await entered.promise;
   const competingStart=performance.now();await setUpNext(admin.id,{mediaId:target,queued:schedule!=='dequeue-after-snapshot'});const competitorMs=performance.now()-competingStart;
   const during=await queue();const [locks]=await sql`select ${ownerPid}=any(pg_blocking_pids(${competitorPid})) as owner_blocks_competitor,${competitorPid}=any(pg_blocking_pids(${ownerPid})) as competitor_blocks_owner`;
   check(ownerPid!==competitorPid,schedule+version+'-distinct-native-sessions');check(!locks.owner_blocks_competitor&&!locks.competitor_blocks_owner,schedule+version+'-competitor-committed-before-owner-release');
   release.release();clearTimeout(deadline);const native=await pending;if(schedule!=='enqueue-during-undo-admission')removed=native;
   (db as any).transaction=original;
   const after=await queue();if(schedule!=='enqueue-during-undo-admission')await owner(admin.id,{mediaId:target,action:'undo',eventId:removed.eventId,previous:removed.previous});const final=await queue();
   const [events]=await sql`select count(*)::int as count,array_agg(action order by occurred_at,id) as actions from tracking_events where user_id=${admin.id} and media_id=${target}`;
   check(final.some(r=>r.media_id===other&&r.created_at.toISOString()==='2026-01-01T00:00:00.000Z'),schedule+version+'-nonmatching-order-timestamp-preserved');
   if(schedule!=='enqueue-during-undo-admission'){check(removed.previous.queued.length===0,schedule+version+'-exact-removed-id-intersection');check(!final.some(r=>r.media_id===target),schedule+version+'-undo-does-not-invent-snapshot-row')}
   else{check(final.find(r=>r.media_id===target)?.created_at.getTime()===during.find(r=>r.media_id===target)?.created_at.getTime(),schedule+version+'-undo-conflict-preserves-concurrent-enqueue-timestamp');check(removed.previous.queued.length===1,schedule+version+'-original-removal-snapshot')}
   pair.push({version,competitorMs,concurrentCommitBeforeRelease:true,snapshotQueueCount:removed.previous.queued.length,beforeQueue:before.map(r=>({target:r.media_id===target,at:r.created_at.toISOString()})),duringQueue:during.map(r=>({target:r.media_id===target,at:r.created_at.toISOString()})),afterRemoveOrUndoQueue:after.map(r=>({target:r.media_id===target,at:r.created_at.toISOString()})),finalQueue:final.map(r=>({target:r.media_id===target,at:r.created_at.toISOString()})),events});
  }
  const normalize=(v:any)=>JSON.stringify({...v,version:undefined,competitorMs:undefined,duringQueue:v.duringQueue.map((r:any)=>({...r,at:r.target&&r.at!=='2026-01-02T00:00:00.000Z'?'concurrent-native-enqueue-time':r.at})),afterRemoveOrUndoQueue:v.afterRemoveOrUndoQueue.map((r:any)=>({...r,at:r.target?'concurrent-native-enqueue-time':r.at})),finalQueue:v.finalQueue.map((r:any)=>({...r,at:r.target?'concurrent-native-enqueue-time':r.at}))});check(normalize(pair[0])===normalize(pair[1]),schedule+'-native-default-current-equal');result.comparisons.push({schedule,default:pair[0],current:pair[1]});
 }
 check(result.externalCalls===0,'zero-providers');result.status='passed';
}catch(e:any){result.status='failed';result.failure={message:String(e.message).split('\nparams:')[0],cause:e.cause?.message,code:e.cause?.code??e.code};process.exitCode=1}
finally{(db as any).transaction=original;globalThis.fetch=oldFetch;await Bun.write(process.argv[2],JSON.stringify(result,null,2));await closeDb()}
