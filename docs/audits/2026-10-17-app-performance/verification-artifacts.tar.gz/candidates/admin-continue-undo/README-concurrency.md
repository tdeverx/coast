# MIN-06 bounded native queue concurrency

Three DEFAULT/CURRENT schedule pairs passed all 37 checks on a run-tagged owned disposable copy of the original actual-data clone. The native actor is the actual admin and the two movies are actual catalogue rows without prior admin tracking. The copy was marker-verified, dropped and confirmed absent. No original database or application source was mutated; providers were disabled. Existing 78-check proof files remain unchanged.

The competing native enqueue/dequeue command completed in a distinct database session before the paused Continue transaction was released. Continue's existing user advisory lock therefore does **not** serialize these queue commands; this was observed rather than assumed.

- Dequeue after snapshot: final actual removed-ID intersection excludes the target that the competitor already deleted. Undo does not resurrect it.
- Enqueue after snapshot: native tracking consumes the newly queued target that was absent from the snapshot. Undo does not invent a snapshot row. This is the same DEFAULT behavior.
- Enqueue during Undo admission: native conflict handling preserves the concurrently inserted timestamp. The unrelated queue row retains exact order and original timestamp.

Each schedule emits exactly drop then restore events. All full normalized results match DEFAULT/CURRENT. Dynamic native enqueue timestamps are normalized only between variants; exact timestamp preservation is independently asserted inside each run.

This finite result closes the requested concurrent-queue acceptance for these schedules, without implying exhaustive races, all media shapes or performance results. `actual-concurrency.json` records the comparisons and owned-copy cleanup; `summary-concurrency.json` records counts, source and artifact hashes. `probe-concurrency.ts`, `wrapper-concurrency.ts` and `run-concurrency.py` are the executed owned runners.
