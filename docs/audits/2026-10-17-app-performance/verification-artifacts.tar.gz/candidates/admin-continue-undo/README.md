# MIN-06 controlled admin native verification

Four archived DEFAULT/CURRENT pairs passed all 78 checks on the original private real-data clone, using the existing admin actor and real movie/show/episode/season identities. Queue entries and one rewatch boundary were controlled temporary rows; this is not naturally observed queue workload. Each native lifecycle and its setup rolled back. No application/runtime source changed.

Each lifecycle calls native Remove twice, Undo the original snapshot, then rejects an Undo with a nonmatching event ID (409). Full returned snapshots, final projection fields, event deltas, queue contents/order/original timestamps, rewatch restoration, content revisions after deferred trigger execution, statement counts and lock ordering compare exactly. A repeated Remove adds no event and snapshots no queue entries; nonmatching queue rows survive.

Across both Removes per case, snapshot driver rows fall 1,026 → 4 and serialized snapshot JSON bytes 139,544 → 556. Instrumented statement count remains 276 → 276, including four harness SET CONSTRAINTS statements per variant; native lifecycle statements remain 272 → 272. This proves bounded row transfer for the chosen real catalogue queue scenarios. It does not establish database CPU, memory, WAL, broad recursive parent membership, concurrent scheduling, permissions or production latency improvements. Fixed-order elapsed samples include slower CURRENT season/show cases and remain descriptive.

DEFAULT is the exact archived `found-implementation-02/queue-consumption/continue.before.ts.txt`; source hashes, probe/result hashes and finite counts are in `summary.json`. `actual.json` retains complete comparisons. `first-stop.json` retains a pre-native setup-column typo and its single direct correction. A cause-capture replay repeated the same pre-native failure. No alternative optimization was investigated.

Account queue/state/events/rewatches and all revision rows match their pre-probe census after rollback. The combined all-table fingerprint and broader acceptance remain the parent gate.
