import {getDb,getSql,closeDb} from '../../../../../src/lib/server/db';
import {changeContinue} from '../../../../../src/lib/core/tracking/continue.server';
import * as schema from '../../../../../src/lib/server/db/schema';
import {sql as q} from 'drizzle-orm';
import {createHash} from 'node:crypto';
const url=new URL(process.env.DATABASE_URL!);if(process.env.COAST_AUDIT_REAL_DATA_CLONE!=='1'||url.hostname!=='127.0.0.1'||url.port!=='55432'||!url.pathname.startsWith('/coast_audit_fix_actual_'))throw Error('Private actual clone required');
const db=getDb(),sql=getSql(),original=db.transaction.bind(db),rollback=Symbol('rollback');
const result:any={boundary:'Controlled temporary admin queue/tracking states over existing real catalogue, each transaction rolled back; not naturally observed queue workload.',checks:{},comparisons:[],externalCalls:0};
const check=(v:any,k:string)=>{result.checks[k]=!!v;if(!v)throw Error(k)};
const hash=(v:any)=>createHash('sha256').update(typeof v==='string'?v:JSON.stringify(v)).digest('hex');
const source=await Bun.file(new URL('../../../../../src/lib/core/tracking/continue.server.ts',import.meta.url)).text();
// Isolate MIN-06: original full-user snapshot versus current canonical predicate; shared current locks and tracking owner in both.
const baseline=await Bun.file(new URL('../found-implementation-02/queue-consumption/continue.before.ts.txt',import.meta.url)).text();check(baseline!==source,'isolated-default-source');
result.sourceHashes={current:hash(source),default:hash(baseline),service:hash(await Bun.file(new URL('../../../../../src/lib/core/tracking/service.server.ts',import.meta.url)).text())};
const base=new URL('../../../../../src/lib/core/tracking/continue.server.ts',import.meta.url);
const code=new Bun.Transpiler({loader:'ts'}).transformSync(baseline).replace(/from\s*(['"])([^'"]+)\1/g,(_m,_quote,p)=>`from ${JSON.stringify(p.startsWith('.')?new URL(p,base).pathname:p.startsWith('$lib/')?new URL('../../../../../src/lib/'+p.slice(5),import.meta.url).pathname:import.meta.resolve(p))}`);
const modulePath=process.env.COAST_DATA_DIR!+'/continue-default.js';await Bun.write(modulePath,code);const prior=await import(modulePath);
await Bun.write(new URL('./continue.default.ts.txt',import.meta.url),baseline);
const fetchOriginal=globalThis.fetch;globalThis.fetch=(async()=>{result.externalCalls++;throw Error('External forbidden')}) as any;
try{
 const [admin]=await sql`select id from users where role='admin' and username='admin' and not disabled and coast_feature_enabled(id,'screen')`;check(admin,'actual-admin-enabled');
 const works=await sql`select distinct on (m.kind) m.id,m.kind from media m where m.kind in ('movie','show','episode','season') and (m.kind<>'episode' or exists(select 1 from episodes e where e.media_id=m.id)) and (m.kind<>'season' or exists(select 1 from seasons s where s.media_id=m.id)) order by m.kind,m.id`;
 check(works.length===4,'four-real-media-kinds');
 const queue=await sql`select id from media where kind='movie' order by id limit 128`;check(queue.length>=32,'real-nonmatching-catalogue');
 async function census(tx:any){return (await tx.execute(q`select jsonb_build_object('queue',(select coalesce(jsonb_agg((to_jsonb(t)-'user_id') order by media_id),'[]') from up_next t where user_id=${admin.id}),'state',(select coalesce(jsonb_agg(to_jsonb(t) order by media_id),'[]') from tracking_state t where user_id=${admin.id}),'rewatches',(select coalesce(jsonb_agg(to_jsonb(t) order by media_id),'[]') from rewatches t where user_id=${admin.id}),'events',(select count(*) from tracking_events where user_id=${admin.id}),'revisions',(select coalesce(jsonb_agg(to_jsonb(t) order by scope,domain),'[]') from content_revisions t)) as value`))[0].value}
 const initial=await original(census);
 for(const work of works){
  const outcomes:any[]=[];
  for(const version of ['default','current']){
   let output:any;let active:any;
   (db as any).transaction=(fn:any)=>{if(active)return fn(active);return original(async tx=>{
    active=tx;await tx.execute(q`set local statement_timeout='20s'`);await tx.execute(q`set local lock_timeout='3s'`);
    // Controlled states only; source data never committed or fabricated.
    await tx.execute(q`delete from up_next where user_id=${admin.id}`);
    await tx.execute(q`delete from rewatches where user_id=${admin.id}`);
    const canonical=work.kind==='episode'?(await tx.execute<any>(q`select show_id as id from episodes where media_id=${work.id}`))[0].id:work.kind==='season'?(await tx.execute<any>(q`select show_id as id from seasons where media_id=${work.id}`))[0].id:work.id;
    await tx.execute(q`delete from tracking_state where user_id=${admin.id} and media_id=${canonical}`);
    await tx.execute(q`insert into up_next(user_id,media_id,created_at) select ${admin.id}::uuid,id,'2026-01-01T00:00:00Z'::timestamptz + row_number() over(order by id)*interval '1 second' from media where id in (${q.join([...queue.map(r=>q`${r.id}::uuid`),q`${canonical}::uuid`],q`,`)})`);
    await tx.execute(q`insert into rewatches(user_id,media_id,started_at) values(${admin.id},${canonical},'2026-01-01T00:00:00Z')`);
    const before=await census(tx);let snapshotRows=0,snapshotBytes=0;
    const select=tx.select.bind(tx);(tx as any).select=(...args:any[])=>{const b=select(...args);const from=b.from.bind(b);b.from=(table:any)=>{const builder=from(table);if(table!==schema.upNext)return builder;const where=builder.where.bind(builder);builder.where=(condition:any)=>{const query=where(condition);const then=query.then.bind(query);query.then=(ok:any,bad:any)=>then((rows:any)=>{snapshotRows+=rows.length;snapshotBytes+=JSON.stringify(rows).length;return ok?ok(rows):rows},bad);return query};return builder};return b};
    const owner=version==='default'?prior.changeContinue:changeContinue;
    const statements:string[]=[];(tx as any).session.logger={logQuery:(text:string)=>statements.push(text)};
    const start=performance.now();const removed:any=await owner(admin.id,{mediaId:work.id,action:'remove'});const afterRemove=await census(tx);await Bun.sleep(3);
    const repeated:any=await owner(admin.id,{mediaId:work.id,action:'remove'});const afterRepeat=await census(tx);
    await owner(admin.id,{mediaId:work.id,action:'undo',eventId:removed.eventId,previous:removed.previous});
    const firstUndo=await census(tx);check(JSON.stringify(firstUndo.queue)===JSON.stringify(before.queue),work.kind+version+'-first-undo-queue-restored');check(firstUndo.rewatches.length===before.rewatches.length,work.kind+version+'-rewatch-restored');check(afterRemove.rewatches.length===0,work.kind+version+'-rewatch-removed');
    let staleUndoStatus=0;try{await owner(admin.id,{mediaId:work.id,action:'undo',eventId:crypto.randomUUID(),previous:removed.previous})}catch(e:any){staleUndoStatus=e.status??e.statusCode??0}
    await tx.execute(q`set constraints all immediate`);
    const final=await census(tx);check(JSON.stringify(final.queue)===JSON.stringify(before.queue),work.kind+version+'-queue-order-timestamps-restored');check(staleUndoStatus===409,work.kind+version+'-stale-undo-rejected');
    output={kind:work.kind,version,canonicalTarget:removed.mediaId===canonical,snapshotRows,snapshotBytes,nativeStatementCount:statements.filter(t=>!t.includes('jsonb_build_object')).length,lockOrder:statements.filter(t=>t.includes('coast_lock_feature_policy')||t.includes('pg_advisory_xact_lock(hashtextextended')).map(t=>t.includes('coast_lock_feature_policy')?'feature-policy':'user-advisory'),elapsedMs:performance.now()-start,removedQueue:removed.previous.queued,repeatQueue:repeated.previous.queued,beforeQueue:before.queue,afterRemoveQueue:afterRemove.queue,afterRepeatQueue:afterRepeat.queue,finalQueue:final.queue,eventDelta:afterRemove.events-before.events,repeatEventDelta:afterRepeat.events-afterRemove.events,staleUndoStatus,previousDropped:removed.previous.dropped,revisionRows:final.revisions,finalState:final.state.map(({updated_at,user_id,...r}:any)=>r),finalRewatches:final.rewatches.map(({user_id,...r}:any)=>r)};
    throw rollback;
   }).catch(e=>{active=undefined;if(e!==rollback)throw e;return output})};
   outcomes.push(await ownerCall());
   async function ownerCall(){return (version==='default'?prior.changeContinue:changeContinue)(admin.id,{mediaId:work.id,action:'remove'})}
  }
  const [a,b]=outcomes;const omit=(x:any)=>{const {version,snapshotRows,snapshotBytes,elapsedMs,...rest}=x;return rest};check(JSON.stringify(omit(a))===JSON.stringify(omit(b)),work.kind+'-native-outcome-equal');check(b.canonicalTarget,work.kind+'-whole-work-target');check(b.removedQueue.length>0,work.kind+'-positive-consumption');check(b.afterRemoveQueue.length>0,work.kind+'-nonmatching-queue-remains');check(b.snapshotRows<a.snapshotRows,work.kind+'-row-gain');check(b.nativeStatementCount===a.nativeStatementCount,work.kind+'-statement-count-preserved');check(b.eventDelta===1&&b.repeatEventDelta===0,work.kind+'-drop-and-idempotent-event-contract');check(b.repeatQueue.length===0,work.kind+'-final-removed-id-filter');result.comparisons.push({kind:work.kind,default:a,current:b});
 }
 check(hash(await original(census))===hash(initial),'account-and-revision-census-restored');check(result.externalCalls===0,'zero-external-calls');
}catch(e:any){result.failure={message:String(e.message).split('\nparams:')[0],cause:e.cause?.message,code:e.cause?.code??e.code};process.exitCode=1}finally{(db as any).transaction=original;globalThis.fetch=fetchOriginal;await Bun.write(process.argv[2],JSON.stringify(result,null,2));await closeDb()}
