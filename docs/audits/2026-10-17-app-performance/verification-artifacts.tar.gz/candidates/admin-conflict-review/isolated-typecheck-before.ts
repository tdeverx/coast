import {getPendingConflicts} from '/Users/admin/Documents/ChatGPT/coast-new/docs/audits/2026-10-17-app-performance/candidates/admin-conflict-review/typecheck-before.ts';
declare const pending:Awaited<ReturnType<typeof getPendingConflicts>>;
const componentCounts:{id:string;localItemCount?:number;remoteItemCount?:number}[]=pending;
void componentCounts;
