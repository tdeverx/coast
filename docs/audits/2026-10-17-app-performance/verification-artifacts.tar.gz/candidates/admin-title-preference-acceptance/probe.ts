import {getSql,getDb,closeDb} from '../../../../../src/lib/server/db';
import {workSummaries} from '../../../../../src/lib/collection/query.server';
import {publicWork} from '../../../../../src/lib/server/public-api/response';
import {resolveMetadata} from '../../../../../src/lib/catalogue/metadata/resolve';
import {getConfig,withRequestConfig} from '../../../../../src/lib/server/config';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const runId=process.env.COAST_AVATAR_RUN_ID!,url=new URL(process.env.DATABASE_URL!);if(process.env.COAST_AUDIT_MATCHED_AVATAR_COPY!=='1'||url.hostname!=='127.0.0.1'||url.port!=='55432'||!/^\/coast_audit_fix_actual_[a-f0-9]{32}$/.test(url.pathname))throw Error('owned-copy-required');
const result:any={runId,status:'running',checks:{},pairs:[],boundary:'Finite missing MIN03 positive policy acceptance: controlled admin metadata preferences/overrides/locks over actual catalogue records on marker-owned actual-data copy. Archived full-card+formatter versus current summary+formatter. No provider replies/users/catalogue records fabricated; no bearer/API-auth claim.'};const check=(v:any,k:string)=>{result.checks[k]=!!v;if(!v)throw Error(k)};const hash=(s:string)=>createHash('sha256').update(s).digest('hex');
const paths=['src/lib/collection/query.server.ts','src/lib/server/queries/media.ts','src/lib/server/public-api/response.ts','src/lib/catalogue/metadata/resolve.ts','src/lib/catalogue/overrides/presentation.server.ts'];const root=new URL('../../../../../',import.meta.url);const hashes=async()=>Object.fromEntries(await Promise.all(paths.map(async p=>[p,hash(await Bun.file(new URL(p,root)).text())])));result.sourceBefore=await hashes();
const runtime=process.env.COAST_DATA_DIR!+'/title-owners';const preflight=await Bun.spawn([process.execPath,'--tsconfig-override',new URL('tsconfig.json',root).pathname,import.meta.dir+'/prepare.ts',runtime],{env:process.env,stdout:'inherit',stderr:'inherit'}).exited;check(preflight===0,'native-owner-import-preflight');const manifest=JSON.parse(await readFile(runtime+'/manifest.json','utf8'));result.archivedSource=manifest;
const old=await import(manifest.baselines['src/lib/collection/query.server.ts'].path),oldFormat=await import(manifest.baselines['src/lib/server/public-api/response.ts'].path);
let external=0;globalThis.fetch=(async()=>{external++;throw Error('external-forbidden')})as any;
const raw=getSql(),c=await raw.reserve(),key=Symbol.for('coast.database.pool');(globalThis as any)[key]=c;const db=getDb();
let admin:any,target:any,snapshots:any[],music:any,config:any;
const alias='Private admin title acceptance',overrideTitle='Administrator title acceptance';
async function setup(original:boolean,privateAlias:string|null,locked:boolean,adminOverride:boolean,work=target.id){
 await c`set default_transaction_read_only='off'`;
 await c`update users set settings=jsonb_set(settings,'{originalTitles}',to_jsonb(${original}::boolean),true)where id=${admin.id}`;
 if(work===target.id){await c`delete from metadata_overrides where media_id=${target.id}`;await c`delete from metadata_locks where media_id=${target.id}`;if(adminOverride)await c`insert into metadata_overrides(media_id,title,updated_by)values(${target.id},${overrideTitle},${admin.id})`;if(locked)await c`insert into metadata_locks(media_id,field)values(${target.id},'title')`}
 await c`delete from user_metadata_preferences where user_id=${admin.id}and media_id=${work}`;if(privateAlias!==null)await c`insert into user_metadata_preferences(user_id,media_id,title)values(${admin.id},${work},${privateAlias})`;
 await c`set default_transaction_read_only='on'`;
}
async function state(){const[r]=await c`select
 (select md5(settings::text)from users where id=${admin.id})as settings,
 (select md5(coalesce(jsonb_agg(to_jsonb(t)order by media_id)::text,''))from metadata_overrides t where media_id=${target.id})as overrides,
 (select md5(coalesce(jsonb_agg(to_jsonb(t)order by field)::text,''))from metadata_locks t where media_id=${target.id})as locks,
 (select md5(coalesce(jsonb_agg(to_jsonb(t)order by media_id)::text,''))from user_metadata_preferences t where user_id=${admin.id})as preferences,
 (select count(*)::int from tracking_events where user_id=${admin.id})as events,
 (select count(*)::int from outbox_actions where user_id=${admin.id})as outbox`;return r}
async function pair(mode:string,viewer:string|null,expected:string|undefined,work=target.id){const beforeState=await state();const [budget]=await c`select current_setting('default_transaction_read_only')as read_only`;check(budget.read_only==='on',mode+'-read-only-owner');
 const before=await withRequestConfig(async()=>(await old.workCards(admin.id,viewer,[work])).map((i:any)=>oldFormat.publicWork(i)));
 const after=await withRequestConfig(async()=>(await workSummaries(admin.id,viewer,[work])).map(i=>publicWork(i)));
 check(JSON.stringify(before)===JSON.stringify(after),mode+'-complete-public-dto-equal');check(after.length===1&&after[0].id===work,mode+'-actual-identity-preserved');if(expected!==undefined)check(after[0].title===expected,mode+'-positive-policy-applied');if(viewer===null)check(after[0].title!==alias,mode+'-private-alias-not-exposed');check(JSON.stringify(beforeState)===JSON.stringify(await state()),mode+'-state-unchanged');
 result.pairs.push({mode,audience:viewer?'actual-admin':'guest',completeEqual:true,expectedPolicyApplied:expected!==undefined,privateAliasNotExposed:viewer===null?true:undefined,items:after.length,completeDtoBytes:Buffer.byteLength(JSON.stringify(after)),ownerReadsProtectedReadOnly:true,stateUnchanged:true});}
try{
 const[marker]=await c`select shobj_description(oid,'pg_database')as marker from pg_database where datname=current_database()`;check(marker.marker==='coast-title-preference-acceptance-copy:'+runId,'exact-owned-marker');await c`set statement_timeout='30000'`;await c`set lock_timeout='5000'`;
 [admin]=await c`select id from users where username='admin'and role='admin'and not disabled and coast_feature_enabled(id,'screen')and coast_feature_enabled(id,'music')`;check(admin,'actual-admin-screen-music');config=await getConfig();
 const candidates=await c`select distinct m.* from media m join metadata_snapshots s on s.media_id=m.id where m.kind='movie'and s.original_title is not null and s.original_title<>s.title order by m.id limit 60`;
 for(const m of candidates){const s=await c`select * from metadata_snapshots where media_id=${m.id}`;const input={fallback:{...m,originalTitle:m.original_title,releaseDate:m.release_date},snapshots:s.map(x=>({...x,originalTitle:x.original_title,releaseDate:x.release_date,updatedAt:x.updated_at})),policy:config.metadataSource==='tmdb-only'?'tmdb-only':'local-first'}as any;const plain=resolveMetadata({...input,preferOriginalTitle:false}).values.title,original=resolveMetadata({...input,preferOriginalTitle:true}).values.title;if(plain&&original&&plain!==original){target=m;snapshots=input.snapshots;result.actualOriginalTitleDistinct=true;break}}
 check(target,'actual-title-original-distinct');[music]=await c`select id,title from music_works where kind='track'order by id limit 1`;check(music,'actual-music-identity');
 const fallback={...target,originalTitle:target.original_title,releaseDate:target.release_date};const expected=(original:boolean,user:string|null,locked:boolean,overridden:boolean)=>resolveMetadata({fallback,snapshots,user:user===null?null:{title:user},locks:locked?['title']:[],override:overridden?{title:overrideTitle}:null,preferOriginalTitle:original,policy:config.metadataSource==='tmdb-only'?'tmdb-only':'local-first'}).values.title!;
 for(const s of [{mode:'original-title-enabled',original:true,user:null,locked:false,override:false},{mode:'private-alias-over-original',original:true,user:alias,locked:false,override:false},{mode:'locked-title-over-private-alias',original:true,user:alias,locked:true,override:false},{mode:'administrator-title-with-lock',original:true,user:alias,locked:true,override:true},{mode:'private-alias-over-unlocked-administrator-title',original:false,user:alias,locked:false,override:true}]){
  await setup(s.original,s.user,s.locked,s.override);await pair(s.mode,admin.id,expected(s.original,s.user,s.locked,s.override));if(s.user!==null)await pair(s.mode+'-guest',null,undefined);
 }
 await setup(false,alias,false,false,music.id);await pair('non-screen-private-alias',admin.id,alias,music.id);await pair('non-screen-private-alias-guest',null,undefined,music.id);
 check(external===0,'zero-external');result.externalCalls=external;result.status='passed';
}catch(e:any){result.status='failed';result.failure={message:String(e.message).split('\nparams:')[0],code:e.code??e.cause?.code};process.exitCode=1}
finally{result.sourceAfter=await hashes();result.productionSourceUnchanged=JSON.stringify(result.sourceBefore)===JSON.stringify(result.sourceAfter);(globalThis as any)[key]=raw;c.release();await closeDb();await writeFile(process.argv[2],JSON.stringify(result,null,2));}
