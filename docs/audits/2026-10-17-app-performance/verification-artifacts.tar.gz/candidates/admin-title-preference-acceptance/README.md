# MIN-03 positive title-policy acceptance — passed

Executed only the eleven missing positive owner-policy comparisons,61checks, in run `e6fc338f-e97b-41ec-a03b-b0b80808d3f5`. All complete public DTOs from archived full-card owner + archived formatter matched current shared summary owner + current formatter. No new proposal or production source change was made.

The actual admin, an actual movie with distinct retained provider original/display titles, and an actual music track supplied the identities. No users, books, catalogue records, metadata snapshots or provider responses were invented. Controlled changes to admin original-title preference, private aliases, administrator metadata override and title lock occurred only on the marker-owned disposable actual-data copy. Original snapshot/identity rows were retained. Each native comparison ran with default transaction READ ONLY enabled on the exclusive reserved connection, including owner-created transactions. READ ONLY admission was asserted before every pair. Settings/override/lock/preference fingerprints and event/outbox counts stayed unchanged across each pair.

| Controlled policy | Actual-admin DTO | Guest DTO |
| --- | --- | --- |
| Original titles enabled, retained original/display titles differ | Complete equality; original-title choice applied | Not repeated; no private alias in this case |
| Private alias over enabled original title | Complete equality; alias applied | Complete equality; private alias absent |
| Title lock over private alias/original preference | Complete equality; locked title wins | Complete equality; private alias absent |
| Administrator title with lock | Complete equality; administrator title wins | Complete equality; private alias absent |
| Private alias over unlocked administrator title | Complete equality; private alias wins | Complete equality; private alias absent |
| Non-screen private alias on actual music track | Complete equality; alias applied | Complete equality; private alias absent |

Positive self-policy results were independently checked against the shared pure metadata resolver populated with actual retained source facts and controlled admin state, not merely compared for equality. The original-title cohort was required to produce different resolved original/display titles before testing. Private strings and actual identities remain in memory; receipts retain only complete-equality/policy booleans and response byte counts.

`prepare.ts` loads the existing archived Collection owner and archived public DTO formatter from `candidates/work-summary`, rewrites only anchored multiline import declarations, and imports both archived/current owners. Native imports and probe syntax were verified outside the database copy. The wrapper records intended executed probe path/SHA before launch: `probe.ts`, SHA-256 `025efd3dc7d932bce7e3c6f482a046dbcc4f5b10e9dcab383d93942b6993b139`. `actual.json` includes archived/current source identities, all eleven comparisons, READ ONLY/state checks, and cleanup proof. Current Collection, media, DTO, resolver and preference-owner source hashes were unchanged before/after.

The owned copy was marker-verified, dropped and confirmed absent. External fetch was forbidden and count stayed zero; no worker, media/provider transport, secret/token creation, normal database mutation or HTTP authorization/quota expansion occurred. Existing MIN-03 resource evidence is reused rather than rerun. Actual books and live bearer HTTP acceptance remain outside this narrow positive policy proof.

Recommendation: accept the named controlled actual-data title-lock/override/private-alias/original-preference owner acceptance. Distinguish it from naturally retained preferences and from browser/bearer HTTP coverage.
