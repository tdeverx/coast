import pathlib,os,subprocess,json,datetime
root=pathlib.Path('/Users/admin/Documents/ChatGPT/coast-new');ev=root/'docs/audits/2026-10-17-app-performance/evidence';bun=root/'.tools/bun-1.4.3/bun-darwin-aarch64/bun'
env={**os.environ,'PATH':str(bun.parent)+os.pathsep+os.environ['PATH']}
for key in ['DATABASE_URL','COAST_DB_TEST','COAST_AUDIT_REAL_DATA_CLONE']:env.pop(key,None)
checks=[('unit',[str(bun),'test','tests']),('check',[str(bun),'run','check']),('build',[str(bun),'run','build']),('code-inventory',[str(bun),'run','code:inventory']),('ui-inventory',[str(bun),'run','ui:inventory:check']),('code-style',[str(bun),'run','code:style'])]
results=[]
for name,cmd in checks:
 log=ev/f'implementation-found-04-{name}.log'
 with log.open('w')as f:r=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 results.append({'name':name,'exit':r.returncode,'log':log.name});print(json.dumps(results[-1]),flush=True)
 if r.returncode:break
receipt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'results':results,'passed':len(results)==len(checks)and all(x['exit']==0 for x in results)}
(ev/'implementation-found-04-gates.json').write_text(json.dumps(receipt,indent=2)+'\n')
raise SystemExit(0 if receipt['passed']else 1)
