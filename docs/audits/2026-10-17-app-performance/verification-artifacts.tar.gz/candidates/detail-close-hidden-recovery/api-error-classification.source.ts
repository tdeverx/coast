export class ApiError extends Error {
  constructor(
    message: string,
    public status: number,
    public details?: unknown
  ) {
    super(message);
  }
}
/** A feature withdrawal is a terminal resource boundary, not a transient network failure. */
export function isFeatureDisabled(cause:unknown) {
  return cause instanceof ApiError && !!cause.details && typeof cause.details==='object' &&
    'code' in cause.details && ['feature_disabled','experimental_disabled'].includes(String(cause.details.code));
}
