import {createHash} from 'node:crypto';
import {parse} from '/Users/admin/Documents/ChatGPT/coast-new/node_modules/svelte/compiler/index.js';
const folder='/private/tmp/coast-detail-close-hidden-recovery-v4-next',root='/Users/admin/Documents/ChatGPT/coast-new';
const sha=(text:string)=>createHash('sha256').update(text).digest('hex'),transpiler=new Bun.Transpiler({loader:'ts'}),report:any={status:'running',scope:'Syntax/source-pin preparation only; no compiler code generation, Bun.build, application/test module evaluation, test execution, server, browser or database.',checks:[]};
try{
 const expected=JSON.parse(await Bun.file(folder+'/source-pins.json').text());
 for(const[path,hash]of Object.entries(expected))if(sha(await Bun.file(root+'/'+path).text())!==hash)throw Error('current_source_pin_changed');
 report.checks.push({kind:'current_source_pins',count:Object.keys(expected).length,passed:true});
 const prior=JSON.parse(await Bun.file(folder+'/v3-verified-inputs.json').text());for(const [path,hash]of Object.entries(prior.files))if(sha(await Bun.file(path).text())!==hash)throw Error('immutable_verified_v3_input_changed');
 report.checks.push({kind:'immutable_v3_inputs',count:Object.keys(prior.files).length,passed:true});
 const manifest=JSON.parse(await Bun.file(folder+'/candidate-manifest.json').text());
 for(const record of Object.values(manifest.sources) as any[]){const text=await Bun.file(folder+'/'+record.candidateFile).text();if(sha(text)!==record.candidate)throw Error('candidate_hash_changed');parse(text,{modern:true});}
 const panel=await Bun.file(folder+'/DetailPanel.svelte.candidate').text(),before=await Bun.file(folder+'/DetailPanel.svelte.v3-verified').text();if(panel!==before.replace('if(!data)closed();','if(!data)closeMediaDetails();'))throw Error('v4_exact_manual_close_delta');
 report.checks.push({kind:'candidate_svelte_parse_and_exact_manual_delta_only',count:2,passed:true});
 const client=await Bun.file(root+'/src/lib/ui/client.ts').text(),errorStart=client.indexOf('export class ApiError extends Error {'),errorEnd=client.indexOf('export async function api<',errorStart);if(errorStart<0||errorEnd<errorStart)throw Error('actual_error_source_markers');const errorSource=client.slice(errorStart,errorEnd);if(sha(errorSource)!==manifest.apiClassification.extractedSha256||errorSource!==await Bun.file(folder+'/api-error-classification.source.ts').text())throw Error('actual_error_source_changed');const errorTypes=transpiler.transformSync(errorSource);
 report.checks.push({kind:'actual_ApiError_and_feature_predicate_source_parse_only',passed:true,sourceSha256:sha(errorSource)});
 const entry=await Bun.file(folder+'/serve.ts').text();transpiler.transformSync(entry);report.entrySha256=sha(entry);
 const marker='const modules:Record<string,{source:string;svelte?:boolean;runes?:boolean}>=';
 const start=entry.indexOf(marker)+marker.length,end=entry.indexOf('\nconst aliases:',start);if(start<marker.length||end<start)throw Error('review_exact_fixture_module_literal');
 const literal=entry.slice(start,end).trim().replace(/;$/,'');
 // Evaluate only this trusted object-of-strings literal. No inner module,
 // component controller, request, promise, test or server is evaluated here.
 const modules=new Function('root','errorTypes','return ('+literal+');')(root,errorTypes);
 let svelte=0,javascript=0;for(const mod of Object.values(modules) as {source:string;svelte?:boolean}[]){if(mod.svelte){parse(mod.source,{modern:true});svelte++;}else{transpiler.transformSync(mod.source);javascript++;}}
 const list=modules.controls.source.match(/const cases=(\[[\s\S]*?\]);<\/script>/)?.[1];if(!list)throw Error('review_control_list_literal');const controls=new Function('return ('+list+');')();if(controls.length!==23||new Set(controls.map((c:any)=>c[0])).size!==23)throw Error('exact_twenty_three_controls');
 for(const [id]of controls)if(!modules.scheduler.source.includes("name==='"+id+"'"))throw Error('declared_control_without_branch');if(modules.scheduler.source.includes('hidden-terminal-player-gap')||modules.scheduler.source.includes('retained_hidden_terminal_recovery_gap_negative_characterization'))throw Error('v3_negative_characterization_not_replaced_in_v4');
 report.checks.push({kind:'entry_and_inner_module_syntax_only',entry:1,svelteModules:svelte,javascriptModules:javascript,controls:controls.map((c:any)=>c[0]),passed:true});
 for(const file of ['detail-panel-close-owner.test.ts.proposed','dialog-geometry.test.ts.proposed'])transpiler.transformSync(await Bun.file(folder+'/'+file).text());
 report.checks.push({kind:'proposed_maintained_test_typescript_parse_only',count:2,panelTests:8,newDialogTests:1,passed:true});
 report.status='passed_preparation_only';
}catch(error){report.status='failed_preparation_only';report.failure=error instanceof Error?error.message:'unknown';process.exitCode=1;}
await Bun.write(folder+'/preparation-checks.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));
