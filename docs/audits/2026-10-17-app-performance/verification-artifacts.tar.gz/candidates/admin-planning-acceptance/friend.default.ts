import {getSql} from '$lib/server/db';
import {AppError} from '$lib/server/security/errors';
export async function requireFriend(userId:string,otherId:string) {
 const [f]=await getSql()`select f.id from friendships f join users u on u.id=${otherId}::uuid where f.user_a=least(${userId}::uuid,${otherId}::uuid) and f.user_b=greatest(${userId}::uuid,${otherId}::uuid) and f.state='accepted' and not u.disabled and coast_feature_enabled(${userId}::uuid,'social') and coast_feature_enabled(${otherId}::uuid,'social')`;
 if(!f)throw new AppError(403,'This action is available between friends.');
}
