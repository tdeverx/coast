# MIN-07 existing friendship batching: positive native Planning acceptance passed

No source/proposal added. The existing applied friendship-batching repair now has nine complete archived DEFAULT/current native API/domain comparisons on a marker-owned actual-data copy. Actual admin, actual eligible movie and three existing accepted friends are used; peers are passive references. Planning/Parties are enabled temporarily only on the copy, with a controlled future plan. Preflight compiled every probe/module/wrapper and imported native current/archived API owners before copy creation; source/input identities stayed unchanged.

All nine outcomes match complete normalized plan/reminder rows, native result/status/errors, notification rows and revision/staging effects. Successful plans have one reminder job, exact future startsAt and15-minute reminder timestamp, correct actor/title/party/first-occurrence raw friend spelling/order, and independently verified generated plan→payload identity. Own generated plan/job/correlation UUIDs are normalized only after native relationship checks. The first receipt stopped on omitted random correlation-ID normalization; corrected identity preparation and failed receipt remain separate.

| Scenario | Status | Friend queries DEFAULT/current | Native statements DEFAULT/current |
|---|---:|---:|---:|
| Three actual friends, party |200|6/2|14/10|
| No friends, non-party |200|0/0|8/8|
| Repeated/uppercase-case friend input |200|8/2|16/10|
| Raw21 repeated IDs |400|0/0|1/1|
| First invalid target in order |403|2/1|4/3|
| Friendship withdrawn between phases |403|4/2|8/6|
| Party feature withdrawn between phases |403|3/1|7/5|
| Existing100scheduled-plan cap |409|6/2|12/8|
| Native reminder INSERT failure |503|6/2|14/10|

Non-friend policy/account-lock/cap/write admission order is exact in all paired native traces. Failed cases insert no lasting plan/job. Native SQL is delegated unchanged; begin callbacks use SAVEPOINTs on one reserved connection inside outer rollback. This preserves preflight/fresh-phase separation without allowing test commits. No fabricated API/provider response or external delivery occurred.

createPlan schedules a reminder; it does not deliver planning notifications. Existing notifications remain unchanged. remindPlan is not executed or modified, reminder batching stays rejected, and this acceptance makes no claim of reminder-worker/provider/browser/production-resource delivery.

All scenarios rolled back and compared copy state restored; wrapper verified marker, dropped the copy, confirmed absence and removed private runtime files. Source database untouched, pool closed, zero fetch attempts. Query/admission reductions are scoped native counts; local times are observations only. actual.json/summary.json contain final receipt and exact traces. No normal account writes, dependency, commit/push/PR or additional performance project.
