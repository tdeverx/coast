import {getSql,closeDb} from '../../../../../src/lib/server/db';
import {roomState} from '../../../../../src/lib/playback/synced/service.server';
import {writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const runId=process.env.COAST_AVATAR_RUN_ID!,url=new URL(process.env.DATABASE_URL!);
if(process.env.COAST_AUDIT_MATCHED_AVATAR_COPY!=='1'||url.hostname!=='127.0.0.1'||url.port!=='55432'||!/^\/coast_audit_fix_actual_[a-f0-9]{32}$/.test(url.pathname))throw Error('owned-copy-required');
const raw=getSql(),key=Symbol.for('coast.database.pool'),result:any={runId,status:'running',checks:{},scenarios:[],boundary:'Controlled temporary room/participant state on actual-data owned clone; actual admin actor; actual passive peer only; no media playback/provider traffic.'};
const check=(ok:any,k:string)=>{result.checks[k]=!!ok;if(!ok)throw Error(k)};
let external=0;globalThis.fetch=(async()=>{external++;throw Error('external-forbidden')})as any;
const base=new URL('../../../../../src/lib/playback/synced/service.server.ts',import.meta.url),source=await Bun.file(base).text();
const start=source.indexOf('    // Friendship removal and disabled accounts revoke session participation too.');
const end=source.indexOf("    const members:RoomState['participants']",start);
check(start>0&&end>start,'candidate-source-anchor');
let candidate=source.slice(0,start)+'    if(!unchangedLiveness){\n'+source.slice(start,end)+'    }\n'+source.slice(end);
candidate=candidate.replace('    if(heartbeat)await sql`UPDATE synced_participants SET heartbeat_at=',`    const [previousLiveness]=heartbeat?await sql\`SELECT buffering,unavailable FROM synced_participants WHERE room_id=\${id} AND user_id=\${userId} AND joined\`:[];
    const unchangedLiveness=!!heartbeat&&previousLiveness?.buffering===heartbeat.buffering&&previousLiveness?.unavailable===heartbeat.unavailable;
    if(heartbeat)await sql\`UPDATE synced_participants SET heartbeat_at=`);
await writeFile(new URL('candidate.server.ts.txt',import.meta.url),candidate);
const code=new Bun.Transpiler({loader:'ts'}).transformSync(candidate).replace(/from\s*(['"])([^'"]+)\1/g,(_m,_q,p)=>`from ${JSON.stringify(p.startsWith('.')?new URL(p,base).pathname:p.startsWith('$lib/')?new URL('../../../../../src/lib/'+p.slice(5),import.meta.url).pathname:import.meta.resolve(p))}`);
const path=process.env.COAST_DATA_DIR!+'/party-candidate.js';await Bun.write(path,code);const proposed=await import(path);
result.sourceHashes={default:createHash('sha256').update(source).digest('hex'),candidate:createHash('sha256').update(candidate).digest('hex')};
let metrics:any;
function instrument(target:any,tx=false):any{return new Proxy(target,{apply(fn,_this,args){const text=Array.isArray(args[0])?args[0].join('?').replace(/\s+/g,' ').trim():'non-tagged';const at=performance.now();const query=Reflect.apply(fn,target,args);return new Proxy(query,{get(q,k){if(k==='then')return (yes:any,no:any)=>q.then((rows:any)=>{const now=performance.now();metrics.statements.push({sql:text,milliseconds:now-at,rows:rows.length});if(/FROM synced_rooms.*FOR UPDATE/.test(text))metrics.lockAcquired=now;return yes?yes(rows):rows},no);const value=Reflect.get(q,k,q);return typeof value==='function'?value.bind(q):value;}})},get(fn,k){if(k==='begin')return async(callback:any)=>{const at=performance.now();try{return await target.begin((sql:any)=>callback(instrument(sql,true)))}finally{metrics.transactionMs=performance.now()-at;metrics.lockHoldMs=metrics.lockAcquired?performance.now()-metrics.lockAcquired:null}};const value=Reflect.get(fn,k,fn);return typeof value==='function'?value.bind(fn):value;}})}
const normalize=(state:any)=>({...state,serverTime:undefined});
try{
 const [marker]=await raw`select shobj_description(oid,'pg_database') as marker from pg_database where datname=current_database()`;check(marker.marker==='coast-party-liveness-copy:'+runId,'exact-owned-marker');
 const [admin]=await raw`select id from users where username='admin' and role='admin' and not disabled and coast_feature_enabled(id,'parties')`;check(admin,'actual-enabled-admin');
 const [peer]=await raw`select u.id from users u where u.id<>${admin.id} and not u.disabled order by u.id limit 1`;result.checks['actual-enabled-passive-peer']=!!peer;
 const [track]=await raw`select id from works where kind='track' order by id limit 1`;check(track,'actual-track-available');
 result.actualReferences={admin:true,passivePeer:true,track:true,identifiersOmitted:true};
 for(const scenario of (peer?['unchanged-admin-only','friendship-revocation-without-room-revision']:['unchanged-admin-only'])){
  const id=crypto.randomUUID();const pair:any[]=[];
  for(const version of ['default','candidate']){
   await raw`delete from synced_rooms where id=${id}`;
   await raw`insert into synced_rooms(id,host_id,media_type,duration_seconds,created_at,updated_at) values(${id},${admin.id},'video',0,'2026-10-19T12:00:00Z','2026-10-19T12:00:00Z')`;
   // Use database now to keep this controlled scenario within the 24-hour lifetime.
   await raw`update synced_rooms set created_at=now(),updated_at='2026-10-19T12:00:00Z' where id=${id}`;
   await raw`insert into synced_participants(room_id,user_id,joined,heartbeat_at) values(${id},${admin.id},true,now())`;
   if(scenario!=='unchanged-admin-only')await raw`insert into synced_participants(room_id,user_id,joined,heartbeat_at) values(${id},${peer.id},true,now())`;
   if(scenario!=='unchanged-admin-only')await raw`delete from friendships where user_a=least(${peer.id}::uuid,${admin.id}::uuid) and user_b=greatest(${peer.id}::uuid,${admin.id}::uuid)`;
   const [before]=await raw`select pg_current_wal_insert_lsn()::text as lsn`;
   metrics={statements:[]};(globalThis as any)[key]=instrument(raw);
   const response=await (version==='default'?roomState:proposed.roomState)(admin.id,id,{buffering:false,unavailable:false});
   (globalThis as any)[key]=raw;
   const [wal]=await raw`select pg_wal_lsn_diff(pg_current_wal_insert_lsn(),${before.lsn}::pg_lsn)::int as bytes`;
   const participants=await raw`select user_id,joined,buffering from synced_participants where room_id=${id} order by user_id`;
   pair.push({version,response:normalize({...response,createdAt:'controlled-creation-time'}),participants,metrics:{...metrics,lockAcquired:undefined,walBytes:wal.bytes,payloadBytes:Buffer.byteLength(JSON.stringify(response))}});
  }
  const equal=JSON.stringify(pair[0].response)===JSON.stringify(pair[1].response)&&JSON.stringify(pair[0].participants)===JSON.stringify(pair[1].participants);
  result.scenarios.push({scenario,exactNormalizedEqual:equal,pair});
  await raw`delete from synced_rooms where id=${id}`;
  if(scenario==='unchanged-admin-only')check(equal,'unchanged-native-candidate-exact');
  else{check(!equal,'candidate-rejected-on-exact-revocation-contract');check(pair[0].participants.find((p:any)=>p.user_id===peer.id)?.joined===false,'native-revokes-passive-nonfriend');check(pair[1].participants.find((p:any)=>p.user_id===peer.id)?.joined===true,'candidate-incorrectly-retains-passive-nonfriend');}
 }
 result.externalCalls=external;check(external===0,'zero-external-transport');result.status=peer?'rejected-contract':'acceptance-gated';result.acceptanceGaps=peer?[]:['No enabled actual peer exists for passive revocation scenario; no users fabricated.','No actual playable media source/session or reader file exercised.','1/8/16 distinct permitted participant contention, delayed clients, revision races, generation revocation remain unverified.'];
 // Avoid exposing actual user/room IDs or usernames in the evidence output.
 for(const scenario of result.scenarios)for(const variant of scenario.pair)for(const member of variant.response.participants)member.avatar=member.avatar?'actual-avatar-present':null;
 const serialized=JSON.stringify(result);const sensitive=await raw`select id,username from users`;let clean=serialized;for(const u of sensitive){clean=clean.replaceAll(u.id,u.id===admin.id?'actual-admin':'actual-passive-user').replaceAll('"'+u.username+'"','"actual-user"')};Object.assign(result,JSON.parse(clean));
}catch(e:any){result.status='failed';result.failure={message:String(e.message).split('\nparams:')[0],code:e.code??e.cause?.code};process.exitCode=1}
finally{(globalThis as any)[key]=raw;await Bun.write(process.argv[2],JSON.stringify(result,null,2));await closeDb()}
