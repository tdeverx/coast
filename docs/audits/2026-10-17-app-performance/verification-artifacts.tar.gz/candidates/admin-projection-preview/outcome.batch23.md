# UIC-04: prepared original candidate; genuine provider evidence gate

Prepared one private candidate only: browser entries contain workId/title, while the durable preview insert retains complete payload/snapshot evidence; review deduplication builds one conflict-ID Set and preserves existing conflict-first ordering. No pagination, panel bound, UI redesign, approval changes or production edits.

The prescribed complete actual projection-preview comparison cannot run within the authorized transport boundary. Every preview calls verifiedContext, which calls the real adapter.profile, then readProjectionRemote calls adapter.read(collection,page) and collectionShows. Approval independently re-reads the same genuine remote state; remote-change rejection depends on that evidence. Even a provided context still calls adapter.profile. A controlled durable preview row over actual catalogue items cannot stand in for genuine current provider responses. Supplying an invented adapter or intercepting those calls with fabricated replies is forbidden by admin-real-data-policy.md/json and the assigned scope. External transport is disabled.

Source proof confirms the durable insert, complete approval owner, and execution/review owners are byte-identical in this candidate. This is preparation evidence, not actual DTO/guard/resource acceptance. No clone measurement or writes were run; there are no owned database changes or copies to clean up. Browser open/close/reopen transfer/mounted-panel/retained-state acceptance remains unexecuted.

Disposition: provider-evidence gate; no adoption recommendation. Stop here under the explicit instruction to stop when genuine provider evidence is required. The candidate is not classified as a failed optimization, and no alternative was explored.
