# MIN-04 original method: default retained

The one candidate replaces the first-occurrence recipient loop with the existing `notifyMany` owner. It is prepared here only; runtime source remains unchanged.

Native private-clone comparison used the existing actual admin as initiating actor and four real Jellyfin owners as passive recipients. Stable values matched, duplicate-recipient suppression and replayed source-key upsert identity passed. Owner statements fell from12 (4config +4preferences +4writes) to3 (1+1+1). Single-run timing/CPU/heap observations are retained in actual.json and are not a performance acceptance claim.

The original method failed two required contracts. A controlled preference change after the first write silenced the second recipient under DEFAULT; candidate retained the earlier normal snapshot. A controlled CHECK failure on recipient2 preserved the first DEFAULT statement's row while the candidate multi-row statement preserved zero rows. Both propagated failure. This is a statement-boundary emulation using savepoints inside an outer rollback, not real committed delivery.

Default retained and this method stops here. Accepting earlier batch preferences and chunk atomicity is a consequential policy change, not a safe invisible optimization. No alternate approach was designed. Preparation-read and lost-ack schedules remain untested; no100-user cohort fabricated.

All owned database changes, including constraint and preferences/config, rolled back. Original518-notification digest restored; pool closed; external network attempts zero. Two harness mistakes (Bun array encoding and absent historical toast column) were corrected; adverse receipts retained. No runtime edits, dependencies, normal-data mutations, remote deliveries, commits, pushes or PRs.
