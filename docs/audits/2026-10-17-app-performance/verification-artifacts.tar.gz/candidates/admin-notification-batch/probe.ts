import {sql} from 'drizzle-orm';
import {PgDialect} from 'drizzle-orm/pg-core';
import {getConfig} from '/Users/admin/Documents/ChatGPT/coast-new/src/lib/server/config';
import {createHash} from 'node:crypto';
const root='/Users/admin/Documents/ChatGPT/coast-new', folder=root+'/docs/audits/2026-10-17-app-performance/candidates/admin-notification-batch';
const report:any={status:'running',comparisons:[]};const pool=new Bun.SQL(process.env.DATABASE_URL!,{max:1,idleTimeout:0});let c:any;let network=0;const oldFetch=globalThis.fetch;globalThis.fetch=(async()=>{network++;throw Error('network_forbidden')}) as any;
const hash=(v:any)=>createHash('sha256').update(JSON.stringify(v)).digest('hex');const assert=(v:any,s:string)=>{if(!v)throw Error(s)};
try{
 const url=new URL(process.env.DATABASE_URL!);assert(process.env.COAST_AUDIT_REAL_DATA_CLONE==='1'&&url.pathname==='/'+(await Bun.file('/private/tmp/coast-app-fixes-clone-name').text()).trim(),'private_clone');
 c=await pool.reserve();await c`BEGIN`;await c`SET LOCAL statement_timeout='30s'`;await c`SET LOCAL lock_timeout='1s'`;await c`SET LOCAL jit=off`;
 const [others]=await c`select count(*)::int n from pg_stat_activity where datname=current_database() and pid<>pg_backend_pid() and backend_type='client backend'`;assert(others.n===0,'exclusive_clone');
 const [admin]=await c`select id from users where role='admin' and disabled=false order by id limit 1`;assert(admin,'actual_admin');
 const rows=await c`select distinct u.id from users u join provider_connections pc on pc.user_id=u.id join provider_instances pi on pi.id=pc.instance_id where pi.provider='jellyfin' order by u.id`;const ids=rows.map((r:any)=>r.id);assert(ids.length>=2,'actual_recipients');report.actual={adminActorPresent:true,passiveRecipients:ids.length,recipientDigest:hash(ids)};
 const digest=async()=>{const [r]=await c`select md5(coalesce(string_agg(row_to_json(n)::text,'' order by id),'')) digest,count(*)::int n from notifications n`;return r};const original=await digest();report.originalNotifications=original;
 const source=await Bun.file(root+'/src/lib/server/notifications/index.ts').text();const segment=source.slice(source.indexOf('export interface NotificationInput'),source.indexOf('export async function resolveNotification'));
 const js=new Bun.Transpiler({loader:'ts'}).transformSync(segment).replaceAll('export ','');
 const dialect=new PgDialect();let calls:any[]=[],mutate=false,changed=false;
 const db={execute:async(query:any)=>{const q=dialect.sqlToQuery(query),start=performance.now();const result=await c.unsafe(q.sql,q.params);calls.push({kind:q.sql.trim().startsWith('INSERT')?'write':q.sql.includes('system_settings')?'config':'preferences',ms:performance.now()-start,rows:result.length});if(mutate&&!changed&&q.sql.trim().startsWith('INSERT')){changed=true;await c`update users set settings=settings||'{"notificationsSilenced":true}'::jsonb where id=${ids[1]}`;}return result;}};
 const owner=new Function('sql','PgDialect','getConfig','getSql',js+';return {notify,notifyMany};')(sql,PgDialect,getConfig,()=>db);
 const input=(userId:string)=>({userId,kind:'sync',title:'Collection source selection changed',body:'Review Trakt Collection export in Settings. Existing remote entries remain until you approve cleanup.',sourceKey:`collection-source-review:${userId}`});
 const invoke=async(mode:string)=>{const inputs=[...new Set([...ids,ids[0]])].map(input);if(mode==='default')for(const item of inputs)await owner.notify(item,db);else await owner.notifyMany(inputs,db);};
 const capture=async()=>Array.from(await c`select user_id,kind,title,body,level,locked,source_key,data,read_at,dismissed_at from notifications where source_key like 'collection-source-review:%' order by user_id`);
 for(const scenario of ['stable','preferences','later-write-failure']){
  const pair:any={scenario};let baseline:any;
  for(const mode of ['default','candidate']){
   await c`SAVEPOINT scenario`;await c`delete from notifications where source_key like 'collection-source-review:%'`;await c`update users set settings=settings||'{"notificationsSilenced":false,"notificationLevel":"normal"}'::jsonb where id=any(${'{'+ids.join(',')+'}'}::uuid[])`;await c`update system_settings set value=value||'{"allowNotificationSilencing":true}'::jsonb where key='coast'`;
   if(scenario==='later-write-failure')await c.unsafe(`ALTER TABLE notifications ADD CONSTRAINT audit_notification_fail CHECK (user_id <> '${ids[1]}'::uuid) NOT VALID`);
   calls=[];mutate=scenario==='preferences';changed=false;const start=performance.now(),cpu=process.cpuUsage(),mem=process.memoryUsage();let failed=false;
   // Savepoint per native statement reproduces autocommit error survival while all owned writes remain rollbackable.
   const raw=db.execute;db.execute=async(q:any)=>{await c`SAVEPOINT statement_boundary`;try{const r=await raw(q);await c`RELEASE SAVEPOINT statement_boundary`;return r;}catch(e){await c`ROLLBACK TO SAVEPOINT statement_boundary`;throw e;}};
   try{await invoke(mode)}catch{failed=true}finally{db.execute=raw;mutate=false}
   const values=await capture();const metrics={wallMs:performance.now()-start,cpuMicros:process.cpuUsage(cpu),heapDelta:process.memoryUsage().heapUsed-mem.heapUsed,statements:calls.length,config:calls.filter(x=>x.kind==='config').length,preferences:calls.filter(x=>x.kind==='preferences').length,writes:calls.filter(x=>x.kind==='write').length,statementMs:calls.reduce((s,x)=>s+x.ms,0)};
   pair[mode]={failed,delivered:values.length,levels:values.map((v:any)=>v.level),valuesDigest:hash(values),metrics};if(mode==='default')baseline=values;else pair.equal=hash(baseline)===hash(values);
   if(scenario==='stable'){
    const before=await c`select id,user_id,created_at,read_at,dismissed_at from notifications where source_key like 'collection-source-review:%' order by user_id`;await invoke(mode);const after=await c`select id,user_id,created_at,read_at,dismissed_at from notifications where source_key like 'collection-source-review:%' order by user_id`;assert(hash(before)===hash(after),'upsert_identity');pair[mode].dedupAndUpsertIdentity=true;
   }
   await c`ROLLBACK TO SAVEPOINT scenario`;await c`RELEASE SAVEPOINT scenario`;
  }
  report.comparisons.push(pair);
 }
 assert(report.comparisons[0].equal,'stable_contract');assert(!report.comparisons[1].equal&&!report.comparisons[2].equal,'expected_policy_obstruction');await c`ROLLBACK`;report.rollback=true;assert(hash(await digest())===hash(original),'restoration');report.notificationRestoration=true;report.status='original_method_rejected_contract_changed';report.decision='Default retained; original direct notifyMany changes preference snapshot timing and later-write committed-prefix behavior. No alternate method explored.';
}catch(e:any){report.diagnostic=e.message;report.errno=e.errno;report.status='probe_failed';report.errorCode=e.code;report.error=e.message?.match(/^[a-z_]+$/)?e.message:'private_diagnostic_only';try{await c`ROLLBACK`;report.failureRollback=true}catch{}}finally{c?.release();await pool.close();report.poolClosed=true;report.networkAttempts=network;globalThis.fetch=oldFetch;await Bun.write(process.argv[2],JSON.stringify(report,null,2)+'\n');console.log(report.status);}
