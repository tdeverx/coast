# PR-11 cap+one music queue candidate — native acceptance passed

Recommendation: adopt the unapplied `candidate.patch` after root review. Production source and UI are unchanged. The candidate implements only the original explicit-overflow prescription in the existing shared music queue owner; it adds no dependencies, queue framework or continuation policy.

One shared10,000-track guard serves `savedMusicQueue` and `musicQueue`. Saved-list/Up Next expansion selects at most10,001 rows; direct album lookup requests10,001 members. Greater than10,000 throws native `DomainError(409,'queue_too_large')` with `This queue exceeds 10,000 tracks. Choose fewer tracks.` before work assessments/progress hydration. At/below cap retain complete DTO/order/repeats/continue identity. Track queues and the separately paged unique party picker retain their existing path. `musicAlbumMembers` itself and its other callers are unchanged.

Two serialized marker-owned copies of the original actual-data clone were created, dropped and proven absent. The actual admin and actual catalogue tracks/albums supplied all content. Controlled temporary playlists use repeated existing tracks or an existing album; Up Next contains existing tracks/album. No catalogue/user/provider identity or reply was fabricated, no media was played, no worker/provider transport ran, and no normal data or production source changed. Whole-copy cleanup owns the temporary list/queue changes.

## Executed exact results

`actual-first.json` retains the initial eight-scenario run `337bb3c9-7db6-4fda-aa44-a3ea04512afa`,33checks. Repeated-track playlists at9,999 and10,000 match native DEFAULT complete DTOs, exact alternating recording order/repeats and first continue identity. At10,001 DEFAULT silently returns10,000; candidate throws the explicit error with no DTO. Complete native API handler execution returns HTTP409 and the exact error/code. Actual Up Next, album, track and paged party picker DTOs match. Repeated actual album expansion also rejects overflow. State fingerprints and event/outbox/room counts remain unchanged, and executed SQL contains no native DML.

A counter review found the first run omitted statements inside `workAssessments` transactions. Its exact DTO/state/error checks remain valid; first-run counters are explicitly marked root-only lower bounds. `actual-resource.json` run `8cdc22ee-167c-4c31-9686-af59efa51a9e`,28checks, corrects transaction-client instrumentation and measures only the resource-relevant boundaries/consumer shapes.9,999 was not replayed. A14-member actual album supplies nontrivial direct album order and repeated-album expansion; no album membership identity was invented to manufacture10,001 direct album entries.

| Native DEFAULT → candidate | SQL statements | Returned SQL rows | Serialized DTO bytes |
| --- | ---: | ---: | ---: |
|10,000 repeated tracks |7 →7 |10,004 →10,004 |1,015,063 →1,015,063 |
|10,001 repeated tracks |7 →4 |10,004 →10,003 |1,015,063 →0; explicit409 |
| Up Next,16expanded tracks |5 →5 |33 →33 |1,634 →1,634 |
| Actual album,14members |7 →7 |44 →44 |1,431 →1,431 |
| Actual single track |6 →6 |4 →4 |158 →158 |
| Party picker,16unique choices |6 →6 |34 →34 |1,612 →1,612 |
| Repeated14-member album,over cap |7 →4 |10,016 →10,003 |977,198 →0; explicit409 |

For10,001-track candidate execution, the10,001-row expansion is the last executed SQL statement: no assessment/progress transaction follows. Full DTO and state equality is asserted before aggregate records are retained. Native implicit BEGIN/COMMIT statements are excluded from both query counts. Rows are returned native SQL rows, not PostgreSQL visited tuples/buffers. Recorded elapsed/RSS deltas are single controlled process observations, not peak-memory budgets or production performance. The selector still scans/sorts its admitted source: cap+one bounds returned materialization and rejects incomplete queues; it does not claim constant SQL CPU for arbitrarily large lists.

## Route and party boundary

Both versions of the full native API handler were import-preflighted with only the music queue import redirected. The candidate full handler's real DomainError mapping was executed and returned409/error/code, with no playback or mutations. PartyMenu calls the separate `music/queue/picker` page owner, which remained exact on actual controlled Up Next. Its existing200-room-queue command limit is a separate unchanged contract.

Source review confirms full-list sequence playback awaits the queue read inside its existing catch before calling `playMusicQueue`, resetting a playlist boundary or starting screen playback (`ui/controls/sequence.svelte.ts:15-35`). Direct/saved music also await the API before updating player audioQueue (`playback/client.svelte.ts:176-187`). No client error-policy change is necessary. These are source contracts, not a claim of actual browser playback/error-dialog execution.

## Provenance and reviewable files

`queue.default.ts.txt` is the exact current owner at capture; `queue.candidate.ts.txt` and `candidate.patch` are private and unapplied. `prepare.ts` rewrites only anchored multiline import declarations, preserving SQL literals. Native queue and full API imports plus probe syntax were verified outside database copies. Wrapper receipts record intended executed probe path/SHA before child launch; each in-copy preparation records both queue source hashes and native API source hash. Final resource probe SHA is `da4642f0e699e2edde01d85cc91bdedda9a225acdaba7ca3283218d7c49b132d`. Both runs assert production queue source unchanged and forbid fetch. `probe.ts`/`probe-resource.ts`, `wrapper*.ts`, `run*.py` retain executed instrumentation and the approved in-memory testcontainerconnection/exclusive-lock path.
