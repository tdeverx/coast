import {readFile,mkdir,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const root='/Users/admin/Documents/ChatGPT/coast-new',dir=root+'/docs/audits/2026-10-17-app-performance/candidates/admin-music-queue-overflow',out=process.argv[2]??'/private/tmp/coast-music-queue-preflight';await mkdir(out,{recursive:true});
const hash=(s:string)=>createHash('sha256').update(s).digest('hex');
function code(source:string,base:string,queue?:string){return new Bun.Transpiler({loader:'ts'}).transformSync(source).replace(/(^import[\s\S]*?\bfrom\s*)(['"])([^'"]+)\2/gm,(_m,prefix,_q,p)=>`${prefix}${JSON.stringify(queue&&p==='$lib/music/queue.server'?queue:p.startsWith('.')?new URL(p,'file://'+base).pathname:p.startsWith('$lib/')?root+'/src/lib/'+p.slice(5):import.meta.resolve(p))}`)}
const manifest:any={files:{}};
for(const version of ['default','candidate']){const source=await readFile(dir+'/queue.'+version+'.ts.txt','utf8'),file=out+'/queue-'+version+'.js';await writeFile(file,code(source,root+'/src/lib/music/queue.server.ts'));manifest.files[version]={path:file,sourceHash:hash(source)};
 const api=await readFile(root+'/src/lib/server/api/index.server.ts','utf8'),route=out+'/route-'+version+'.js';await writeFile(route,code(api,root+'/src/lib/server/api/index.server.ts',file));manifest.files[version].routePath=route;manifest.routeSourceHash=hash(api);
 await import(file);await import(route);
}
await writeFile(out+'/manifest.json',JSON.stringify(manifest,null,2));console.log(JSON.stringify({preflight:'passed',versions:2,nativeRoutesImported:true}));
