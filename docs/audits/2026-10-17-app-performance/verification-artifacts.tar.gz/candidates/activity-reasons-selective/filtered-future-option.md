# Later filtered-path option — source review only, not implemented

The selective candidate leaves every filtered/friend request at its exact current SQL. Optimizing those paths remains open.

A possible later shared-owner option is to wrap the unchanged relationshipReasons producer inside the existing reasons CTE, apply only the cheap exact row predicates there, and then materialize that already restricted set. Conceptually:

```sql
reasons as materialized (
  select * from (<unchanged relationshipReasons>) candidate
  where <friendId absent OR candidate.user_id = friendId>
    and <relationship=all OR candidate.relationship = relationship>
)
```

This is a proposal, not a patch or approved query. Keep the existing outer predicates in visible_relationships, all policy/friendship/category/work visibility checks, and every other consumer unchanged. The friend and relationship tests depend only on columns already produced by reasons; the helper's only consumption is visible_relationships, so these deterministic row predicates appear movable before the expensive policy calls without changing the set. The UNION's distinct-row semantics must remain, and no root graph or event-scope logic is replaced. Do not try to move work category, privacy functions or membership checks into the generic shared relationshipReasons constant used by card heads.

The potential benefit is preserving selective user/type admission before the fence. The potential cost is still a materialization spool and a different plan for every reasons branch; a redundant outer predicate can also affect estimates. If the derived subquery prevents pushdown into the UNION, the intended benefit may not occur. No source assertion can establish the actual plan or avoid spill.

Before implementation: revalidate current source/policy-function attributes and every reasons reference, derive exact SQL/bindings for friend/filtered/all/no-helper cases, then compare the same actual complete outputs and per-family plans against baseline and the selective candidate. Include the observed other-friend branch, watchlist's extra temp reads, positive progress fallback, consumed/all, and actual all-owner/artist/group/mixed-root/cursor cases. Current private/public/visible-ancestor/positive-watchlist and larger-graph gaps remain; do not fabricate states to erase them. No execution, app/dependency/schema change or adoption is authorized by this note.
