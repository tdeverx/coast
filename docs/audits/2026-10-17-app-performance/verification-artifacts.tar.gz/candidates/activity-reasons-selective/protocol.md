# Selective reasons materialization — private candidate only

The unconditional helper remains unadopted. Its 115-pair/28-plan receipt `510f52b4…` is immutable: the other-friend scope gained 1,527 root shared-buffer visits and 1,396 temporary-read blocks; watchlist reduced shared visits but added 1,396 temporary-read blocks. Other measured families improved or stayed equal. The earlier pilot, failed combined-selector proof and counts diagnostic remain unchanged.

This candidate changes one existing CTE interpolation at `activityRelationships`:

```ts
reasons as${scope.relationship==='all'&&!scope.friendId?sql` materialized`:sql``} (${relationshipReasons})
```

Only `relationship === 'all'` without a friend filter receives the fence. Current `activityFeed` validates a supplied friendId as a UUID; no empty-string compatibility behavior is introduced. All filtered relationship or friend-scoped helper calls emit exact baseline SQL and bindings. Helper-absent calls remain unchanged. The original shared relationshipReasons/Edges constants and workSocial/card-head consumer are byte-unchanged. There is no cache, framework, dependency, schema, cap, sort, output, policy or API change.

The candidate's blank fragment has no additional whitespace: ineligible SQL must be byte-identical to the original `reasons as (` form. Eligible SQL must be exactly one `reasons as (` → `reasons as materialized (` change with identical bindings. This is asserted on every actual comparison, not inferred from the source condition.

## Prepared proof, no execution lease

`reasons-selective-full-actual.ts` is a minimal derivative of the passed revised unconditional probe `9e63d66f…`; `unconditional-to-selective-probe.patch` records every change. All 31 current source pins and exact three policy-function/no-RLS gates remain. The same actual census, 64 historical + 51 additional = 115 labels, 14 named plan contexts /28 plans, zero timing-sample loop, ordered full DTO and complete ordered primary-row comparisons, read-only session, transport/key/privacy guards and independent rollback/release/close remain.

Expected complete comparison shapes are:

| Shape | Pairs | Required SQL contract |
| --- | ---: | --- |
| Helper active, relationship=all, no friend | 48 | Exactly one MATERIALIZED keyword, identical bindings |
| Helper active, filtered relationship or friend | 21 | Exact baseline SQL and bindings |
| Helper absent, scoped | 12 | Exact baseline SQL and bindings |
| Helper absent, unscoped | 34 | Exact baseline SQL and bindings |

The historical first64 comprise 17 eligible, one consumed/ineligible helper, 12 helper-absent scoped and34 unscoped. No prior result cache substitutes for current execution. Exact duplicated requests may reuse a completed pair only under the unchanged declared cache key and are reported separately; on the retained prior run all115 were unique.

A new parent lease is required: `COAST_AUDIT_ACTIVITY_REASONS_SELECTIVE_FULL_LEASE=1 COAST_AUDIT_ACTIVITY_REASONS_PHASE=full`. Output must be the absent `/private/tmp/coast-activity-reasons-selective-full-once.json`. The original designated fix clone is the only target, loopback127.0.0.1:55432, max-one reserved RR READ ONLY30s/1s, JIT off/work_mem4MB, same backend/settings and zero-other-client preflight. Current integrated toast source versus original pretoast clone is checked only as separate metadata; this proof does no notice or schema work. Stop on first failure, preserve it, and do not retry or adopt automatically.

## Preserved actual gaps and interpretation

The passed diagnostic proved829 episode rows, but all known-parent tracking/collected state counts for these selected controls were zero, and all episode controls returned zero items. Four real collection-kind member controls also returned zero items; they are not positive contains ancestry. All413 screen collection parents have only1,348 collection-kind links and no contains cohort; that absence is retained and verified afresh.

All four saved audiences are friends, without section/category overrides or social-disable preferences. No private/public/withdrawal state is manufactured. Four scoped returned-cursor results were empty; cursor presence is not a positive second page. Artist/group relationships had positive events but no fallback cards; mixed roots and progress supplied positive fallback cards. Watchlist/lists/favourites positive result cohorts remain absent. Dated multi-track and repeated dated-work listens remain absent. No HTTP/browser, concurrent withdrawal, provider, CPU/RSS/WAL or physical-disk claim is made.

The selective fence still materializes an uncapped scoped reason set on eligible requests, potentially spilling or blocking a different useful predicate in an unmeasured family. The default checked families are evidence, not a universal regression guarantee. Root shared Hit+Read and temporary counters remain per-family; root buffers are not summed with descendants, and single-plan elapsed fields are descriptive only. Ineligible byte SQL identity protects the existing filtered/friend admission paths rather than claiming their performance is now optimized.

The parent reviews this prepared package and future actual outcomes before deciding any production application. No main source has changed during preparation.
