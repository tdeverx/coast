from pathlib import Path
import hashlib,json,difflib
old=Path('/private/tmp/coast-scoped-activity-reasons-next');f=Path('/private/tmp/coast-scoped-activity-reasons-selective-next');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n in ['full-source-pins.json','policy-function-contracts.json','expected-full-coverage-labels.json','expected-full-census.json','expected-full-revised-additional-labels.json','relationships.before.ts.txt']:(f/n).write_bytes((old/n).read_bytes())
baseline=(f/'relationships.before.ts.txt').read_text();before="reasons as (${relationshipReasons})";selective="reasons as${scope.relationship==='all'&&!scope.friendId?sql` materialized`:sql``} (${relationshipReasons})"
assert baseline.count(before)==1
candidate=baseline.replace(before,selective)
(f/'relationships.selective.candidate.ts.txt').write_text(candidate)
(f/'selective-materialization.patch').write_text(''.join(difflib.unified_diff(baseline.splitlines(True),candidate.splitlines(True),fromfile='a/src/lib/social/relationships.server.ts',tofile='b/src/lib/social/relationships.server.ts')))
s=(old/'reasons-full-revised-candidate.ts').read_text().replace(str(old),str(f)).replace('reasons-full-revised-candidate.ts','reasons-selective-full-actual.ts').replace('relationships.materialized.candidate.ts.txt','relationships.selective.candidate.ts.txt').replace('58047cfcb8c2ab6556a9ab529a555ea8100c7b052018ede507ff0faae6dd2c4e',sha(f/'relationships.selective.candidate.ts.txt'))
s=s.replace('/coast-activity-reasons-full-revised-once','/coast-activity-reasons-selective-full-once').replace('COAST_AUDIT_ACTIVITY_REASONS_REVISED_FULL_LEASE','COAST_AUDIT_ACTIVITY_REASONS_SELECTIVE_FULL_LEASE')
source_old="assert(afterHelper.replace('reasons as materialized (${relationshipReasons})','reasons as (${relationshipReasons})')===beforeHelper,'one_keyword_helper_delta_only');"
source_new="assert(afterHelper.replace("+json.dumps(selective)+","+json.dumps(before)+")==beforeHelper,'one_local_selective_fragment_source_delta_only');"
assert s.count(source_old)==1;s=s.replace(source_old,source_new.replace(')==beforeHelper',')===beforeHelper'))
s=s.replace('only private original82aa versus materialized58047 helper changes.','only private original82aa versus selective relationship-all/no-friend helper changes.')
s=s.replace("const helperActive=options.relationship!==undefined,scoped=", "const helperActive=options.relationship!==undefined,materializes=helperActive&&options.relationship==='all'&&!options.friendId,scoped=")
s=s.replace("if(helperActive)assert(b.query.sql.split('reasons as (').length===2", "if(materializes)assert(b.query.sql.split('reasons as (').length===2")
s=s.replace("'helper_absent_sql_byte_identity'", "'ineligible_or_helper_absent_sql_byte_identity'")
s=s.replace("parametersEqual:true,scoped,helperActive,sqlContract:helperActive?", "parametersEqual:true,scoped,helperActive,materializes,sqlContract:materializes?")
s=s.replace("'byte_identical_helper_absent'", "'byte_identical_ineligible_or_helper_absent'")
s=s.replace("report.historicalCoverage={labels:64,uniquePairs:64,unscopedByteIdentical:34,scopedHelperAbsentByteIdentical:12,helperActiveOneKeyword:18};", "assert(report.comparisons.filter((x:any)=>x.materializes).length===17,'historical17eligible_materialized_contexts');report.historicalCoverage={labels:64,uniquePairs:64,unscopedByteIdentical:34,scopedHelperAbsentByteIdentical:12,eligibleHelperOneKeyword:17,ineligibleHelperByteIdentical:1};")
s=s.replace("report.coverageSummary={helperActive:", "report.coverageSummary={materialized:report.comparisons.filter((x:any)=>x.materializes).length,ineligibleHelperByteIdentical:report.comparisons.filter((x:any)=>x.helperActive&&!x.materializes).length,helperActive:")
s=s.replace(" assert(queryPairs.size===14,", " assert(report.coverageSummary.materialized===48&&report.coverageSummary.ineligibleHelperByteIdentical===21,'exact48eligible_and21ineligible_helper_pairs');\n assert(queryPairs.size===14,")
s=s.replace("helperActive:pair.options.relationship!==undefined,sqlShapeSha256:", "helperActive:pair.options.relationship!==undefined,materializes:pair.options.relationship==='all'&&!pair.options.friendId,sqlShapeSha256:")
s=s.replace("'Only one helper optimization fence changes; full query/input/caps/order/fallback stay.", "'Only relationship=all without friendId gets the materialization fence; all filtered/friend/helper-absent shapes require exact baselineSQL and bindings. Full query/input/caps/order/fallback stay.")
(f/'reasons-selective-full-actual.ts').write_text(s)
(f/'unconditional-to-selective-probe.patch').write_text(''.join(difflib.unified_diff((old/'reasons-full-revised-candidate.ts').read_text().splitlines(True),s.splitlines(True),fromfile='passed/reasons-full-revised-candidate.ts',tofile='prepared/reasons-selective-full-actual.ts')))
verify=(old/'verify-full-revised-preparation.ts').read_text().replace(str(old),str(f)).replace('full-revised-preparation-checks.json','preparation-checks.json').replace('relationships.materialized.candidate.ts.txt','relationships.selective.candidate.ts.txt').replace('58047cfcb8c2ab6556a9ab529a555ea8100c7b052018ede507ff0faae6dd2c4e',sha(f/'relationships.selective.candidate.ts.txt')).replace('reasons-full-revised-candidate.ts','reasons-selective-full-actual.ts').replace('/coast-activity-reasons-full-revised-once','/coast-activity-reasons-selective-full-once')
verify=verify.replace("candidate.replace('reasons as materialized (${relationshipReasons})','reasons as (${relationshipReasons})')", "candidate.replace("+json.dumps(selective)+","+json.dumps(before)+")")
(f/'verify-preparation.ts').write_text(verify)
print(json.dumps({'helperSha256':sha(f/'relationships.selective.candidate.ts.txt'),'patchSha256':sha(f/'selective-materialization.patch'),'probeSha256':sha(f/'reasons-selective-full-actual.ts'),'probeDeltaSha256':sha(f/'unconditional-to-selective-probe.patch')}))
