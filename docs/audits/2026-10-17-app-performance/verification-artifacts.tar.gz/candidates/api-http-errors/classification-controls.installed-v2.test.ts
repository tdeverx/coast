import {expect,test} from 'bun:test';
import {json,error,isHttpError} from '/Users/admin/Documents/ChatGPT/coast-new/node_modules/@sveltejs/kit/src/exports/index.js';
import * as v from '/Users/admin/Documents/ChatGPT/coast-new/node_modules/valibot/dist/index.mjs';
import {AppError} from '/Users/admin/Documents/ChatGPT/coast-new/src/lib/server/security/errors.ts';
import {DomainError} from '/Users/admin/Documents/ChatGPT/coast-new/src/lib/core/errors.ts';
import {ProviderActionError} from '/Users/admin/Documents/ChatGPT/coast-new/src/lib/providers/contracts.ts';
import {ProviderHttpError} from '/Users/admin/Documents/ChatGPT/coast-new/src/lib/server/security/provider-fetch.ts';
import {providerApiError} from '/Users/admin/Documents/ChatGPT/coast-new/src/lib/server/security/provider-api-error.ts';
const folder='/private/tmp/coast-api-http-errors-next';
const AsyncFunction=Object.getPrototypeOf(async function(){}).constructor;
const classifyFailure=(cause:unknown)=>(cause as any)?.name==='AbortError'?'aborted':'unknown';
async function compile(owner:'central'|'insights',state:'before'|'candidate'){
 const source=await Bun.file(folder+'/'+owner+'.'+state+'.ts.txt').text();
 const marker=owner==='central'?'  } catch (error) {':'  } catch(cause) {';
 const start=source.indexOf(marker),end=source.lastIndexOf('\n  }\n};');
 if(start<0||end<start||source.indexOf(marker,start+1)>=0)throw Error('single_current_catch_owner_required');
 const deps={json,isHttpError,v,AppError,DomainError,ProviderActionError,ProviderHttpError,providerApiError,classifyFailure,logDiagnostic:async()=>{}};
 return new AsyncFunction(owner==='central'?'error':'cause','request','path','source',...Object.keys(deps),source.slice(start+marker.length,end));
}
async function invoke(owner:'central'|'insights',state:'before'|'candidate',cause:unknown,aborted=false){
 const fn=await compile(owner,state),controller=new AbortController();if(aborted)controller.abort();
 const deps={json,isHttpError,v,AppError,DomainError,ProviderActionError,ProviderHttpError,providerApiError,classifyFailure,logDiagnostic:async()=>{}};
 const response=await fn(cause,{signal:controller.signal},['library'],'tmdb',...Object.values(deps));
 return{status:response.status,headers:[...response.headers.entries()],text:await response.text()};
}
const kit=(status:number)=>{try{error(status,'Controlled expected request message.');}catch(cause){expect(isHttpError(cause,status)).toBe(true);return cause;}};
// Authored classification controls only; these are not actual data/provider or HTTP evidence.
test('trusted installed Kit errors preserve400404503 status and curated JSON while existing fallback is characterized',async()=>{
 for(const owner of ['central','insights']as const)for(const status of[400,404,503]){
  const cause=kit(status),before=await invoke(owner,'before',cause),after=await invoke(owner,'candidate',cause);
  expect(before.status).toBe(503);expect(after.status).toBe(status);
  expect(JSON.parse(after.text)).toEqual({error:'Controlled expected request message.',code:'request_failed'});
 }
});
test('unknown errors, native OperationError and status-shaped objects keep exact redacted fallback',async()=>{
 for(const owner of ['central','insights']as const)for(const cause of[new Error('controlled-secret-must-not-leak'),new DOMException('controlled-secret-must-not-leak','OperationError'),{status:404,body:{message:'controlled-secret-must-not-leak'}}]){
  const before=await invoke(owner,'before',cause),after=await invoke(owner,'candidate',cause);
  expect(after).toEqual(before);expect(after.status).toBe(503);expect(after.text).not.toContain('controlled-secret-must-not-leak');
 }
});
test('existing AppErrorDomainErrorvalidationprovider classification and cancelled relay response remain exact',async()=>{
 let invalid:unknown;try{v.parse(v.string(),42);}catch(cause){invalid=cause;}
 const causes=[new AppError(403,'Controlled feature denial.','feature_disabled'),new DomainError('Controlled missing work.',404,'not_found'),invalid,new ProviderActionError('Controlled permission.','permission'),new ProviderHttpError(401,null,{error:'controlled-secret-must-not-leak'}),new ProviderHttpError(429,60)];
 for(const cause of causes)expect(await invoke('central','candidate',cause)).toEqual(await invoke('central','before',cause));
 const aborted=new DOMException('Controlled abort.','AbortError'),before=await invoke('central','before',aborted,true),after=await invoke('central','candidate',aborted,true);
 expect(after).toEqual(before);expect(after.status).toBe(499);
 for(const owner of ['central','insights']as const){const cause=new AppError(403,'Controlled feature denial.','feature_disabled');expect(await invoke(owner,'candidate',cause)).toEqual(await invoke(owner,'before',cause));}
});
