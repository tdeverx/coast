# UPP-01 native actual workload admission — keep current

Executed existing actual-admin default `profileInsightsData({})` and one actual show-details read, unchanged live adapters and native compiled Svelte SSR renderers. No browser, fictional preview data, generated workload, budget/cap, spatial index, worker or source change was introduced. Final run `41171f06-56ac-4e83-b480-762c18e6a15e` passed33checks; `actual-continuation.json` is the final receipt.

The native profile payload contains16dated activity days/56watches,7displayed genre rows/163genre credits, and one rating. Native genre admission already aggregates the tail into the truthful `Other` row; this probe preserves that returned order and credit total. Genre credits are not disjoint watched-title counts. Native activity bucketing produces15UTC buckets while retaining56watches. Rating admission retains all ten half-star bins, including zero-count bins. Complete payload/model/ordered-row/label/series digests preserve private identities and labels without storing them.

| Actual model | Style | Rows / selection identities | SSR ChartMarks | Separate SSR legend rows | Exact value total |
| --- | --- | ---: | ---: | ---: | ---: |
| Native profile activity |2B |15 |15 |0 |56watches |
| Native profile movie/episode mix |3A |2 |6 |2 |56watches |
| Native profile genre credits |3A |7 |21 |7 |163credits |
| Native profile rating bins |2B |10 |10 |0 |1rating |
| Default bar adapter over unchanged actual genre rows |2A |7 |7 |0 |163credits |
| Native show season targets |11A |61 |61 |0 |0completed; capacity unknown |

The2A row is direct admission through the existing `barModel` default `axis=false`, using unchanged actual native genre rows, not a claim that a currently mounted caller uses2A. Current native profile consumers request2B. The61season rows come from the actual show with most retained seasons, through `detailsData` → `mediaOverviewPanels`; its native completion fields are zero and capacity fields unknown. The probe preserves those facts rather than inventing a denominator or claiming positive progress coverage.

Exact native mark index order is asserted.3A emits three ordered ChartMark loops across the wide slices, wide legend and compact responsive slices, plus a separate compact HTML legend. Counts include both responsive markup variants, not merely currently visible browser marks. Unique selection identities remain exactly the row count. Native renderers leave their model inputs unchanged. SSR elapsed/heap observations are retained as server-process observations only; no browser long-task, frame cost or retained-heap conclusion follows.

The first run correctly captured the complete native query payload, totals/order and15-mark activity render, then failed because instrumentation expected one3Amark per row. A second expectation accounted for wide slice/legend loops but missed the compact responsive loop. `first-attempt.json`, `second-attempt.json`, `probe.ts` and `probe-continuation.second-attempt.ts.txt` retain those instrumentation attempts. The final continuation uses exact current source loop semantics, fixes the observation clock, verifies the full actual payload digest against the first run and reuses its already verified activity render rather than repeating it. No alternative algorithm or workload was sought.

All three marker-owned copies were dropped and confirmed absent. Native reads used the exclusive reserved connection with READ ONLY defaults/repeatable-read defaults and30s statement/5s lock budgets; existing native owner transactions retain their own snapshots. External fetch was forbidden and stayed zero. Ten production query/adapter/renderer source hashes were identical before/after. Preflight imported native queries/adapters and compiled/imported native SSR components outside the database copy. Final wrapper records prelaunch probe SHA `968fa9955701c2d52ad27063446a9b2c4e0619f799840218c16c3f1fc222da1e`.

**Disposition: keep current.** These actual native models use linear bar/distribution/target families; no packed-bubble/isotype/flow model was exercised or found in their native outputs. This observed workload does not justify the original conditional spatial-index or worker alternative. Root owns any signed-in browser trace. A universal family input/error/mark budget remains unselected; no arbitrary limit or broader repair acceptance is inferred from this finite read-only measurement.
