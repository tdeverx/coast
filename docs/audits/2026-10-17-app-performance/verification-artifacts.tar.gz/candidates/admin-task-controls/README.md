# PJ-15: bounded command contract obstruction

Status: **backlog; not implemented or verified**. This private proposal stops at the explicit contract gate. No runtime, Tasks read query/index, UI, original database, worker or provider transport was changed. No actual-data mutation/performance run was performed, so no latency, memory or round-trip improvement is claimed.

The proposed method is the existing PJ-15 prescription: select at most 100 IDs in `(created_at,id)` order per chunk, retain canonical cancel/retry/promote calls, stop at a finite command budget, and continue explicitly. `selection.sql` shows the one bounded selection candidate. It is deliberately not wired into a route: its required initial-target relation has no existing authoritative owner.

## Current contract, verified from source

- `queue/index.ts:602-620` admits admin, selects all IDs once under current task-generation and instance predicates, then performs serial canonical per-job calls. The selected IDs freeze membership at that statement snapshot. State, scope or account-generation changes after that snapshot do not reselect membership.
- The only success response is `{updated,skipped}` after every selected ID has been attempted. Every successful canonical call increments updated, even an already manual promotion. Only AppError 409 increments skipped. Other failures escape immediately after any earlier independent commits; there is no failed count or recovery token today.
- `api/queue.server.ts:11-14` accepts only kind, optional instance and action. `JobSchedule.svelte:57-63` awaits that response and reports it as complete. No continuation/progress admission exists.
- Cancel transactionally resolves each notification and leaves running jobs untouched. Retry takes the maintenance advisory lock per job, checks benchmark/active conflicts and preserves retry-credit rules. Promote preserves retry/service gates and calls in-memory request priority inside its existing transaction callback. These calls cannot be replaced with a broad UPDATE.

## Concrete obstruction

For an admitted initial set of 101 successful pending cancel targets and a 100-attempt budget, the native success result is `{updated:101,skipped:0}`. Returning after one chunk with `{updated:100,skipped:0}` silently acknowledges incomplete work. Returning a continuation changes the existing response/UI contract. Waiting internally for all chunks preserves completion but removes the finite command-work budget. Rolling all work into one transaction changes existing per-job commit/error and side-effect behavior and still leaves unbounded transaction work.

An upper `(created_at,id)` boundary alone does not freeze original membership: an existing failed job can become pending below the boundary after initial admission, or an existing obsolete-generation row can become current after reconnect; repeated live predicate evaluation captures it although the native initial ID set excludes it. Conversely, reapplying current-generation selection after reconnect drops initially selected IDs that the native code would still attempt. Persisting only the generation boundary therefore also changes behavior. The proposed selection requires an immutable admitted-ID relation (or retained database snapshot), not merely the latest cursor plus a generation token.

After a committed chunk loses its HTTP acknowledgement, replaying IDs is not generally equivalent: cancel now reports skips; retry can now conflict with its own newly active work; promotion can still report updated. Exact cumulative updated/skipped/failed accounting requires an agreed command identity, receipt/replay rule and storage lifetime. No such owner exists in the current route. Adding it is the durable-command policy explicitly excluded from this task without review.

## Required decision before execution

Approve a concrete continuation/receipt and frozen-membership ownership contract, or retain this finding in backlog. This is a contract failure of the original prescription under the requested unchanged complete-response semantics, not a lack of naturally active workload. Actual admin-owned retained rows on a tagged actual-data copy could supply controlled eligible states once that decision exists; they cannot resolve an undefined acknowledgement/recovery contract. Native/candidate exact-result, generation/race, side-effect and bounds execution must happen before any verified handoff. This artifact is **not** that handoff.
