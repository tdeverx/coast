-- Private PJ-15 candidate shape, NOT executable against the application schema.
-- admitted_task_targets is a REQUIRED immutable initial-ID relation; it does not
-- exist today. Inventing its owner/receipt/recovery policy is the blocking decision.
-- Do not substitute current outbox state/generation predicates: that changes the
-- native statement-snapshot target set when states or account generations race.
select id, created_at
from admitted_task_targets
where command_id = :command_id
  and (:after_created_at is null
    or (created_at, id) > (:after_created_at, :after_id))
order by created_at, id
limit 100;

-- Each returned ID must still use the unchanged canonical per-job command.
-- A finite attempt/time budget needs explicit continuation and a replay-safe
-- cumulative receipt before this can replace updateTaskActions.
