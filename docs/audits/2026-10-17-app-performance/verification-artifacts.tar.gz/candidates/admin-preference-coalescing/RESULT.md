# FRT-03 equivalent pending preferences: rejected, default retained

One original-method candidate shares only adjacent equivalent pending deliveries within the same client/actor scope. Each caller still has a separate serialized acknowledgement/refresh. It does not reuse a generic pending map, and A→B→A retains the last A. No production source changed.

Preflight compiled candidate/harness/wrapper, imported the actual full API module and froze exact source/input identities before creating a marker-owned actual-data copy. The finite native suite used the existing actual admin, exact route promise chain and actual shared client method bodies, native full API dispatch and native updateProfile. Response objects were native, never fabricated; external fetch attempts were zero. Kit refresh dependency selection was exact extracted code; callbacks read native settings rather than mounting a new browser.

Stable adjacent duplicates match all caller results, full settings/effects, ordered refreshes/invalidations and final month preference. Native API calls2→1 and ORM statements4→2, with both caller refreshes retained. A→B→A matches all outcomes with3calls/6statements and final month in both versions. Local samples remain observations only.

The required native failure boundary rejects the method. A temporary native PostgreSQL trigger fails the first preference write once. DEFAULT returns actual503 to caller1, then its existing catch permits caller2 to invoke the actual API independently: caller2 succeeds, final period=month and one refresh occurs. Candidate shares the failed delivery: both callers receive503, final period remains all and no refresh occurs. Complete settings/effect digests differ. This changes meaningful independent recovery/acknowledgement behavior despite lower query counts.

Stop here. Retain the current ordered promise chain and return this method to the failed-method backlog. No alternate approach or extra scenarios were explored after failure. No new dependency, provider reply, user/catalogue identity, normal-data write, commit or remote delivery occurred.

Outer rollback restored compared copy state; wrapper verified exact ownership marker, dropped the copy, confirmed absence and removed private runtime files. Source database untouched, pool closed. Source/private pins rechecked unchanged after execution. actual.json is the finite receipt; plan/preflight/candidate/default chain/probe/wrapper/run and manifest preserve reproducibility.
