/** One client scope; serialize every acknowledgement/refresh while sharing only pending adjacent delivery. */
export function createPreferenceWrites(
  deliver:(path:string,body:unknown)=>Promise<unknown>,
  acknowledge:()=>Promise<void>
) {
  let writes=Promise.resolve<unknown>(undefined);
  let pending:{key:string;delivery:Promise<unknown>}|undefined;
  return (patch:Record<string,unknown>,scope:string)=>{
    const key=JSON.stringify([scope,patch]);
    let entry=pending?.key===key?pending:undefined;
    if(!entry){
      entry={key,delivery:Promise.resolve<unknown>(undefined)};
      const current=entry;
      current.delivery=writes.catch(()=>undefined).then(()=>{
        if(pending===current)pending=undefined;
        return deliver('profile',{action:'preferences',...patch});
      });
      pending=current;
    }
    const delivery=entry.delivery;
    writes=writes.catch(()=>undefined).then(()=>delivery).then(async result=>{
      await acknowledge();return result;
    });
    return writes;
  };
}
