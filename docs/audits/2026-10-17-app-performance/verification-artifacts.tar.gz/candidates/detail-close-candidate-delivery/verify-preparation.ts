import {createHash} from 'node:crypto';
import {parse} from '/Users/admin/Documents/ChatGPT/coast-new/node_modules/svelte/compiler/index.js';
const folder='/private/tmp/coast-detail-close-candidate-delivery-next',root='/Users/admin/Documents/ChatGPT/coast-new';
const sha=(text:string)=>createHash('sha256').update(text).digest('hex'),transpiler=new Bun.Transpiler({loader:'ts'}),report:any={status:'running',scope:'Syntax/source-pin preparation only; no compiler code generation, Bun.build, module imports from app/test, test execution, server, browser or database.',checks:[]};
try{
 const expected=JSON.parse(await Bun.file(folder+'/source-pins.json').text());
 for(const[path,hash]of Object.entries(expected))if(sha(await Bun.file(root+'/'+path).text())!==hash)throw Error('current_source_pin_changed');
 report.checks.push({kind:'current_source_pins',count:Object.keys(expected).length,passed:true});
 const manifest=JSON.parse(await Bun.file(folder+'/candidate-manifest.json').text());
 for(const record of Object.values(manifest.sources) as any[]){const text=await Bun.file(folder+'/'+record.candidateFile).text();if(sha(text)!==record.candidate)throw Error('candidate_hash_changed');parse(text,{modern:true});}
 report.checks.push({kind:'candidate_svelte_parse_only',count:2,passed:true});
 const entry=await Bun.file(folder+'/serve.ts').text();transpiler.transformSync(entry);report.entrySha256=sha(entry);
 const marker='const modules:Record<string,{source:string;svelte?:boolean;runes?:boolean}>=';
 const start=entry.indexOf(marker)+marker.length,end=entry.indexOf('\nconst aliases:',start);
 if(start<marker.length||end<start)throw Error('review_exact_fixture_module_literal');
 const literal=entry.slice(start,end).trim().replace(/;$/,'');
 // This trusted preparation-only literal constructs strings. It does not import
 // or execute any inner fixture module, controller, request or browser script.
 const modules=new Function('root','return ('+literal+');')(root);
 let svelte=0,javascript=0;
 for(const mod of Object.values(modules) as {source:string;svelte?:boolean}[]){if(mod.svelte){parse(mod.source,{modern:true});svelte++;}else{transpiler.transformSync(mod.source);javascript++;}}
 const list=modules.controls.source.match(/const cases=(\[[\s\S]*?\]);<\/script>/)?.[1];if(!list)throw Error('review_control_list_literal');const controls=new Function('return ('+list+');')();
 if(controls.length!==17||new Set(controls.map((c:any)=>c[0])).size!==17)throw Error('exact_seventeen_controls');
 report.checks.push({kind:'entry_and_inner_module_syntax_only',entry:1,svelteModules:svelte,javascriptModules:javascript,controls:controls.length,passed:true});
 for(const file of ['detail-panel-close-owner.test.ts.proposed','dialog-geometry.test.ts.proposed'])transpiler.transformSync(await Bun.file(folder+'/'+file).text());
 report.checks.push({kind:'proposed_maintained_test_typescript_parse_only',count:2,passed:true});
 report.status='passed_preparation_only';
}catch(error){report.status='failed_preparation_only';report.failure=error instanceof Error?error.message:'unknown';process.exitCode=1;}
await Bun.write(folder+'/preparation-checks.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));
