import {createHash} from 'node:crypto';
import {readFile,writeFile} from 'node:fs/promises';
import {isDeepStrictEqual} from 'node:util';
const root='/Users/admin/Documents/ChatGPT/coast-new',dir=root+'/docs/audits/2026-10-17-app-performance/candidates/admin-received-recommendations',out=process.argv[2];
const hash=(v:any)=>createHash('sha256').update(typeof v==='string'?v:JSON.stringify(v)).digest('hex');
const assert=(v:any,s:string)=>{if(!v)throw Error(s)};
const url=new URL(process.env.DATABASE_URL!);assert(process.env.COAST_AUDIT_REAL_DATA_CLONE==='1'&&url.hostname==='127.0.0.1'&&url.port==='55432'&&url.pathname==='/'+(await readFile('/private/tmp/coast-app-fixes-clone-name','utf8')).trim(),'clone_guard');
const pool=new Bun.SQL(url.href,{max:1,idleTimeout:0,connection:{jit:'off',statement_timeout:'30000',lock_timeout:'5000'}});
const report:any={status:'running',boundary:'Controlled rollback scenarios using existing admin, actual peers and actual catalogue only; no natural-usage claim. No external transport or normal database writes.',cases:[]};
let capture:any[]|null=null,external=0;globalThis.fetch=(async()=>{external++;throw Error('external_transport_forbidden')}) as any;
const {BunSQLPreparedQuery}=await import(root+'/node_modules/drizzle-orm/bun-sql/session.js');
for(const name of ['execute','all']){const old=BunSQLPreparedQuery.prototype[name];BunSQLPreparedQuery.prototype[name]=async function(...args:any[]){const start=performance.now(),v=await old.apply(this,args);if(capture&& !/^set /i.test(this.queryString))capture.push({query:this.queryString,params:[...this.params],rows:Array.from(v).length,bytes:Buffer.byteLength(JSON.stringify(v)),ms:performance.now()-start});return v;}}
const quote=(v:string)=>'"'+v.replaceAll('"','""')+'"';
async function census(){const tables=await pool`select schemaname,tablename from pg_tables where schemaname in ('public','drizzle') order by 1,2`;const rows=[];for(const t of tables){const [r]=await pool.unsafe(`select count(*)::int as rows,encode(sha256(convert_to(coalesce(string_agg(h,'' order by h),''),'UTF8')),'hex') as digest from (select encode(sha256(convert_to(to_jsonb(t)::text,'UTF8')),'hex') h from ${quote(t.schemaname)}.${quote(t.tablename)} t) q`);rows.push({table:t.schemaname+'.'+t.tablename,...r})}return {tables:rows.length,rows:rows.reduce((s,r)=>s+r.rows,0),hash:hash(rows)}}
try{
 report.sourcePins=Object.fromEntries(await Promise.all(['progress.before.ts.txt','progress.baseline.ts','progress.candidate.ts','collection.before.ts.txt','collection.candidate.ts'].map(async f=>[f,hash(await readFile(dir+'/'+f,'utf8'))])));
 const before=await census();report.before=before;
 const stop=Symbol();try{await pool.begin(async tx=>{
  (globalThis as any)[Symbol.for('coast.database.pool')]=tx;
  const [other]=await tx`select count(*)::int n from pg_stat_activity where datname=current_database() and pid<>pg_backend_pid()`;assert(other.n===0,'exclusive_clone_required');
  report.settings=(await tx`select current_setting('jit') jit,current_setting('work_mem') work_mem,current_setting('recursive_worktable_factor') recursive_worktable_factor`)[0];
  const [admin]=await tx`select id from users where role='admin' and not disabled order by created_at,id limit 1`;assert(admin,'actual_admin_required');
  const peers=await tx`select id from users where id<>${admin.id} and not disabled order by created_at,id limit 3`;assert(peers.length>=2,'two_actual_peers_required');report.actualPeerCount=peers.length;
  const {getDb}=await import(root+'/src/lib/server/db/index.ts');const db=getDb();const {BunSQLTransaction}=await import(root+'/node_modules/drizzle-orm/bun-sql/session.js');const held=new BunSQLTransaction((db as any).dialect,(db as any).session,(db as any).session.schema);db.transaction=held.transaction.bind(held);
  const baseline=await import(dir+'/progress.baseline.ts'),candidate=await import(dir+'/progress.candidate.ts');
  const {PgDialect}=await import(root+'/node_modules/drizzle-orm/pg-core/dialect.js');
  const oldCTE=await import(dir+'/collection.baseline.ts'),newCTE=await import(dir+'/collection.candidate.ts');
  const dialect=new PgDialect();for(const scope of ['all','personal',[],[admin.id]])assert(isDeepStrictEqual(dialect.sqlToQuery(oldCTE.collectionCTE(admin.id,admin.id,'all',scope as any)),dialect.sqlToQuery(newCTE.collectionCTE(admin.id,admin.id,'all',scope as any))),'legacy_cte_bytes_bindings_changed');report.legacyCTEIdentical=true;
  const run=async(label:string,options:any,viewer=admin.id)=>{
   const results=[];const measures=[];
   for(const owner of [baseline,candidate]){capture=[];const started=performance.now();let value:any;try{value=await owner.progressData(admin.id,{view:'recommendations',...options},viewer)}catch(e:any){value={error:e.status??e.statusCode??null,message:e.message}}const calls=capture;capture=null;results.push(value);let plan:any;
   if(label==='controlled-screen-all-1'||label==='controlled-screen-available-1'){const q=calls.find(c=>c.query.includes('social_recommendations'));if(q){const [ex]=await tx.unsafe('explain(analyze,buffers,format json) '+q.query,q.params);const p=ex['QUERY PLAN'][0];const nodes=(n:any):any[]=>[n,...(n.Plans??[]).flatMap(nodes)];const ns=nodes(p.Plan);plan={planningMs:p['Planning Time'],executionMs:p['Execution Time'],rootRows:p.Plan['Actual Rows'],rootSharedHitBlocks:p.Plan['Shared Hit Blocks'],rootSharedReadBlocks:p.Plan['Shared Read Blocks'],rootTempReadBlocks:p.Plan['Temp Read Blocks'],rootTempWrittenBlocks:p.Plan['Temp Written Blocks'],summedNodeRowsTimesLoops:ns.reduce((s,n)=>s+(n['Actual Rows']??0)*(n['Actual Loops']??0),0)};}}
   measures.push({plan,ms:performance.now()-started,statements:calls.length,rows:calls.reduce((s,c)=>s+c.rows,0),bytes:calls.reduce((s,c)=>s+c.bytes,0),plannerRows:calls.find(c=>c.query.includes('social_recommendations'))?.rows,plannerBytes:calls.find(c=>c.query.includes('social_recommendations'))?.bytes,assessmentStatements:calls.filter(c=>c.query.includes('with recursive')).length,sqlBytes:calls.reduce((s,c)=>s+Buffer.byteLength(c.query),0),boundValues:calls.reduce((s,c)=>s+c.params.length,0)});}
   assert(isDeepStrictEqual(results[0],results[1]),'native_complete_output_mismatch_'+label);report.cases.push({label,options,exact:true,digest:hash(results[0]),total:results[0].total,page:results[0].page,pages:results[0].pages,visible:results[0].items?.length,error:results[0].error??null,baseline:measures[0],candidate:measures[1]});await writeFile(out,JSON.stringify(report,null,2));return results[0];
  };
  await run('natural-admin',{category:'screen',scope:'all'});
  for(const p of peers){await tx`insert into friendships(user_a,user_b,requested_by,state) values(least(${admin.id}::uuid,${p.id}::uuid),greatest(${admin.id}::uuid,${p.id}::uuid),${admin.id},'accepted') on conflict(user_a,user_b) do update set state='accepted'`;}
  await tx`update system_settings set value=value || '{"experimentalMusic":true,"experimentalGaming":true,"experimentalBooks":true,"experimentalComics":true,"features":{"screen":true,"social":true}}'::jsonb where key='coast'`;
  await tx`update users set settings=settings || '{"features":{"screen":true,"music":true,"game":true,"book":true,"comic":true,"social":true}}'::jsonb where id=${admin.id}`;
  const works=await tx`select id,category from (select id,category from (select id,category,kind,row_number() over(partition by kind order by id) n from works where kind in ('movie','show','season','collection','album','game','track','book','comic','audiobook')) w where n<=case when kind in ('show','season','collection','album') then 2 else 125 end union select id,category from (select distinct w.id,w.category from works w join availability a on a.media_id=w.id where a.user_id=${admin.id} and a.state='available' order by w.id limit 125) positive) selected order by category,id`;
  report.controlledWorks=works.length;assert(works.filter(w=>w.category==='movie').length===0,'category_sanity');
  for(const w of works.slice(0,2))for(const p of peers.slice(0,2))await tx`insert into social_recommendations(sender_id,recipient_id,work_id,created_at) values(${p.id},${admin.id},${w.id},'2026-01-01T00:00:00Z') on conflict(sender_id,recipient_id,work_id) where state='pending' do nothing`;
  await run('controlled-small',{category:works[0].category==='book'||works[0].category==='comic'?'reading':works[0].category,scope:'all'});
  for(const w of works)for(const p of peers.slice(0,2))await tx`insert into social_recommendations(sender_id,recipient_id,work_id,created_at) values(${p.id},${admin.id},${w.id},'2026-01-01T00:00:00Z') on conflict(sender_id,recipient_id,work_id) where state='pending' do nothing`;
  report.pending=(await tx`select count(*)::int rows,count(distinct work_id)::int works from social_recommendations where recipient_id=${admin.id} and state='pending'`)[0];
  for(const category of ['screen','music','game','reading'])for(const scope of ['all','available'])for(const page of [1,2,999])await run('controlled-'+category+'-'+scope+'-'+page,{category,scope,page});
  await run('private-recipient',{category:'screen'},peers[0].id);
  await tx`update friendships set state='removed' where user_a=least(${admin.id}::uuid,${peers[0].id}::uuid) and user_b=greatest(${admin.id}::uuid,${peers[0].id}::uuid)`;
  await run('removed-sender',{category:'screen',scope:'all'});
  await tx`update users set disabled=true where id=${peers[1].id}`;
  await run('disabled-sender',{category:'screen',scope:'all'});
  await tx`update users set disabled=false where id=${peers[1].id}`;
  await tx`update friendships set state='accepted' where user_a=least(${admin.id}::uuid,${peers[0].id}::uuid) and user_b=greatest(${admin.id}::uuid,${peers[0].id}::uuid)`;
  const {respondRecommendation}=await import(root+'/src/lib/social/service.server.ts');
  const actions=await tx`select r.id from social_recommendations r join works w on w.id=r.work_id where r.recipient_id=${admin.id} and r.state='pending' and w.kind='movie' order by r.id limit 2`;assert(actions.length===2,'native_admin_action_rows');
  report.actions=[];for(let n=0;n<2;n++){const action=n===0?'save':'dismiss';const result=await respondRecommendation(admin.id,actions[n].id,{action});assert(result.state===(n===0?'saved':'dismissed'),'native_action_state');report.actions.push({action,state:result.state});await run('after-'+action,{category:'screen',scope:'all'});}
  await tx`update users set settings=jsonb_set(settings,'{features,screen}','false'::jsonb) where id=${admin.id}`;await run('disabled-category',{category:'screen',scope:'all'});await tx`update users set settings=jsonb_set(settings,'{features,screen}','true'::jsonb) where id=${admin.id}`;
  await tx`update provider_connections set status='disconnected' where user_id=${admin.id}`;
  await run('absent-connected-sources',{category:'screen',scope:'available'});
  throw stop;
 });}catch(e){if(e!==stop)throw e;}
 report.after=await census();assert(isDeepStrictEqual(before,report.after),'all_table_restoration_mismatch');assert(external===0,'external_transport');report.externalCalls=external;report.status='passed';
}catch(e:any){report.status='failed';report.failureCode=e.message?.match(/^[a-zA-Z0-9_-]+$/)?e.message:'private_log_review_required';console.error(e)}finally{await pool.close();await writeFile(out,JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({status:report.status,failureCode:report.failureCode}));}
