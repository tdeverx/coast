# DATA-06 received recommendations — controlled actual-data verification

Rejected for this pass; retain the default in backlog. `applied=false`. Neither runtime owner nor the SQL-seed extension was edited.

The prescribed candidate joins authorization, shared Collection availability, complete per-work grouping, exact totals and clamped page selection in PostgreSQL. Sender names and recommendation IDs are returned only for selected works. Its narrow trusted SQL seed extension preserves old all/personal/explicit-ID compiled SQL and bindings byte for byte and applies the same requested-root ancestor/descendant closure. Available-scope count still assesses the complete eligible root set inside PostgreSQL; it is not limited to 60 roots. Card hydration remains the selected page.

The native baseline and archived candidate matched complete DTOs in 33 controlled pairs, using the real admin as actor/viewer/recipient, actual catalogue identities, and existing peers as sender test data. The natural recipient had zero pending rows: that is a coverage gap, not a natural scalability result. Controlled temporary data supplied 511 actual works and 1,022 pending recommendations, including duplicate work recommendations from two real senders. Cases included all/available scopes, screen/music/game/reading, first/second/clamped pages, removed and disabled senders, recipient privacy, disabled category, disconnected sources and native admin Save/Dismiss. All temporary changes were rolled back. Both runs restored every one of 102 tables / 1,864,145 rows to fingerprint `9428397f6ad5bb35ab00dc685720984797592bea078e3e13300acf5dab9a07c7`; zero external calls occurred.

`actual.json` is semantic evidence. Its original timers include EXPLAIN work, and its initial baseline plan excludes the separate availability assessment. Those timing/plan comparisons are diagnostic only and must not be used as before/after resource evidence.

`resources.json` corrects those measurement boundaries on the same frozen candidate and corpus. Exactly three pairs ran: small all, large all (candidate first), large available. Native timers stop before EXPLAIN. Baseline source resources include both its aggregate and full eligibility assessment; candidate resources include its complete planner. No adverse sample was dropped.

| Source boundary | Baseline | Candidate |
| --- | ---: | ---: |
| Small all: transferred rows / bytes | 2 / 329 | 1 / 370 |
| Large all: transferred rows / bytes | 247 / 40,509 | 1 / 9,884 |
| Large available: transferred rows / bytes | 494 / 112,528 | 1 / 9,884 |
| Large all: source execution ms | 3.15 | 9.23 |
| Large available: source execution ms | 824.72 | 1042.22 |
| Large all: full native ms | 107.85 | 179.00 |
| Large available: full native ms | 979.46 | 1171.41 |
| Large available: summed source EXPLAIN execution ms | 1001.05 | 1423.02 |

Large all buffer hits were identical at 6,986. Large available summed source buffer hits were 438,939 versus 441,190, reads 29,048 versus 24,253, temp reads 11,863 versus 11,837 and temp writes 7,831 versus 7,805. Available statement bindings fell from 559 to 78. These are single descriptive samples and PostgreSQL resources. Small and large-available ran baseline first; large-all ran candidate first. Cache/order effects are not isolated, and no repeated-sample distribution, universal regression, production latency, heap, RSS or concurrent-load claim is made.

The transfer goal succeeds, but the observed source and native latency regression prevents a verified optimization handoff. Under the requested candidate-fails-to-backlog rule, no alternative design or follow-up optimization was attempted. All candidate modules, both probes and raw aggregate evidence remain reviewable here. `summary.json` freezes their hashes.

Final runtime source hashes are recorded in `summary.json` and `manifest.json`; each runtime file remains byte-identical to its archived before file. Both rejected initial measurement-boundary receipts remain in `summary.json` with their unmodified `actual.json` evidence.
