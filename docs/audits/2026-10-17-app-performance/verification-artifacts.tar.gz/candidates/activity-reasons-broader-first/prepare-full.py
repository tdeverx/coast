from pathlib import Path
import json,hashlib,difflib
folder=Path('/private/tmp/coast-scoped-activity-reasons-next')
root=Path('/Users/admin/Documents/ChatGPT/coast-new')
prior=Path('/private/tmp/coast-scoped-activity-workset-next')
sha=lambda b:hashlib.sha256(b if isinstance(b,bytes) else b.encode()).hexdigest()
writejson=lambda p,d:p.write_text(json.dumps(d,indent=2)+'\n')
pilot=(folder/'reasons-pilot-actual.ts').read_text(); oldfull=(prior/'workset-full-actual.ts').read_text()
pins=json.loads((folder/'pilot-source-pins.json').read_text())
for rel in ['src/lib/social/model.ts','node_modules/drizzle-orm/bun-sql/session.js']:
 pins[rel]=sha((root/rel).read_bytes())
assert all(sha((root/p).read_bytes())==h for p,h in pins.items())
writejson(folder/'full-source-pins.json',pins); ph=sha((folder/'full-source-pins.json').read_bytes())
for name in ['expected-full-coverage-labels.json','expected-full-census.json']:
 (folder/name).write_bytes((prior/name).read_bytes())
extra=[]
for relationship in ['progress','watchlist','lists','favourites']:extra.append({'kind':'full-relationship-filter','ownerRole':'prior-selected-most-events','relationship':relationship})
for owner in range(4):
 for friend in range(4):extra.append({'kind':'full-scoped-friend','ownerOrdinal':owner,'friendOrdinal':friend})
for owner in range(4):
 for scope in ['artist','artist-and-work','reading-group','reading-group-and-work']:extra.append({'kind':'full-cross-category-relationship','ownerOrdinal':owner,'scope':scope})
for owner in range(4):extra.append({'kind':'full-scoped-returned-cursor','ownerOrdinal':owner})
for owner in range(4):
 for role in ['ancestor-episode','ancestor-collection-member']:extra.append({'kind':'full-ancestor-child-root','ownerOrdinal':owner,'scope':role})
for mode in ['empty','duplicate']:extra.append({'kind':'full-relationship-explicit-ids','ownerRole':'prior-selected-most-events','mode':mode})
extra.append({'kind':'full-mixed-root-and-scopes','ownerOrdinal':0})
assert len(extra)==51
writejson(folder/'expected-full-additional-labels.json',extra); eh=sha((folder/'expected-full-additional-labels.json').read_bytes())
s=pilot.replace("/^\\/private\\/tmp\\/coast-activity-reasons-pilot-[a-z0-9-]+\\.json$/", "/^\\/private\\/tmp\\/coast-activity-reasons-full-once\\.json$/")
assert s!=pilot
s=s.replace("'private_aggregate_output_required');", "'private_aggregate_output_required');\nassert(!(await Bun.file(output).exists()),'fresh_once_output_required');",1)
s=s.replace("phase:'pilot_only'", "phase:'full'")
s=s.replace("Two actual scopes for one saved owner, four plans, no timing samples or fabricated data.", "The historical64actual contexts plus51helper-focused labels across4saved owners,28plans and no timing samples or fabricated data.")
s=s.replace("comparisons:[],plans:[],samples:[],progress:[]", "comparisons:[],coverageLabels:[],plans:[],samples:[],progress:[]")
s=s.replace("COAST_AUDIT_ACTIVITY_REASONS_LEASE==='1'", "COAST_AUDIT_ACTIVITY_REASONS_FULL_LEASE==='1'").replace("process.env.COAST_AUDIT_ACTIVITY_REASONS_PHASE==='pilot'", "process.env.COAST_AUDIT_ACTIVITY_REASONS_PHASE==='full'")
s=s.replace("explicit_root_reasons_pilot_lease_before_url_pool", "explicit_root_reasons_full_lease_before_url_pool").replace("reviewed_two_scope_pilot_only", "reviewed_full_phase_only")
s=s.replace("pilot-source-pins.json", "full-source-pins.json").replace('8aa30d6df43572832c698d181f6e892e833598158448a3f342feaa359b08b81a',ph)
contracts="const contracts=JSON.parse(contractBytes);"
s=s.replace(contracts,contracts+f"\n const labelBytes=await Bun.file(folder+'/expected-full-coverage-labels.json').text(),censusBytes=await Bun.file(folder+'/expected-full-census.json').text(),additionalLabelBytes=await Bun.file(folder+'/expected-full-additional-labels.json').text();assert(sha(labelBytes)==='c12fef059d0e1e0b5a39712ab647ba74801aa443a9df5467d39e92a5e9f22b2b'&&sha(censusBytes)==='0bef97163b167a6ea4d4f8b67ea5ef2e94f931a87e23d50497cbd22ac40adcd3'&&sha(additionalLabelBytes)==='{eh}','exact_historical_64_and_additional_51_label_contracts');const expectedLabels=JSON.parse(labelBytes),expectedCensus=JSON.parse(censusBytes),expectedAdditionalLabels=JSON.parse(additionalLabelBytes);report.workloadContracts={{historicalLabelsSha256:sha(labelBytes),historicalCensusSha256:sha(censusBytes),additionalLabelsSha256:sha(additionalLabelBytes)}};",1)
s=s.replace("const checkpoint=async(kind:string)=>{report.progress.push({ordinal:report.progress.length+1,kind,comparisons:report.comparisons.length,plans:report.plans.length});", "const checkpoint=async(kind:string,status?:string)=>{report.progress.push({ordinal:report.progress.length+1,kind,...(status?{status}:{}),comparisons:report.comparisons.length,labels:report.coverageLabels.length,plans:report.plans.length});")
start=s.index(' const owners=Array.from('); end=s.index(' const last=await settings();',start)
selectors=oldfull[oldfull.index(' const owners=Array.from('):oldfull.index(' const invoke=async(',oldfull.index(' const owners=Array.from('))]
compare=r''' const invoke=async(api:any,owner:string,options:any,ids?:string[])=>{const stats={ormStatements:0,ormRows:0,primaryCalls:0};captured=undefined;active=stats;let value:any;try{value=await withRequestConfig(()=>api.activityFeed(owner,options,ids));}finally{active=null;}assert(captured&&stats.primaryCalls===1,'one_complete_primary_captured');return{value,query:captured.compiled,primaryRows:captured.rows,stats};};
 const stable=(x:any):any=>Array.isArray(x)?x.map(stable):x&&typeof x==='object'?Object.fromEntries(Object.keys(x).sort().map(k=>[k,stable(x[k])])):x;
 const cache=new Map<string,any>(),queryPairs=new Map<string,any>(),initialPairs=new Map<string,any>(),showPairs=new Map<string,any>();
 const compare=async(label:any,owner:string,options:any={},ids?:string[])=>{
  const key=JSON.stringify(stable({owner,options,activityIdsMode:ids===undefined?'undefined':'explicit',ids:ids===undefined?null:ids})),prior=cache.get(key);
  if(prior){report.coverageLabels.push({...label,comparisonOrdinal:prior.ordinal,reusedIdenticalInput:true});await checkpoint(label.kind,'identical_input_reused');return prior;}
  report.stage={...label,side:'before'};await checkpoint(label.kind,'before_started');const b=await invoke(baseline,owner,options,ids);report.stage={...label,side:'candidate'};await checkpoint(label.kind,'candidate_started');const a=await invoke(candidate,owner,options,ids);
  assert(same(b.value,a.value),'complete_exported_feed_dto_changed');assert(same(b.primaryRows,a.primaryRows),'complete_primary_ordered_rows_changed');assert(same(b.query.params,a.query.params),'primary_parameters_changed');
  const helperActive=options.relationship!==undefined,scoped=!!(options.workId||options.artistId||options.readingGroupId)||ids!==undefined;
  if(helperActive)assert(b.query.sql.split('reasons as (').length===2&&b.query.sql.replace('reasons as (','reasons as materialized (')===a.query.sql,'exact_only_one_materialization_sql_delta');else assert(b.query.sql===a.query.sql,'helper_absent_sql_byte_identity');
  const ordinal=report.comparisons.length+1,row={ordinal,firstLabel:label,completeDtoEqual:true,orderedPrimaryRowsEqual:true,parametersEqual:true,scoped,helperActive,sqlContract:helperActive?'exact_one_materialization_keyword':'byte_identical_helper_absent',items:b.value.items.length,events:b.value.events.length,relationshipOnlyCards:b.value.items.filter((x:any)=>String(x.entryId).startsWith('relationship:')).length,unknownDates:b.value.events.filter((x:any)=>!x.dateKnown).length,groupedEvents:b.value.events.filter((x:any)=>x.count>1).length,reactionItems:b.value.items.filter((x:any)=>x.captionActivity?.myReaction!=null).length,hasMore:b.value.hasMore,hasNext:!!b.value.next,outputBytes:Buffer.byteLength(JSON.stringify(b.value)),before:b.stats,candidate:a.stats};
  report.comparisons.push(row);report.coverageLabels.push({...label,comparisonOrdinal:ordinal,reusedIdenticalInput:false});
  const summary={ordinal,events:b.value.events.length,next:b.value.next,queries:{before:b.query,candidate:a.query},owner,options,ids};cache.set(key,summary);await checkpoint(label.kind,'complete_pair_equal');return summary;
 };
 const remember=(name:string,result:any)=>{assert(!queryPairs.has(name),'unique_plan_context');queryPairs.set(name,result);};
'''
historic=oldfull[oldfull.index('  let selectedOwner='):oldfull.index(' assert(isDeepStrictEqual(report.cohorts,expectedCensus)')]
historic=historic.replace("const pair=await compare({kind:'prior-initial',ownerOrdinal},owner.id);", "const pair=await compare({kind:'prior-initial',ownerOrdinal},owner.id);initialPairs.set(owner.id,pair);")
historic=historic.replace("if(scope.role==='observed-normal-movie'||ownerOrdinal===0)remember(ownerOrdinal+':'+scope.role,pair);", "if(scope.role==='retained-active-show')showPairs.set(owner.id,pair);if(ownerOrdinal===0||scope.role==='retained-active-show'&&ownerOrdinal===3)remember(ownerOrdinal+':'+scope.role,pair);")
extra_code=r''' assert(same(report.cohorts,expectedCensus),'same_retained_actual_census');
 const labelsOnly=()=>report.coverageLabels.map(({comparisonOrdinal,reusedIdenticalInput,...label}:any)=>label);
 assert(same(labelsOnly(),expectedLabels)&&report.comparisons.length===64&&report.coverageLabels.length===64,'exact_historical_64_unique_pairs_and_labels');
 assert(report.comparisons.filter((x:any)=>!x.scoped).length===34&&report.comparisons.filter((x:any)=>x.helperActive).length===18,'historical_34_unscoped_and_18_helper_active_contracts');
 report.historicalCoverage={labels:64,uniquePairs:64,unscopedByteIdentical:34,scopedHelperAbsentByteIdentical:12,helperActiveOneKeyword:18};
 remember('unscoped-selected-initial',initialPairs.get(selectedOwner));
 const[episode]=await c`SELECT media_id AS id,show_id,season_id FROM episodes WHERE season_id=${season.id}::uuid ORDER BY season_number,episode_number,media_id LIMIT 1`;
 const[member]=await c`SELECT child_id AS id FROM media_relationships WHERE parent_id=${collection.id}::uuid AND kind='contains' ORDER BY position NULLS LAST,child_id LIMIT 1`;
 assert(episode&&member,'retained_ancestor_child_roots_available');
 const[ancestorCounts]=await c`SELECT count(*)::int AS matching_parent_states,count(*) FILTER(WHERE collected)::int AS collected_parent_states FROM tracking_state WHERE media_id IN (${episode.show_id}::uuid,${episode.season_id}::uuid,${collection.id}::uuid)`;
 const[privacy]=await c`SELECT count(*)::int AS owners,count(*) FILTER(WHERE coalesce(settings->'social'->>'audience','friends')='private')::int AS private_audience,count(*) FILTER(WHERE coalesce(settings->'social'->>'audience','friends')='friends')::int AS friends_audience,count(*) FILTER(WHERE coalesce(settings->'social'->>'audience','friends')='public')::int AS public_audience,count(*) FILTER(WHERE settings->'social'->'sections' IS NOT NULL)::int AS owners_with_section_preferences,count(*) FILTER(WHERE settings->'social'->'categories' IS NOT NULL)::int AS owners_with_category_preferences,count(*) FILTER(WHERE settings->'features'->>'social'='false')::int AS social_disabled_preferences FROM users WHERE NOT disabled`;
 report.additionalCohorts={episodeWithinLargestSeason:true,directMemberWithinLargestCollection:true,distinctChildRoots:episode.id!==member.id,directKnownParentStateCounts:ancestorCounts,actualSavedPrivacy:privacy,negativePolicyWithdrawalExercised:false};
 for(const relationship of['progress','watchlist','lists','favourites']){const pair=await compare({kind:'full-relationship-filter',ownerRole:'prior-selected-most-events',relationship},selectedOwner,{workId:show.id,relationship});if(relationship==='watchlist')remember('filtered-watchlist',pair);}
 for(const[ownerOrdinal,owner]of owners.entries())for(const[friendOrdinal,friend]of owners.entries()){const pair=await compare({kind:'full-scoped-friend',ownerOrdinal,friendOrdinal},owner.id,{category:'screen',workId:show.id,relationship:'all',friendId:friend.id});if(ownerOrdinal===0&&friendOrdinal===1)remember('0:friend-other',pair);}
 assert(artist&&group,'retained_artist_and_reading_group_required');
 for(const[ownerOrdinal,owner]of owners.entries())for(const spec of[
  {scope:'artist',options:{artistId:artist.artist_id,relationship:'all'}},
  {scope:'artist-and-work',options:{artistId:artist.artist_id,workId:artist.work_id,relationship:'all'}},
  {scope:'reading-group',options:{readingGroupId:group.group_id,relationship:'all'}},
  {scope:'reading-group-and-work',options:{readingGroupId:group.group_id,workId:group.work_id,relationship:'all'}}
 ]){const pair=await compare({kind:'full-cross-category-relationship',ownerOrdinal,scope:spec.scope},owner.id,spec.options);if(ownerOrdinal===0&&spec.scope==='artist')remember('0:artist-relationship',pair);if(ownerOrdinal===0&&spec.scope==='reading-group')remember('0:reading-group-relationship',pair);}
 for(const[ownerOrdinal,owner]of owners.entries()){
  const sourcePair=showPairs.get(owner.id);assert(sourcePair,'historical_show_pair_for_each_owner');
  assert(sourcePair.next,'actual_show_returned_cursor_required_for_each_owner');
  await compare({kind:'full-scoped-returned-cursor',ownerOrdinal},owner.id,{category:'screen',workId:show.id,relationship:'all',...sourcePair.next});
 }
 for(const[ownerOrdinal,owner]of owners.entries())for(const spec of[{scope:'ancestor-episode',id:episode.id},{scope:'ancestor-collection-member',id:member.id}]){const pair=await compare({kind:'full-ancestor-child-root',ownerOrdinal,scope:spec.scope},owner.id,{category:'screen',workId:spec.id,relationship:'all'});if(ownerOrdinal===0)remember('0:'+spec.scope,pair);}
 assert(reactionIds.length>0,'retained_reaction_identity_for_duplicate_shape');
 await compare({kind:'full-relationship-explicit-ids',ownerRole:'prior-selected-most-events',mode:'empty'},selectedOwner,{workId:show.id,relationship:'all'},[]);
 await compare({kind:'full-relationship-explicit-ids',ownerRole:'prior-selected-most-events',mode:'duplicate'},selectedOwner,{workId:show.id,relationship:'all'},[reactionIds[0],reactionIds[0]]);
 remember('mixed-roots',await compare({kind:'full-mixed-root-and-scopes',ownerOrdinal:0},owners[0].id,{workId:show.id,artistId:artist.artist_id,readingGroupId:group.group_id,relationship:'all'}));
 assert(report.coverageLabels.length===115&&same(labelsOnly().slice(64),expectedAdditionalLabels),'exact_115_historical_plus_additional_labels');
 report.completeLabels=report.coverageLabels.length;report.completeComparisons=report.comparisons.length;
 report.coverageSummary={helperActive:report.comparisons.filter((x:any)=>x.helperActive).length,helperAbsentScoped:report.comparisons.filter((x:any)=>!x.helperActive&&x.scoped).length,helperAbsentUnscoped:report.comparisons.filter((x:any)=>!x.helperActive&&!x.scoped).length,identicalInputLabelsReused:report.coverageLabels.filter((x:any)=>x.reusedIdenticalInput).length};
 assert(queryPairs.size===14,'exact_fourteen_representative_plan_contexts');
 for(const[name,pair]of queryPairs)for(const side of['before','candidate']){report.stage={kind:'plan',name,side};await checkpoint('plan','started');const q=pair.queries[side],raw=(await c.unsafe('EXPLAIN (ANALYZE,BUFFERS,FORMAT JSON) '+q.sql,q.params))[0]['QUERY PLAN'][0];report.plans.push({name,side,comparisonOrdinal:pair.ordinal,helperActive:pair.options.relationship!==undefined,sqlShapeSha256:sha(q.sql),parameterCount:q.params.length,planningMs:raw['Planning Time'],executionMs:raw['Execution Time'],plan:safePlan(raw.Plan)});await checkpoint('plan','completed');}
 report.readWorkComparison=[];
 for(const name of queryPairs.keys()){const before=report.plans.find((p:any)=>p.name===name&&p.side==='before').plan,candidate=report.plans.find((p:any)=>p.name===name&&p.side==='candidate').plan;const counters=(p:any)=>({sharedHits:p['Shared Hit Blocks']??0,sharedReads:p['Shared Read Blocks']??0,rootSharedVisits:(p['Shared Hit Blocks']??0)+(p['Shared Read Blocks']??0),tempReads:p['Temp Read Blocks']??0,tempWrites:p['Temp Written Blocks']??0});report.readWorkComparison.push({name,before:counters(before),candidate:counters(candidate)});}
 assert(report.plans.length===28&&report.samples.length===0,'exact_28_plans_zero_timing_samples');
'''
# artist/group selectors must remain in scope for the additional matrix.
historic=historic.replace("const[artist]=", "const[artist]=").replace("const[group]=", "const[group]=")
s=s[:start]+selectors+compare+historic+extra_code+s[end:]
old="report.status='passed_private_pilot_only';report.limits="
s=s.replace(old,"report.status='passed_private_broader_proof_only';delete report.stage;report.limits=")
s=s.replace("'Two saved scopes for one owner only, not full policy/friend/artist/group/allviewercoverage or normalHTTP/browser acceptance.'", "'Historical64 contexts plus51 helper-focused labels across4retained owners; actual duplicate requests may reuse a complete comparison and are counted separately. Not normalHTTP/browser or concurrent policy-withdrawal acceptance.'")
s=s.replace("Four descriptive singleplans, no timing samples/CPU/RSS/WAL.","Twenty-eight descriptive singleplans, no alternating timing samples/CPU/RSS/WAL.")
s=s.replace("No automatic adoption from equality or elapsed samples.","No automatic adoption from equality or descriptive plan elapsed times.")
s=s.replace("afterpilot", "afterfullproof")
(folder/'reasons-full-actual.ts').write_text(s)
diff=''.join(difflib.unified_diff(pilot.splitlines(True),s.splitlines(True),fromfile='passed/reasons-pilot-actual.ts',tofile='prepared/reasons-full-actual.ts'))
(folder/'pilot-to-full.patch').write_text(diff)
print(json.dumps({'probeSha256':sha(s),'pins':len(pins),'pinsSha256':ph,'additionalLabels':len(extra),'additionalLabelSha256':eh,'diffSha256':sha(diff)}))
