# Private broader reasons-materialization proof — prepared, not executed

The two-scope pilot is immutable. This package extends its exact source loader, policy metadata checks, reserved-session guards, output redaction and independent cleanup. Both variants use current main `queries.server.ts` SHA `29f1f31c…`; only its helper import points to original `relationships.server.ts` SHA `82aa52a2…` or the one-keyword `MATERIALIZED` candidate SHA `58047cfc…`. No query, shared relationship constant, card-head owner, endpoint, cache, cap, order, feature, dependency or schema edit is proposed here.

Preparation is not an execution lease. A fresh explicit parent lease and `COAST_AUDIT_ACTIVITY_REASONS_FULL_LEASE=1 COAST_AUDIT_ACTIVITY_REASONS_PHASE=full` are required. The designated original fix clone is the only permitted database. The output must be the previously absent `/private/tmp/coast-activity-reasons-full-once.json`. Failure stops the run; no retry, guard relaxation, automatic full phase or adoption follows.

## Sources and preflight

`full-source-pins.json` pins 31 current files: the pilot's 29 files, plus the imported social model and installed Bun/Drizzle prepared-query codec used by the capture. Query and both helper hashes are checked separately. `policy-function-contracts.json` is unchanged from the passed pilot. The three actual public functions must match source 0058 for body, identity/arguments/default/result, SQL language, STABLE volatility, security invoker, strict/leakproof/parallel/config/cost/row attributes. The 64-entry source journal was scanned offline for later redefinitions; 0058 and all later SQL files are pinned. The same 17 relevant public relations must be ordinary tables without RLS. These metadata gates run afresh before owner calls, not inferred from the earlier pilot.

Current main pins include adopted toast source/schema and API dependencies. The original designated clone is intentionally still before toast: its notification toast column must be absent after earlier rollback proofs. This proof reads only that column metadata; it never queries notification rows, adds the toast column, runs migration code or uses normal database credentials. This is a declared source/schema test boundary, not application compatibility behavior.

Use max-one pool, one reserved backend, explicit REPEATABLE READ READ ONLY, statement timeout 30 seconds, lock timeout one second, JIT off, work_mem 4 MB. Verify all settings and the same backend initially/finally. Zero other client backends is a preflight observation under the parent lease, not atomic exclusion. Global fetch throws, the isolated runner must have no credentials key before/after, and no secret projection is permitted. Full DTOs, rows, SQL and bindings stay in memory. Saved output contains only counts, request-shape labels, source hashes and structural/numerical plans without expressions, conditions, raw identities or private payloads.

## Workload

Retain the exact historical 42 + 16 + 6 = 64 labels and aggregate census. The first 64 must still be 64 unique complete comparisons, including 34 unscoped calls, 12 scoped calls without a relationship helper, and 18 helper-active calls. Current historical selectors and request options are reused, not the old runtime baseline module or old result payloads. Missing positive selectors or changed expected census stop the proof rather than silently reduce it.

These historical labels cover all four retained owners, self/other friend filters, initial/returned cursor, categories, periods, event kinds, unknown-date cursors, actual item roots, all/consumed relationships, actual reaction identities, the selected movie, largest 829-episode season, 23-member collection, active show, explicit empty/duplicate activity IDs, positive artist and reading-group selectors with/without work scope. The saved historical census has no dated multi-track listen batch or repeated dated-work listen; those gaps remain.

Add 51 declared labels:

| Labels | Actual-data request shape |
| ---: | --- |
| 4 | Remaining progress/watchlist/lists/favourites relationship filters on the retained active show, using the historically selected owner. |
| 16 | Four actual viewers × self/three other actual friend filters, same show and relationship=all. |
| 16 | Four actual viewers × artist, artist+work, reading group, reading group+work, all with relationship=all. |
| 4 | The exact returned cursor from each viewer's historical show+relationship result, retaining original scope and category. All four saved show results previously had next cursors; absence now stops. |
| 8 | Four viewers × an existing episode in the largest season and an existing direct member of the largest collection, with relationship=all. These exercise child roots/ancestor reason branches. |
| 2 | Explicit empty and duplicate actual reaction identities together with a show relationship scope. An empty activity-ID list does not imply an empty complete result because relationship fallback remains independent. |
| 1 | One viewer with actual show, artist and reading-group identities simultaneously; event scopes retain AND while target roots retain the existing UNION. |

Total declared labels: 115. Each distinct exact request executes both full owners, compares every returned DTO field and ordered complete primary row, and records next/hasMore plus cardinalities. Only literally identical request options and identity arrays may reuse a successful pair; counts for labels versus unique comparisons stay separate. Root child selectors could coincide naturally; no invented distinction or duplicate comparison count is claimed.

For **every** comparison, parameters must match. Helper-active SQL must differ by exactly one `reasons as (` → `reasons as materialized (` replacement. Helper-absent SQL must be byte-identical, including scoped calls and all 34 unscoped calls. Complete outputs still execute in those paths; source-shape equality is not substituted for results.

Record aggregate saved audience/section/category preferences and direct known-parent tracking/collected-state counts. These describe actual coverage, not manufactured policy changes. Zero positive visible music/reading/filter/ancestor outcomes remain gaps even if the real selector exists. No saved private/disabled/withdrawal configuration is invented or changed.

## Representative plans

Capture 14 before/candidate contexts, 28 EXPLAIN (ANALYZE, BUFFERS, FORMAT JSON) plans, no timing-sample loop:

1. Historically selected owner's unscoped initial feed.
2. Actual reaction identities without the relationship helper.
3. Owner zero's selected empty movie.
4. Owner zero's largest season.
5. Owner zero's largest collection.
6. Owner zero's active show.
7. Owner three's active show.
8. Owner zero's selected episode child root.
9. Owner zero's selected direct collection member root.
10. Owner zero's artist relationship scope.
11. Owner zero's reading-group relationship scope.
12. Selected owner's watchlist relationship filter.
13. Owner zero's other-friend show relationship scope.
14. Owner zero's simultaneous show/artist/group roots.

Plans use the exact captured compiled statement and bindings. Root Shared Hit + Read Blocks and root temporary-read/write counters are compared separately; descendant buffers are not summed. Structural nodes/actual rows×loops, reason-producer size, spool/sort/hash behavior and pushdown changes remain inspectable. Single-plan elapsed values are descriptive and may be affected by cache/order; there are no alternating samples or latency/CPU/physical-I/O claims.

The materialized producer is scoped but uncapped by page size: cost is O(the admitted relationship reason set), not O(60 cards). It can block useful friend/category/filter pushdown, increase memory/temporary work, or change planner paths on a larger artist/group/ancestor set. A large mean benefit does not erase an adverse family. Equality alone does not authorize adoption; the parent reviews per-family work, positive/empty coverage and remaining gaps first.

## Cleanup and retained evidence

Every safe progress checkpoint identifies only label/side/counts. On success or failure restore both capture hooks, global fetch and global pool binding, then independently attempt rollback, reserved release and pool close; cleanup failure marks the proof failed. Verify no key appeared. All owner work is in the read-only reserved transaction, with no DDL or domain DML. This proof does not perform an all-table hash census; the enforced READ ONLY boundary, source pins and cleanup define its restoration claim.

Preserve original pilot probe, plan, syntax, policy contracts, source manifest and the passed receipt byte-exact. Keep this broader probe/diff/protocol/preparation receipts separately. No repository edits, provider calls, browser/HTTP/auth acceptance, background job execution, schema/index changes, concurrent withdrawal proof, cache/model-quality claim or automatic production application is part of this package.
