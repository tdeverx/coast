# DATA-07 game metadata: safe variant structural guard

**Recommend the one-line candidate for root review.**214 checks pass across14 native DEFAULT/candidate scenarios. No runtime file was edited. The candidate source is `034e72426d23d1f4d9d194fe55c36942aea729bf5b28e50fedd55bc528b6d3f4`; the measured/default runtime remains `053d8dad52b931840d7acedbd4e3d0900dd501a387750f5c63d9bf8c550d1ddc`.

## Exact scope and authoritative timestamps

The existing `importIgdbMetadata` variant conflict update now executes only when `(parent_id,provider)` differs from the submitted structure. A matching parent/source preserves the existing relationship row and its last-structural-change timestamp. Different parent and source takeover still update normally. Native identities, advisory locks, recursive imports and parentKnown rules remain unchanged.

`games.updatedAt` and every work_features refresh are retained. The tempting equal-feature conflict guard is **contract-incompatible**, not a promised untested fix: `workTasteFeatures` chooses each feature key by `updated_at DESC,provider`. Refreshing an unchanged IGDB object can legitimately retake precedence from another stored provider object. The controlled source-precedence scenario proves both DEFAULT and candidate keep that behavior. No cache, schema, dependency, clock substitution or freshness policy was added.

## Actual input and finite controls

The owned actual-data copy contains1159 IGDB game identities,1158 IGDB feature rows and122 retained game variants.24 real linked canonical games were replayed using their retained metadata, actual provider identities and feature objects. Their retained parent links were included in the normalized input; embedded parent input deliberately omits that parent's own relation, matching the existing `parentKnown=false` contract. These inputs are **normalized canonical replay, not fresh or reconstructed upstream API responses**.

The finite controlled cases use real existing game identities and retained field/feature values: matching/repeated parent, changed parent, provider takeover, embedded ancestor preservation, unknown-parent preservation, known-absence own-provider removal, other-provider preservation, changed existing title/features, source freshness precedence, reattachment of the same retained IGDB identity through its real Steam alias, and conflicting real identities. Temporary relations/source rows were explicitly controlled state, not naturally observed provider assertions. No users or catalogue identities were fabricated. Native gameDetails used the actual admin only; the metadata writer itself has no actor/account-generation parameter.

## Native comparison and measured effect

All complete normalized canonical game/identity/parent/feature/work/private state, native import returns, actual-admin details and keyed taste-feature associations match. Only the deliberately changed update clocks are normalized: game/feature clocks are separately required to be fresh at invocation; an unchanged variant's clock intentionally stops advancing. Created dates, ordered identity payloads and every feature-array element/order remain intact. All global/admin revision deltas agree.

| Scenario | DEFAULT variant updates | Candidate variant updates | ORM statements DEFAULT/candidate |
| --- | ---: | ---: | ---: |
|24 retained canonical replays, including2 retained parent observations |2|0|258 /258|
| Controlled matching parent |1|0|19 /19|
| Controlled repeated matching parent,2 calls |2|0|38 /38|
| Embedded parent with retained ancestor |1|0|19 /19|
| Changed parent |1|1|19 /19|
| Provider takeover |1|1|19 /19|

The24-game replay still physically updates26 game rows and26 feature rows in both versions; recursive parents account for the extra2. Global tracking/social revisions each increase26 in both versions. Thus this is a small **variant tuple-write reduction**, not statement, game freshness, feature-write or revision elimination. Conflict admission/locking SQL still runs. Unknown/absent-parent controls preserve the native distinction, identity re-enrichment keeps the same real game UUID/private records, and the genuine changes remain applied. Conflicting identities fail through the native owner without canonical state change.

Single-run24-game elapsed samples are189.73→174.96ms and global WAL119752→119720 bytes. These are descriptive local observations, not a universal speed/WAL claim. Adverse samples remain in the receipt: embedded-parent elapsed7.15→7.22ms, changed-feature3.28→4.15ms, source-precedence3.24→9.87ms, and identity reattachment8.14→19.53ms. WAL can include background/full-page effects and the SQL guard itself retains conflict lock work. No repeated benchmark series was added.

## Harness correction, cleanup and limits

Source/dispatch and syntax preflight ran before database copies. The first native run stopped on a hash of Map iteration order in the embedded-parent control even though canonical state, returns, details and revisions matched. Its exact source/receipt remain in `probe.attempt-1.ts.txt` and `harness-attempt-1.json`. Root confirmed the native taste consumers use keyed `.get` and the query has no ORDER BY. The single correction sorts Map keys for comparison, preserves every feature-array order, and retains raw iteration/key-order diagnostics. The unchanged candidate then passed the complete intended matrix; no alternative was explored.

The pool is pinned to one connection before imports/TEMP setup. All controlled state exists only on an exact-marker owned copy; copy drop and absence, source clone unchanged and temporary runtime removal are proved. No provider transport, normal database/UI mutation or production source edit occurred. Fresh provider parsing/wire data, full provider worker/reconnect/publication behavior, concurrent importer contention, CPU/heap and production tails are not certified here. Existing tests for the shared owner remain the integrated gate owner's responsibility.
