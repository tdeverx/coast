import { getFeatureConfig } from '$lib/server/features';
import {statusesForUsers} from './status.server';
import {activityAction,workFriendFilters,workFriendOptions} from './model';
import {activityRelationships,relationshipEdges,relationshipReasons,relationshipEventFilter} from './relationships.server';
import {getDb} from '$lib/server/db';
import {sql} from 'drizzle-orm';
import * as v from 'valibot';
import {workCards} from '$lib/collection/query.server';
const uuid=v.pipe(v.string(),v.uuid());
export const feedOptionsSchema=v.object({category:v.optional(v.picklist(['all','screen','music','game','reading']),'all'),kind:v.optional(v.pipe(v.string(),v.maxLength(40)),'all'),friendId:v.optional(uuid),workId:v.optional(uuid),artistId:v.optional(uuid),readingGroupId:v.optional(uuid),relationship:v.optional(v.picklist(workFriendFilters)),beforeRelationship:v.optional(v.picklist(['true','false'])),beforeKnown:v.optional(v.picklist(['true','false'])),period:v.optional(v.picklist(['month','year','all']),'all'),before:v.optional(v.pipe(v.string(),v.isoTimestamp())),beforeId:v.optional(uuid)});
export async function activityFeed(userId:string,raw:unknown={},activityIds?:string[]) {
 if(activityIds)v.parse(v.pipe(v.array(uuid),v.maxLength(60)),activityIds);
 const o=v.parse(feedOptionsSchema,raw);
 if(o.relationship!==undefined)v.parse(v.literal(true),!!(o.workId||o.artistId||o.readingGroupId));
 const scoped=!!(o.workId||o.artistId||o.readingGroupId)||activityIds!==undefined;
 const activityScope=sql`and (${activityIds===undefined} or a.id in (${activityIds?.length?sql.join(activityIds.map(id=>sql`${id}::uuid`),sql`, `):sql`null::uuid`}))`;
 const workScope=o.workId?sql`and (a.work_id=${o.workId}::uuid or e.show_id=${o.workId}::uuid or e.season_id=${o.workId}::uuid or se.show_id=${o.workId}::uuid or exists(select 1 from media_relationships member where member.parent_id=${o.workId}::uuid and member.child_id in (a.work_id,e.show_id,e.season_id,se.show_id) and member.kind='contains'))`:sql``;
 const artistScope=o.artistId?sql`and exists(select 1 from music_credits credit where credit.work_id=a.work_id and credit.artist_id=${o.artistId}::uuid)`:sql``;
 const readingGroupScope=o.readingGroupId?sql`and exists(select 1 from reading_group_members member where member.group_id=${o.readingGroupId}::uuid and member.work_id=a.work_id)`:sql``;
 // Expand only the requested work and its direct contains members. Each
 // subtype lookup uses that original root set; this is not recursive descent.
 const admittedWork=o.workId?sql`admitted_work_roots as materialized (
  select ${o.workId}::uuid as work_id
  union select child_id from media_relationships where parent_id=${o.workId}::uuid and kind='contains'
 ), admitted_work_ids as materialized (
  select work_id from admitted_work_roots
  union select media_id from episodes where show_id in(select work_id from admitted_work_roots)
  union select media_id from episodes where season_id in(select work_id from admitted_work_roots)
  union select media_id from seasons where show_id in(select work_id from admitted_work_roots)
 ), `:sql``;
 // Materialize only admitted event rows before policy and enrichment. A
 // semijoin keeps each event once even when several structural paths match.
 const admitted=scoped?sql`${admittedWork}admitted_activity as materialized (
  select a.* from social_activity a
  where true ${activityScope} ${o.workId?sql`and a.work_id in(select work_id from admitted_work_ids)`:sql``} ${artistScope} ${readingGroupScope}
 ), `:sql``;
 const rows=await getDb().execute<{id:string;userId:string;username:string;workId:string;eventKind:string;occurredAt:string;count:number;members:string[];dateKnown:boolean;displayWorkId:string;rootId:string;avatar:string|null;episodeCodes:string[];rating:number|null;minutes:number|null;rewatch:boolean;trackTitle:string|null;listenNumber:number;readingPage:number|null;readingTotal:number|null;isRelationship:boolean;relationships:string[]}>(sql`
 with recursive ${admitted}${activityRelationships(userId,o)} activity_policy_keys as materialized (
  select distinct a.user_id,a.section,w.category
  from ${scoped?sql`admitted_activity`:sql`social_activity`} a join works w on w.id=a.work_id
 ), activity_policy as materialized (
  select k.user_id,k.section,k.category from activity_policy_keys k
  where coast_category_enabled(${userId}::uuid,k.category)
   and (k.user_id=${userId}::uuid or coast_feature_enabled(k.user_id,'social') and coast_feature_enabled(${userId}::uuid,'social'))
   and (k.user_id=${userId}::uuid or exists(select 1 from friendships f where f.state='accepted' and f.user_a=least(${userId}::uuid,k.user_id) and f.user_b=greatest(${userId}::uuid,k.user_id)))
   and social_visible(k.user_id,${userId}::uuid,k.section,k.category)
 ), visible_raw as (
  select a.*,w.category,w.kind,u.username,coalesce(e.show_id,se.show_id,r.parent_id,a.work_id) as root_id,
   case when e.media_id is not null then 'S'||lpad(e.season_number::text,greatest(2,length(e.season_number::text)),'0')||'E'||lpad(e.episode_number::text,greatest(2,length(e.episode_number::text)),'0') end as episode_code,
   history.page as reading_page,history.total_pages as reading_total,rating.value as rating, session.minutes_played as minutes,coalesce(tracking.rewatch,false) as rewatch,music.title as track_title
  from ${scoped?sql`admitted_activity`:sql`social_activity`} a join works w on w.id=a.work_id join users u on u.id=a.user_id
  join activity_policy policy on policy.user_id=a.user_id and policy.section is not distinct from a.section and policy.category is not distinct from w.category
  left join reading_history history on history.id=substring(a.source_key from '^reading:([0-9a-f-]{36})$')::uuid
  left join music_works music on music.id=a.work_id
  left join ratings rating on a.event_kind='rating' and rating.user_id=a.user_id and rating.media_id=a.work_id
  left join game_sessions session on session.id=substring(a.source_key from '^game_sessions:([0-9a-f-]{36})$')::uuid
  left join tracking_events tracking on tracking.id=substring(a.source_key from '^tracking_events:([0-9a-f-]{36})$')::uuid
  left join episodes e on e.media_id=a.work_id
  left join seasons se on se.media_id=a.work_id
  left join lateral(select parent_id from media_relationships where e.show_id is null and se.show_id is null and child_id=a.work_id and kind='contains' order by case when parent_id=${o.workId??null}::uuid then 0 else 1 end,position,parent_id limit 1) r on true
  where true
   ${relationshipEventFilter(o.relationship)}
   ${activityScope}
   and (${o.category}='all' or w.category=${o.category} or ${o.category}='reading' and w.category in ('book','comic')) and (${o.kind}='all' or a.event_kind=${o.kind})
   and (${o.friendId??null}::uuid is null or a.user_id=${o.friendId??null}::uuid)
   ${workScope}
   ${artistScope}
   ${readingGroupScope}
   and (w.category='screen' or (w.category='music' and coalesce((select value->>'experimentalMusic' from system_settings where key='coast'),'false')='true') or (w.category='game' and coalesce((select value->>'experimentalGaming' from system_settings where key='coast'),'false')='true') or (w.category='book' and coalesce((select value->>'experimentalBooks' from system_settings where key='coast'),'false')='true') or (w.category='comic' and coalesce((select value->>'experimentalComics' from system_settings where key='coast'),'false')='true'))
 ), deduplicated as (
 select *,row_number() over(partition by user_id,case when source='jellyfin' and event_kind='watch' and date_known then work_id::text||':'||occurred_at::text else id::text end order by created_at,id) as observation_rank from visible_raw
 ), visible as (select *,sum(case when event_kind='listen' and date_known then 1 else 0 end) over(partition by user_id,work_id order by occurred_at,id) as listen_number,lag(occurred_at) over(partition by user_id,root_id order by occurred_at,id) as previous_date from deduplicated where observation_rank=1), numbered as (
  select *,sum(case when previous_date is null or occurred_at-previous_date>interval '3 hours' then 1 else 0 end) over(partition by user_id,root_id order by occurred_at,id) as run from visible
 ), keyed as (
 select *,event_kind as display_kind,
 case when ${activityIds!==undefined} then id::text when event_kind='listen' and batch_key is not null and date_known then 'album:'||batch_key
 when kind='episode' and event_kind='watch' and date_known then 'episode:'||root_id||':'||run else id::text end as group_key from numbered
 ), grouped as (
 select (array_agg(id order by occurred_at desc,id desc))[1] as id,user_id,username,
 (array_agg(work_id order by occurred_at desc,id desc))[1] as work_id,
 (array_agg(root_id order by occurred_at desc,id desc))[1] as root_id,
 case when count(*)=1 and bool_or(kind='episode') then (array_agg(work_id order by occurred_at desc,id desc))[1] else (array_agg(root_id order by occurred_at desc,id desc))[1] end as display_work_id,
 coalesce(array_agg(episode_code order by occurred_at,id) filter(where episode_code is not null),'{}'::text[]) as episode_codes,display_kind as event_kind,
 max(occurred_at) as occurred_at,
 max(reading_page) as reading_page,max(reading_total) as reading_total,max(track_title) as track_title,max(listen_number)::int as listen_number,max(rating) as rating,sum(minutes)::int as minutes,bool_or(rewatch) as rewatch,count(*)::int as count,array_agg(id order by occurred_at,id) as members,bool_and(date_known) as date_known
 from keyed group by user_id,username,display_kind,group_key
 ), combined as (
  select *,false as is_relationship,'{}'::text[] as relationships from grouped
  ${o.relationship!==undefined?sql`union all
  select md5('relationship:'||r.user_id::text||':'||r.work_id::text)::uuid as id,r.user_id,u.username,r.work_id,r.work_id as root_id,r.work_id as display_work_id,
   '{}'::text[] as episode_codes,'relationship' as event_kind,'1970-01-01T00:00:00Z'::timestamptz as occurred_at,
   case when social_visible(r.user_id,${userId}::uuid,'progress',w.category) then progress.page end as reading_page,
   case when social_visible(r.user_id,${userId}::uuid,'progress',w.category) then progress.total_pages end as reading_total,
   null::text as track_title,0::int as listen_number,
   case when social_visible(r.user_id,${userId}::uuid,'ratings',w.category) then rating.value end as rating,
   null::int as minutes,false as rewatch,1::int as count,'{}'::uuid[] as members,false as date_known,true as is_relationship,r.relationships
  from relationship_states r join users u on u.id=r.user_id join works w on w.id=r.work_id
  left join reading_progress progress on progress.user_id=r.user_id and progress.work_id=r.work_id
  left join ratings rating on rating.user_id=r.user_id and rating.media_id=r.work_id
  where not exists(select 1 from visible_raw a where a.user_id=r.user_id and a.work_id=any(r.work_ids))`:sql``}
 )
 select is_relationship as "isRelationship",relationships,id,user_id as "userId",username,work_id as "workId",event_kind as "eventKind",occurred_at as "occurredAt",count,members,rating,minutes,rewatch,reading_page as "readingPage",reading_total as "readingTotal",track_title as "trackTitle",listen_number as "listenNumber",date_known as "dateKnown",display_work_id as "displayWorkId",root_id as "rootId",episode_codes as "episodeCodes",
 case when social_visible(user_id,${userId}::uuid,'details') then (select settings->'profile'->>'avatar' from users where users.id=combined.user_id) end as avatar from combined
 where (is_relationship or ${o.period}='all' or occurred_at>=now()-case when ${o.period}='year' then interval '1 year' else interval '30 days' end) and (${o.before??null}::timestamptz is null or
 (not is_relationship,date_known,occurred_at,id)<(not coalesce(${o.beforeRelationship??null}::boolean,false),coalesce(${o.beforeKnown??null}::boolean,true),${o.before??null}::timestamptz,coalesce(${o.beforeId??null}::uuid,'ffffffff-ffff-ffff-ffff-ffffffffffff'::uuid)))
 order by is_relationship,date_known desc,occurred_at desc,id desc limit 61`);
 const page=Array.from(rows).slice(0,60),cards=await workCards(userId,userId,[...new Set(page.flatMap(r=>[r.displayWorkId,r.rootId]))]);
 const [statuses,reactions]=await Promise.all([statusesForUsers(userId,page.map(event=>event.userId)),reactionSummary(userId,'activity',page.filter(event=>!event.isRelationship).map(event=>event.id))]);
 const items=page.flatMap(event=>{
   const item=cards.find(c=>('workId' in c?c.workId??c.id:c.id)===event.displayWorkId);
   if(!item)return [];
   if(event.isRelationship){
    const labels=workFriendOptions(item.kind);
    const states=event.relationships.map((state:string)=>state==='favourites'?'Favourited':state==='lists'?'In a list':state==='collected'?'Collected':labels.find(option=>option.value===state)?.label??(event.rating!==null?'Rated':'Tracked'));
    const detail=[...new Set(states),...(event.readingPage!==null?[`${event.readingPage}${event.readingTotal?' of '+event.readingTotal:''} pages`]:[]),...(event.rating!==null?[`${event.rating} / 5`]:[])].join(' · ');
    return [{...item,entryId:`relationship:${event.id}`,captionActor:{username:event.username,avatar:event.avatar,status:statuses[event.userId]??'offline'},captionSubtitle:detail}];
   }
   const extras=[event.readingPage!=null?`${event.readingPage}${event.readingTotal?' of '+event.readingTotal:''} pages`:null,event.eventKind==='listen'&&event.count===1?event.trackTitle:null,event.eventKind==='listen'&&event.count===1&&event.listenNumber>1?`Listen ${event.listenNumber}`:null,event.rating!=null?`${event.rating}/5`:null,event.minutes!=null?`${event.minutes} minutes`:null,event.rewatch?'Rewatch':null].filter(Boolean);
   const episodeCount=new Set(event.episodeCodes).size;
   const action=event.eventKind==='watch'&&episodeCount>0?`Watched ${episodeCount} ${episodeCount===1?'episode':'episodes'}`:activityAction(event.eventKind);
   const root=cards.find(c=>('workId' in c?c.workId??c.id:c.id)===event.rootId);
   const detail=[event.eventKind==='watch'&&episodeCount>0?`${episodeCount} ${episodeCount===1?'episode':'episodes'}`:event.count>1?`${event.count} ${event.eventKind==='listen'?'tracks':'items'}`:null,...extras].filter(Boolean).join(' · ');
   return [{...item,captionTitle:item.kind==='episode'?root?.title??item.title:item.title,captionTitleHref:item.kind==='episode'&&root?`/media/${root.id}`:undefined,entryId:event.id,captionActivity:{myReaction:reactions[event.id]?.find(reaction=>reaction.mine)?.emoji??null,id:event.id,occurredAt:new Date(event.occurredAt).toISOString(),dateKnown:event.dateKnown,kind:event.eventKind,action:activityAction(event.eventKind),detail},captionActor:{username:event.username,avatar:event.avatar,status:statuses[event.userId]??'offline'},captionSubtitle:`${action}${episodeCount===0&&event.count>1?` · ${event.count} ${event.eventKind==='listen'?'tracks':'items'}`:''}${extras.length?` · ${extras.join(' · ')}`:''}`}];
 });
 const last=page.at(-1);
 return {items,events:page.filter(event=>!event.isRelationship),hasMore:rows.length>60,next:last?{before:new Date(last.occurredAt).toISOString(),beforeId:last.id,beforeKnown:String(last.dateKnown),...(o.relationship!==undefined?{beforeRelationship:String(last.isRelationship)}:{})}:null};
}
/** Compact media-card heads only; item Activity owns the detailed relationship view. */
export async function workSocial(userId:string,ids:string[]) {
 v.parse(v.pipe(v.array(uuid),v.maxLength(60)),ids);if(!ids.length||!(await getFeatureConfig(userId)).features.social)return {};
 const list=sql.join(ids.map(id=>sql`${id}::uuid`),sql`,`);
 const rows=await getDb().execute<{workId:string;userId:string;username:string;avatar:string|null;rating:number|null;watched:boolean;progress:number;total:number}>(sql`
 with recursive edges(parent_id,child_id) as (${relationshipEdges}), descendants(root,id) as(select id,id from works where id in (${list}) union select d.root,e.child_id from descendants d join edges e on e.parent_id=d.id), ancestors(root,id) as(select id,id from works where id in (${list}) union select a.root,e.parent_id from ancestors a join edges e on e.child_id=a.id), reasons as (${relationshipReasons}
 ), visible_friends as (
 select distinct d.root as "workId",u.id as "userId",u.username,
 case when social_visible(u.id,${userId}::uuid,'details') then u.settings->'profile'->>'avatar' end as avatar,
 case when social_visible(u.id,${userId}::uuid,'ratings',w.category) then rating.value end as rating,
 case when w.category in ('book','comic') then social_visible(u.id,${userId}::uuid,'progress',w.category) and coalesce(rp.state='completed',false) when social_visible(u.id,${userId}::uuid,'activity',w.category) then coalesce(t.watched,false) else false end as watched,
 case when social_visible(u.id,${userId}::uuid,'progress',w.category) then case when w.category in ('book','comic') then coalesce(rp.page,0) else coalesce(t.position_seconds,0) end else 0 end as progress
 from descendants d join reasons r on r.id=d.id join works w on w.id=d.id join users u on u.id=r.user_id and coast_feature_enabled(u.id,'social')
 left join ratings rating on rating.user_id=u.id and rating.media_id=d.root left join tracking_state t on t.user_id=u.id and t.media_id=d.root left join reading_progress rp on rp.user_id=u.id and rp.work_id=d.root
 where (w.category='screen' or (w.category='music' and coalesce((select value->>'experimentalMusic' from system_settings where key='coast'),'false')='true') or (w.category='game' and coalesce((select value->>'experimentalGaming' from system_settings where key='coast'),'false')='true') or (w.category='book' and coalesce((select value->>'experimentalBooks' from system_settings where key='coast'),'false')='true') or (w.category='comic' and coalesce((select value->>'experimentalComics' from system_settings where key='coast'),'false')='true')) and exists(select 1 from friendships f where f.state='accepted' and f.user_a=least(${userId}::uuid,u.id) and f.user_b=greatest(${userId}::uuid,u.id)) and social_visible(u.id,${userId}::uuid,r.section,w.category)
 ), ranked_friends as (
 select *,count(*) over(partition by "workId")::int as total,
 row_number() over(partition by "workId" order by username,"userId") as ordinal from visible_friends
 )
 select "workId","userId",username,avatar,rating,watched,progress,total
 from ranked_friends where ordinal<=3 order by "workId",ordinal`);
 const reactions=await getDb().execute<{targetId:string;emoji:string;count:number}>(sql`select r.target_id as "targetId",r.emoji,count(*)::int as count from social_reactions r join works w on w.id=r.target_id where r.target_kind='work' and r.target_id in (${list}) and social_visible(r.user_id,${userId}::uuid,'reactions',w.category) group by r.target_id,r.emoji`);
 // Resolve only the three visible heads per work after privacy filtering.
 const socialFriends=Array.from(rows);
 const statuses=await statusesForUsers(userId,socialFriends.map(row=>row.userId));
 type WorkFriends={friends:(Omit<typeof socialFriends[number],'total'>&{status:import('./status').ActivityStatus})[];total:number};
 const byWork=new Map<string,WorkFriends>();
 for(const {total,...friend} of socialFriends){
  const entry:WorkFriends=byWork.get(friend.workId)??{friends:[],total};
  entry.friends.push({...friend,status:statuses[friend.userId]??'offline'});byWork.set(friend.workId,entry);
 }
 return Object.fromEntries(ids.map(id=>[id,{friends:byWork.get(id)?.friends??[],total:byWork.get(id)?.total??0,reactions:Array.from(reactions).filter(r=>r.targetId===id)}]));
}

/** Batch reads share the same visibility predicate as activity and media indicators. */
export async function reactionSummary(userId:string,targetKind:'work'|'activity',ids:string[]) {
 v.parse(v.pipe(v.array(uuid),v.maxLength(60)),ids);if(!ids.length||!(await getFeatureConfig(userId)).features.social)return {};
 const targets=sql.join(ids.map(id=>sql`${id}::uuid`),sql`,`);
 const rows=await getDb().execute<{targetId:string;emoji:string;count:number;mine:boolean}>(sql`
 select r.target_id as "targetId",r.emoji,count(*)::int as count,bool_or(r.user_id=${userId}) as mine
 from social_reactions r
 left join social_activity a on r.target_kind='activity' and a.id=r.target_id
 join works w on w.id=case when r.target_kind='work' then r.target_id else a.work_id end
 where coast_feature_enabled(r.user_id,'social') and coast_category_enabled(${userId}::uuid,w.category) and r.target_kind=${targetKind} and r.target_id in (${targets})
 and (r.target_kind='work' or social_visible(a.user_id,${userId}::uuid,a.section,w.category))
 and social_visible(r.user_id,${userId}::uuid,'reactions',w.category)
 and (w.category='screen' or (w.category='music' and coalesce((select value->>'experimentalMusic' from system_settings where key='coast'),'false')='true') or (w.category='game' and coalesce((select value->>'experimentalGaming' from system_settings where key='coast'),'false')='true') or (w.category='book' and coalesce((select value->>'experimentalBooks' from system_settings where key='coast'),'false')='true') or (w.category='comic' and coalesce((select value->>'experimentalComics' from system_settings where key='coast'),'false')='true'))
 group by r.target_id,r.emoji`);
 return Object.fromEntries(ids.map(id=>[id,Array.from(rows).filter(row=>row.targetId===id)]));
}
