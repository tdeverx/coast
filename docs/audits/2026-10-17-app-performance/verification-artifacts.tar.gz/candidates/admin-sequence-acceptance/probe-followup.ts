import {getSql,getDb,closeDb} from '../../../../../src/lib/server/db';
import {sql as q} from 'drizzle-orm';
import * as current from '../../../../../src/lib/core/tracking/service.server';
import {setRewatch} from '../../../../../src/lib/core/tracking/rewatch.server';
import {sequenceEntries,sequenceEntry,restartPlaylist} from '../../../../../src/lib/core/lists/sequence.server';
import {createHash} from 'node:crypto';
const runId=process.env.COAST_AVATAR_RUN_ID!,url=new URL(process.env.DATABASE_URL!);
if(process.env.COAST_AUDIT_MATCHED_AVATAR_COPY!=='1'||url.hostname!=='127.0.0.1'||url.port!=='55432'||!/^\/coast_audit_fix_actual_[a-f0-9]{32}$/.test(url.pathname))throw Error('owned-copy-required');
const sql=getSql(),db=getDb(),result:any={runId,status:'running',checks:{},pairs:[],locks:[],boundary:'Controlled temporary admin lists, rewatch/history and repeated paths using actual catalogue, on marker-owned disposable actual-data copy. Native archived default/current; all scenario mutations rolled back. No fabricated accounts/catalogue/provider/media replies or transport.'};
const check=(ok:any,k:string)=>{result.checks[k]=!!ok;if(!ok)throw Error(k)};
let external=0;globalThis.fetch=(async()=>{external++;throw Error('external-forbidden')})as any;
const hash=(v:string)=>createHash('sha256').update(v).digest('hex');
const paths=['core/tracking/service.server.ts','core/tracking/rewatch.server.ts','core/lists/sequence.server.ts'];
const hashes=async()=>Object.fromEntries(await Promise.all(paths.map(async p=>[p,hash(await Bun.file(new URL('../../../../../src/lib/'+p,import.meta.url)).text())])));
async function archived(name:string){const source=await Bun.file(new URL(name+'.default.ts.txt',import.meta.url)).text(),base=new URL('../../../../../src/lib/core/'+(name==='sequence'?'lists/':'tracking/')+name+'.server.ts',import.meta.url);const code=new Bun.Transpiler({loader:'ts'}).transformSync(source).replace(/from\s*(['"])([^'"]+)\1/g,(_m,_q,p)=>`from ${JSON.stringify(p.startsWith('.')?new URL(p,base).pathname:p.startsWith('$lib/')?new URL('../../../../../src/lib/'+p.slice(5),import.meta.url).pathname:import.meta.resolve(p))}`);const file=process.env.COAST_DATA_DIR!+'/sequence-default-'+name+'.js';await Bun.write(file,code);return {module:await import(file),hash:hash(source)}}
const prior=await archived('service'),priorRewatch=await archived('rewatch');result.sourceBefore=await hashes();result.archived={commit:'eb0673873462b71118d1c11678d128958a05ff07',tracking:prior.hash,rewatch:priorRewatch.hash,sharedCurrentSequenceOwner:true};
const fixture={list:crypto.randomUUID(),root1:crypto.randomUUID(),root2:crypto.randomUUID()};
let owner:any,parent:string,nested:string,movie:string,other:string;
const fixed='2021-01-01T00:00:00.000Z';
async function setup(tx:any,mode:string){
 await tx.execute(q`delete from media_relationships where parent_id in (${parent},${nested})`);
 await tx.execute(q`insert into media_relationships(parent_id,child_id,position,kind) values(${parent},${movie},0,'collection'),(${parent},${nested},1,'collection'),(${nested},${movie},0,'collection'),(${nested},${other},1,'collection')`);
 await tx.execute(q`delete from tracking_events where user_id=${owner.id} and media_id in (${parent},${nested},${movie},${other})`);
 await tx.execute(q`delete from tracking_state where user_id=${owner.id} and media_id in (${parent},${nested},${movie},${other})`);
 await tx.execute(q`delete from rewatches where user_id=${owner.id} and media_id in (${parent},${nested},${movie},${other})`);
 await tx.execute(q`delete from up_next where user_id=${owner.id} and media_id in (${parent},${nested},${movie},${other})`);
 await tx.execute(q`insert into up_next(user_id,media_id,created_at) values(${owner.id},${movie},'2020-01-01T00:00:00Z'),(${owner.id},${other},'2020-01-02T00:00:00Z')`);
 await tx.execute(q`insert into lists(id,user_id,name,playlist,created_at,updated_at) values(${fixture.list},${owner.id},'Owned sequence acceptance',true,'2020-01-01T00:00:00Z','2020-01-01T00:00:00Z')`);
 await tx.execute(q`insert into list_items(id,list_id,media_id,position,added_at) values(${fixture.root1},${fixture.list},${parent},0,'2020-01-01T00:00:00Z'),(${fixture.root2},${fixture.list},${parent},1,'2020-01-01T00:00:00Z')`);
 if(mode.includes('rewatch')||mode.includes('backdated')){
  await current.trackInTransaction(tx,owner.id,{mediaId:movie,action:'watch',occurredAt:'2010-01-01T00:00:00.000Z'});
  await tx.execute(q`insert into rewatches(user_id,media_id,started_at) values(${owner.id},${parent},'2020-01-01T00:00:00Z')`);
 }
 if(mode.includes('dropped'))await tx.execute(q`insert into tracking_state(user_id,media_id,dropped) values(${owner.id},${nested},true)`);
}
async function snapshot(tx:any){const [r]=await tx.execute(q`select
 (select jsonb_agg(to_jsonb(t)-'updated_at' order by media_id) from tracking_state t where user_id=${owner.id}) as states,
 (select jsonb_agg(to_jsonb(t) order by media_id) from up_next t where user_id=${owner.id}) as queue,
 (select jsonb_agg(to_jsonb(t)-'id'-'created_at' order by media_id,sequence::text,occurred_at,action) from tracking_events t where user_id=${owner.id}) as events,
 (select jsonb_agg(to_jsonb(t) order by media_id) from rewatches t where user_id=${owner.id}) as rewatches,
 (select to_jsonb(t)-'updated_at' from lists t where id=${fixture.list}) as list,
 (select jsonb_agg(to_jsonb(t) order by position,id) from list_items t where list_id=${fixture.list}) as items,
 (select count(*)::int from outbox_actions t where user_id=${owner.id}) as outboxCount`);return r}
function cleanResult(r:any){if(!r)return r;if(r.eventIds)r={...r,eventIds:r.eventIds.map(()=> 'generated-event')};if(r.events)return {...r,events:r.events.map(({eventId,...e}:any)=>e)};const{updatedAt,...state}=r.state??{};return {...r,state,eventId:r.eventId?'generated-event':null}}
async function run(version:string,mode:string){let captured:any;const module=version==='default'?prior.module:current;const session=(db as any).session,old=session.logger,oldOptions=session.options.logger,queries:string[]=[];const logger={logQuery:(q:string)=>queries.push(q)};session.logger=logger;session.options.logger=logger;
 try{try{await db.transaction(async tx=>{
 await tx.execute(q`set local statement_timeout='20s'`);await setup(tx,mode);
 const before=await snapshot(tx);let outcome:any,error:any;
 const playlist=mode.includes('playlist'),sequence=playlist?{kind:'playlist',id:fixture.list,entryId:fixture.root1}:{kind:'collection',id:parent,entryId:parent};
 const entries=await sequenceEntries(owner.id,sequence as any,tx);
 const target=entries.find(e=>e.mediaId===movie)!;
 const occurredAt=mode.includes('backdated')?'2015-01-01T00:00:00.000Z':fixed;
 const ordinary=mode.startsWith('ordinary');let input:any=ordinary?{mediaId:movie,action:'watch',acknowledged:true,occurredAt,sequence:{...sequence,entryId:target.entryId}}:{mediaId:parent,action:'watch',acknowledged:true,occurredAt,sequence};
 if(mode.includes('malformed'))input.sequence.entryId='not-a-uuid';
 if(mode.includes('withdrawn'))await tx.execute(q`delete from media_relationships where parent_id=${nested} and child_id=${movie}`),input.sequence.entryId=parent+'/'+nested+'/'+movie;
 if(mode.includes('source-replacement'))await tx.execute(q`update list_items set media_id=${other} where id=${fixture.root1}`);
 if(mode==='playlist-repeated-roots')input.sequence={kind:'playlist',id:fixture.list,entryId:fixture.root1};
 const mutationsBefore=await snapshot(tx);const start=queries.length;
 try{outcome=await tx.transaction(async inner=>{const first=await module.trackInTransaction(inner,owner.id,input);const second=await module.trackInTransaction(inner,owner.id,{...input,sequence:{...input.sequence,entryId:input.sequence.entryId.replace(fixture.root1,fixture.root2)}});return {...second,firstResult:cleanResult(first),eventIds:[first.eventId,second.eventId]};});}catch(e:any){error={name:e.name,message:e.message,status:e.status,code:e.code};}
 const after=await snapshot(tx);const mutationQueries=queries.slice(start);
 const eventIds=outcome?.eventIds??outcome?.events?.map((e:any)=>e.eventId)??(outcome?.eventId?[outcome.eventId]:[]);
 const eventLinks=eventIds.length?await tx.execute(q`select id from tracking_events where user_id=${owner.id} and id in (${q.join(eventIds.map((id:string)=>q`${id}::uuid`),q`,`)})`):[];
 const full=(await sequenceEntries(owner.id,sequence as any,tx));
 const narrow=await Promise.all(full.map(e=>sequenceEntry(owner.id,{...sequence,entryId:e.entryId} as any,e.mediaId,tx)));
 captured={logicalResult:cleanResult(outcome),snapshot:after,error,atomicError:!error||JSON.stringify(mutationsBefore)===JSON.stringify(after),eventIdentity:!outcome||eventLinks.length===eventIds.length,fullNarrowEqual:JSON.stringify(full)===JSON.stringify(narrow),occurrences:full.length,distinctPaths:new Set(full.map(e=>e.entryId)).size,watched:full.filter(e=>e.watched).length,logicalPlayCount:after.states?.filter((s:any)=>s.media_id===movie).map((s:any)=>s.play_count),query:{statements:mutationQueries.length,wholeTree:mutationQueries.filter(s=>s.includes('from entries order by sort_path')).length,narrow:mutationQueries.filter(s=>s.includes('from entries where entry_id=')).length},setupChangedOnlyOwnedCopy:true};
 throw Error('CONTROLLED_ROLLBACK');
 });}catch(e:any){if(e.message!=='CONTROLLED_ROLLBACK')throw e;}}
 finally{session.logger=old;session.options.logger=oldOptions}
 return captured;
}
async function lockAcceptance(){
 const archivedSequence=await archived('sequence');result.archived.sequence=archivedSequence.hash;
 const list=crypto.randomUUID();
 await sql`insert into lists(id,user_id,name,playlist,playback_started_at) values(${list},${owner.id},'Owned boundary acceptance',true,'2020-01-01T00:00:00Z')`;
 for(const mode of ['saved-rewatch-clear','saved-playlist-restart'])for(const version of ['default','current']){
  if(mode==='saved-rewatch-clear')await sql`insert into rewatches(user_id,media_id,started_at) values(${owner.id},${parent},'2020-01-01T00:00:00Z') on conflict(user_id,media_id) do update set started_at=excluded.started_at`;
  else await sql`update lists set playback_started_at='2020-01-01T00:00:00Z' where id=${list}`;
  const before=await sql`select (select jsonb_agg(to_jsonb(t)-'updated_at' order by media_id) from tracking_state t where user_id=${owner.id})as state,(select jsonb_agg(to_jsonb(t) order by media_id)from up_next t where user_id=${owner.id})as queue,(select count(*)::int from tracking_events where user_id=${owner.id})as events`;
  let release!:()=>void,entered!:()=>void;const gate=new Promise<void>(r=>entered=r),leave=new Promise<void>(r=>release=r);let settled=false,failure:any;
  const blocker=sql.begin(async tx=>{await tx`select pg_advisory_xact_lock(hashtextextended(${owner.id},0))`;entered();await leave});await gate;
  const fn=mode==='saved-rewatch-clear'?(version==='default'?priorRewatch.module.setRewatch:setRewatch):(version==='default'?archivedSequence.module.restartPlaylist:restartPlaylist);
  const operation=fn(owner.id,mode==='saved-rewatch-clear'?{mediaId:parent,startedAt:null}:list).then(()=>{settled=true},(e:any)=>{settled=true;failure=e});
  await Bun.sleep(250);
  const [wait]=await sql`with target as(select hashtextextended(${owner.id},0)as key)select count(*)::int as n from pg_locks l,target where l.locktype='advisory'and not l.granted and l.database=(select oid from pg_database where datname=current_database())and l.classid=((target.key>>32)&4294967295)::oid and l.objid=(target.key&4294967295)::oid`;
  const settledWhileHeld=settled;release();await blocker;await operation;if(failure)throw failure;
  const after=await sql`select (select jsonb_agg(to_jsonb(t)-'updated_at' order by media_id) from tracking_state t where user_id=${owner.id})as state,(select jsonb_agg(to_jsonb(t) order by media_id)from up_next t where user_id=${owner.id})as queue,(select count(*)::int from tracking_events where user_id=${owner.id})as events`;
  const [effect]=mode==='saved-rewatch-clear'?await sql`select not exists(select 1 from rewatches where user_id=${owner.id}and media_id=${parent})as ok`:await sql`select playback_started_at>'2020-01-01T00:00:00Z'::timestamptz as ok from lists where id=${list}`;
  check(effect.ok,mode+version+'-saved-boundary-effect');check(JSON.stringify(before)===JSON.stringify(after),mode+version+'-history-state-queue-preserved');
  check(version==='default'?settledWhileHeld:!settledWhileHeld&&wait.n===1,mode+version+'-authoritative-account-fence');
  result.locks.push({mode,version,settledWhileHeld,accountWaiters:wait.n,savedBoundaryEffect:true,historyStateQueuePreserved:true});
 }
 await sql`delete from lists where id=${list}`;
}
function logical(r:any){return JSON.stringify({...r,query:undefined})}
try{
 const[marker]=await sql`select shobj_description(oid,'pg_database')as marker from pg_database where datname=current_database()`;check(marker.marker==='coast-sequence-acceptance-copy:'+runId,'exact-owned-marker');
 [owner]=await sql`select id from users where username='admin' and role='admin' and not disabled and coast_feature_enabled(id,'screen') and coast_feature_enabled(id,'playback')`;check(owner,'actual-admin-screen-playback');
 const parents=await sql`select id from media where kind='collection' order by id limit 2`;const movies=await sql`select id from media where kind='movie' order by id limit 2`;check(parents.length===2&&movies.length===2,'actual-catalogue-collections-movies');[parent,nested]=parents.map(x=>x.id);[movie,other]=movies.map(x=>x.id);
 for(const mode of ['ordinary-playlist-repeated-entries']){
  const before=await run('default',mode),after=await run('current',mode),equal=logical(before)===logical(after);
  result.pairs.push({mode,equivalent:equal,default:{...before,snapshot:undefined,logicalResult:undefined},current:{...after,snapshot:undefined,logicalResult:undefined},completeStateEventsQueueListRewatchCompared:true});
  check(equal,mode+'-complete-native-equivalence');check(before.atomicError&&after.atomicError,mode+'-atomic-error');check(before.eventIdentity&&after.eventIdentity,mode+'-exact-event-links');check(before.fullNarrowEqual&&after.fullNarrowEqual,mode+'-full-narrow-occurrence');
 }
 await lockAcceptance();
 check(external===0,'zero-external-transport');result.externalCalls=external;result.status='passed';
}catch(e:any){result.status='failed';result.failure={message:String(e.message).split('\nparams:')[0],code:e.code??e.cause?.code};process.exitCode=1}
finally{result.sourceAfter=await hashes();result.sourceUnchanged=JSON.stringify(result.sourceBefore)===JSON.stringify(result.sourceAfter);await Bun.write(process.argv[2],JSON.stringify(result,null,2));await closeDb()}
