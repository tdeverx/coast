<script lang="ts">
  import { reportFailure } from '$lib/ui/client-context';
  import ReadingLaunch from '$lib/reading/ReadingLaunch.svelte';
  import { goto } from '$app/navigation';
  import { mediumOptions } from '$lib/experimental';
  import SegmentedControl from '$lib/ui/components/SegmentedControl.svelte';
  import { page } from '$app/state';
  import Heading from '$lib/ui/components/Heading.svelte';
  import Shelf from '$lib/ui/components/Shelf.svelte';
  import Button from '$lib/ui/components/Button.svelte';
  import { api, change } from '$lib/ui/client';
  import { createOperation } from '$lib/ui/operation.svelte';
  import { playMedia } from '$lib/playback/client.svelte';
  import { startSynced, syncedPlayer } from '$lib/playback/synced/client.svelte';
  let { data } = $props();
  const operation = createOperation();

  async function start(id: string,reading=false) {
    const plan = data.plans.find(plan => plan.id === id);
    if (!plan) return;
    await operation.run(async () => {
      if(!reading)await playMedia(plan.workId);
      if (plan.party) {
        await startSynced();
        const room = syncedPlayer.room;
        if (!room) throw new Error(syncedPlayer.notice || 'The party could not start.');
        for (const friendId of plan.friends) await api(`synced/${room.id}/invite`, { friendId });
      }
      await change(`planning/${id}/complete`, {});
    });
  }
  function finish(id: string, cancel = false) {
    void operation.run(async () => {
      if (cancel) await change(`planning/${id}`, undefined, 'DELETE');
      else await change(`planning/${id}/complete`, {});
    });
  }
  function pageUrl(number: number) {
    const url = new URL(page.url);
    url.searchParams.set('page', String(number));
    return url.pathname + url.search;
  }

  reportFailure(()=>operation.error);
</script>

<svelte:head><title>Planning · Coast</title></svelte:head>
<div class="content page">
  <Heading title="Planning" variant="page" description="Experimental · your scheduled plans. Visual treatment unapproved.">
    {#snippet segments()}<SegmentedControl label="Planning medium" value={data.category} options={mediumOptions({...page.data,features:page.data.capabilities}, ['screen','game','music','reading'])} onchange={category=>{const url=new URL(page.url);url.searchParams.set('category',category);url.searchParams.delete('page');void goto(url,{keepFocus:true,noScroll:true});}} />{/snippet}
  </Heading>

  <Shelf title="Your plans" items={data.items} layout="grid" availability={false} hideEmpty={false} pageNumber={data.page} pages={data.pages} {pageUrl}>
    {#snippet details(item)}
      <div class="row">
        {#if item.kind==='book'||item.kind==='comic'}<ReadingLaunch compact workId={item.id} title={item.title} onopened={async()=>{start(item.entryId!,true);}} />
        {:else if ['movie', 'episode', 'track'].includes(item.kind)}
          <Button compact disabled={operation.busy} onclick={() => start(item.entryId!)}>Start</Button>
        {:else}
          <Button compact href={'href' in item ? item.href : `/media/${item.id}`}>View</Button>
          <Button compact disabled={operation.busy} onclick={() => finish(item.entryId!)}>Done</Button>
        {/if}
        <Button compact emphasis="subtle" disabled={operation.busy} onclick={() => finish(item.entryId!, true)}>Cancel</Button>
      </div>
    {/snippet}
    {#snippet empty()}<p class="muted">Use Plan in a title’s menu to schedule it.</p>{/snippet}
  </Shelf>
</div>
