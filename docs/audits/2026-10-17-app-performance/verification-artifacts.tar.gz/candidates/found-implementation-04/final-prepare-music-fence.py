from pathlib import Path
import hashlib,json,shutil
root=Path('/Users/admin/Documents/ChatGPT/coast-new');d=Path('/private/tmp/coast-bounded-music-fence-next');d.mkdir(exist_ok=True)
current=(root/'src/lib/server/queries/music.ts').read_text()
before=current.replace("    let incomplete=results.some(result=>!!result.failure);\n    for (let number = bounds.firstPage; number <= page&&!incomplete; number++) {", "    for (let number = bounds.firstPage; number <= page; number++) {")
before=before.replace("      if (current.some((result,index) => result.failure || result.total !== results[index].total)) {\n        incomplete=true;break;\n      }", "      if (current.some((result,index) => result.failure || result.total !== results[index].total))\n        throw new AppError(502, 'The music library changed or could not be loaded. Retry this range.', 'incomplete_page_range');")
before=before.replace("    signal?.throwIfAborted();\n    await requireFeature(userId,'music');", "    await requireFeature(userId,'music');")
before=before.replace("    if (before.length!==after.length)","    if (JSON.stringify(before) !== JSON.stringify(after))")
before=before.replace("    if(incomplete)\n      throw new AppError(502, 'The music library changed or could not be loaded. Retry this range.', 'incomplete_page_range');\n",'')
expected=json.loads(Path('/private/tmp/coast-bounded-library-next/range-actual.json').read_text())['sourcePinsBefore']['src/lib/server/queries/music.ts'];assert hashlib.sha256(before.encode()).hexdigest()==expected
(d/'music-before-final-fence.ts.txt').write_text(before)
s=Path('/private/tmp/coast-bounded-library-controls-next/controls-proof.ts').read_text().replace('/private/tmp/coast-bounded-library-controls-next',str(d)).replace('controls-actual.json','music-fence-actual.json')
a=s.index(' const{libraryContent}=');b=s.index(' assert((await settings()).pid===initial.pid',a)
s=s[:a]+r'''
 const{requireFeature}=await import(root+'/src/lib/server/features.ts'),{actualMusicRangeFailureControls}=await import(root+'/tests/fixtures/music-range.ts');
 const owners:any[]=Array.from(await c`select u.id from users u where not u.disabled order by exists(select 1 from provider_connections pc join provider_instances pi on pi.id=pc.instance_id where pc.user_id=u.id and pc.status='connected' and pi.provider='jellyfin' and pi.enabled) desc,u.id`);assert(owners.length>=2,'actual_two_enabled_subjects');
 const views=[];
 for(const owner of owners.slice(0,2)) {
  const rows:any[]=Array.from(await c`select i.provider,i.enabled,i.name,pc.id as connection_id,pc.account_generation,pc.status from provider_instances i left join provider_connections pc on pc.instance_id=i.id and pc.user_id=${owner.id} where i.enabled and i.provider='jellyfin' order by i.id`);noSecret(rows);
  views.push(rows.map(row=>({provider:row.provider,enabled:row.enabled,name:row.name,connection:row.connection_id?{id:row.connection_id,accountGeneration:row.account_generation,status:row.status}:null})));
 }
 report.actualViews=views.map((view,index)=>({subjectOrdinal:index,enabledJellyfinInstances:view.length,connectedSources:view.filter(p=>p.connection?.status==='connected').length}));
 const before=await Bun.file(folder+'/music-before-final-fence.ts.txt').text();assert(sha(before)===plan.historicalMusicSourceSha256,'reconstructed_exact_historical_music_source');
 report.controls=await actualMusicRangeFailureControls(owners[0].id,views,(id:string)=>requireFeature(id,'music'),before);
''' +s[b:]
s=s.replace("scope:'Current compiled shared Library resource owner: actual cloned catalogue DTOs with authored refresh/retry/failure/lease/filter/viewer/disposal schedules; no fabricated catalogue, providers or mutations.'", "scope:'Final Music range error admission: exact historical/current owner, actual native safe source projections and authored transport/policy/census delivery controls. No fabricated provider response or DB mutation.'")
s=s.replace("report.status='passed_actual_data_library_owner_controls'","report.status='passed_actual_source_music_range_fence_controls'")
a=s.index(' report.limits=[');b=s.index(';await Bun.write(output,',a)
s=s[:a]+" report.limits=['No provider call, credential projection/decryption, fake source row/identity or fabricated remote response. Every remote attempt is an authored rejection; the source inputs are credential-free native projections for two existing users.','The before source exactly matches the historical pinned pre-fence bytes. Fault/census/policy delivery is controlled; it is not an observed live provider outage or same-account permission race.','Normal connected-provider complete JSON DTO comparisons are separate. No CPU/heap/latency or provider-page reduction is claimed.']"+s[b:]
(d/'music-fence-proof.ts').write_text(s);shutil.copyfile('/private/tmp/coast-bounded-library-next/policy-function-contracts.json',d/'policy-function-contracts.json')
pins={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.glob('src/**/*')) if p.is_file()}
for name in ['package.json','bun.lock','tests/fixtures/music-range.ts']:pins[name]=hashlib.sha256((root/name).read_bytes()).hexdigest()
(d/'source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
plan={'approvedRunnerSha256':hashlib.sha256(Path('/private/tmp/coast-fixes-run.py').read_bytes()).hexdigest(),'historicalMusicSourceSha256':expected,'inputPins':{name:hashlib.sha256((d/name).read_bytes()).hexdigest() for name in ['music-fence-proof.ts','source-pins.json','policy-function-contracts.json','music-before-final-fence.ts.txt']}}
(d/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
launch=Path('/private/tmp/coast-bounded-library-controls-next/launch.py').read_text().replace('/private/tmp/coast-bounded-library-controls-next',str(d)).replace("folder/'controls-proof.ts'","folder/'music-fence-proof.ts'").replace('controls-actual.json','music-fence-actual.json');(d/'launch.py').write_text(launch)
print(hashlib.sha256((d/'plan.json').read_bytes()).hexdigest())
