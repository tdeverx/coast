from pathlib import Path
import hashlib,json,shutil
root=Path('/Users/admin/Documents/ChatGPT/coast-new');d=Path('/private/tmp/coast-bounded-library-controls-next');d.mkdir(exist_ok=True)
s=Path('/private/tmp/coast-bounded-library-next/range-proof.ts').read_text().replace('/private/tmp/coast-bounded-library-next',str(d)).replace('range-actual.json','controls-actual.json')
a=s.index(' const orm=');b=s.index(' assert((await settings()).pid===initial.pid',a)
s=s[:a]+r'''
 const{libraryContent}=await import(root+'/src/lib/server/queries/library-content.ts'),{getFeatureConfig}=await import(root+'/src/lib/server/features.ts'),{withRequestConfig}=await import(root+'/src/lib/server/config.ts');
 const{actualLibraryWindowControls}=await import(root+'/tests/fixtures/library-window.ts');
 const[owner]=await c`select id from users where not disabled order by id limit 1`;assert(owner,'actual_enabled_owner');
 const policy=await withRequestConfig(()=>getFeatureConfig(owner.id));
 const data={user:{id:owner.id},capabilities:policy.features,experimentalMusic:policy.experimentalMusic,experimentalGaming:policy.experimentalGaming,experimentalBooks:policy.experimentalBooks,experimentalComics:policy.experimentalComics,contentRevision:{tracking:'authored-initial-revision'}};
 report.ownerOrdinal=0;report.controlResults=await actualLibraryWindowControls(data,async(path:string)=>{
  const result=await withRequestConfig(()=>libraryContent(owner.id,new URL(path,'http://coast/')));noSecret(result);report.actualDomainReads=(report.actualDomainReads??0)+1;return result;
 });
 assert(report.controlResults.schedules.length===6,'six_actual_data_owner_schedules');
''' +s[b:]
s=s.replace("scope:'Bounded native-page server ranges versus canonical actual catalogue DTOs; read-only cloned actual data, no providers or mutations.'", "scope:'Current compiled shared Library resource owner: actual cloned catalogue DTOs with authored refresh/retry/failure/lease/filter/viewer/disposal schedules; no fabricated catalogue, providers or mutations.'")
s=s.replace("report.status='passed_bounded_catalogue_server_ranges_actual'", "report.status='passed_actual_data_library_owner_controls'")
a=s.index(' report.limits=[');b=s.index(';await Bun.write(output,',a)
s=s[:a]+" report.limits=['Every response comes from the actual canonical libraryContent reader on the private clone in the same verified read-only RR frame. No manufactured rows, identities or provider responses.','Request delivery/failure, revision/filter/viewer/disposal and lease-release ordering are authored controls, not native browser/HTTP or actual database policy withdrawal. Native Back, DOM and focus evidence is separate.','The fixture captures current source and uses the real Resource/Library/page-window/admission/path/revision owners. Only client-context, component lifecycle, navigation and transport delivery are ports.','No positive normal-data mutation, in-flight provider command, CPU/heap/GPU/decoded-image/bytes or latency claim.']"+s[b:]
(d/'controls-proof.ts').write_text(s);shutil.copyfile('/private/tmp/coast-bounded-library-next/policy-function-contracts.json',d/'policy-function-contracts.json')
pins={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.glob('src/**/*')) if p.is_file()}
for name in ['package.json','bun.lock','tests/fixtures/library-window.ts','tests/fixtures/ui-script.ts']:pins[name]=hashlib.sha256((root/name).read_bytes()).hexdigest()
(d/'source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
plan={'approvedRunnerSha256':hashlib.sha256(Path('/private/tmp/coast-fixes-run.py').read_bytes()).hexdigest(),'purpose':'Current compiled Library client owner against actual cloned data; read-only RR and no provider transport; synthetic schedules are controls, not fabricated catalogue.','inputPins':{name:hashlib.sha256((d/name).read_bytes()).hexdigest() for name in ['controls-proof.ts','source-pins.json','policy-function-contracts.json']}}
(d/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
launch=Path('/private/tmp/coast-bounded-library-next/launch.py').read_text().replace('/private/tmp/coast-bounded-library-next',str(d)).replace("folder/'range-proof.ts'","folder/'controls-proof.ts'").replace('range-actual.json','controls-actual.json');(d/'launch.py').write_text(launch)
print(hashlib.sha256((d/'plan.json').read_bytes()).hexdigest())
