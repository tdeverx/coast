import {createHash} from 'node:crypto';
import {readFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {compile,compileModule} from '/Users/admin/Documents/ChatGPT/coast-new/node_modules/svelte/compiler/index.js';

// PREPARED ONLY. This serves an authored, isolated UI fixture after explicit
// authorization. Operate it with ordinary CUA controls; no browser evaluator,
// Playwright driver, normal app, provider, database or private Kit history keys.
const root='/Users/admin/Documents/ChatGPT/coast-new';
const folder='/private/tmp/coast-detail-close-baseline-next';
if(process.env.COAST_AUDIT_DETAIL_CLOSE_FIXTURE!=='1')throw Error('explicit_fixture_execution_authorization_required');
if(process.env.DATABASE_URL)throw Error('database_environment_forbidden');
const sha=(value:string)=>createHash('sha256').update(value).digest('hex');
const pinBytes=await readFile(folder+'/source-pins.json','utf8');
const expected:Record<string,string>=JSON.parse(pinBytes);
for(const [path,hash]of Object.entries(expected))if(sha(await readFile(resolve(root,path),'utf8'))!==hash)throw Error('fixture_source_pin_changed');
const typeScript=new Bun.Transpiler({loader:'ts'});
const modules:Record<string,{source:string;svelte?:boolean;runes?:boolean}>={
 route:{runes:true,source:`export const page=$state({state:{},url:new URL('/library',location.href),data:{user:{id:'controlled-actor-a'},contentRevision:{tracking:'0'},capabilities:{screen:true,music:true,games:true,reading:true}}});`},
 bridge:{runes:true,source:`import {page} from 'close-fixture:route';
 export const state=$state({running:false,status:'idle',progress:'Choose one baseline control. Reset before another case.',result:null});
 export const requests=[],traversals=[],nativeCloses=[],events=[];
 export let holdNative=false;
 let serial=0,revision=0;const watchers=new Set(),replayed=new WeakSet();
 export function wake(){for(const watch of [...watchers])watch();}
 export function record(kind,extra={}){events.push({ordinal:events.length+1,kind,...extra});wake();}
 export function until(read,label){if(read())return Promise.resolve();state.progress=label;return new Promise((resolve,reject)=>{const watch=()=>{if(!state.running){watchers.delete(watch);reject(Error('controlled_case_cancelled'));}else if(read()){watchers.delete(watch);resolve();}};watchers.add(watch);record('waiting',{label});});}
 export function cancel(){state.running=false;state.status='cancelled';state.progress='Reset this fixture before another case.';wake();}
 export function setHoldNative(value){holdNative=value;}
 export function requested(delta,origin){traversals.push({delta,origin,depth:page.state.mediaDetailDepth??0,hrefPresent:!!page.state.mediaDetailHref,viewer:page.data.user.id,issued:false});record('history-request',{delta,origin});}
 export const historyBoundary={back(){requested(-1,'back');},go(delta){requested(delta,'close');}};
 export function push(url,value){window.history.pushState({fixtureState:value,fixtureUrl:String(url),fixtureEntry:++serial},'',url);page.state=value;page.url=new URL(url);record('shallow-push',{depth:value.mediaDetailDepth??0});}
 export function replace(url,value){window.history.replaceState({fixtureState:value,fixtureUrl:String(url),fixtureEntry:serial},'',url);page.state=value;page.url=new URL(url);record('shallow-replace');}
 export async function arrive(index=0){const item=traversals.filter(call=>!call.issued)[index];if(!item)throw Error('no_pending_traversal');item.issued=true;const before=events.filter(e=>e.kind==='popstate').length;window.history.go(item.delta);await until(()=>events.filter(e=>e.kind==='popstate').length>before,'real_history_arrival');}
 export async function forward(){const before=events.filter(e=>e.kind==='popstate').length;window.history.forward();await until(()=>events.filter(e=>e.kind==='popstate').length>before,'real_forward_arrival');}
 export function releaseNative(index=0){const held=nativeCloses.filter(item=>!item.delivered)[index];if(!held)throw Error('no_held_native_close');held.delivered=true;const event=new Event('close');replayed.add(event);held.node.dispatchEvent(event);record('native-close-replayed');}
 export function viewer(value){page.data.user={id:value};record('viewer-replacement');}
 export function refresh(){page.data.contentRevision.tracking=String(++revision);record('controlled_revision');}
 export function snapshot(){return{depth:page.state.mediaDetailDepth??0,hrefPresent:!!page.state.mediaDetailHref,section:page.state.mediaDetailHref?.includes('section=activity')?'activity':'overview',dialogs:document.querySelectorAll('dialog[open]').length,headings:[...document.querySelectorAll('[data-fixture-heading]')].map(node=>node.textContent),traversals:traversals.map(({delta,origin,issued})=>({delta,origin,issued})),nativeCloseCount:events.filter(e=>e.kind==='native-close').length,popstateCount:events.filter(e=>e.kind==='popstate').length};}
 window.history.replaceState({fixtureState:{},fixtureUrl:page.url.href,fixtureEntry:0},'',page.url);
 window.addEventListener('popstate',event=>{page.state=event.state?.fixtureState??{};page.url=new URL(event.state?.fixtureUrl??location.href);record('popstate',{depth:page.state.mediaDetailDepth??0,hrefPresent:!!page.state.mediaDetailHref});});
 document.addEventListener('close',event=>{if(!(event.target instanceof HTMLDialogElement)||replayed.has(event))return;record('native-close',{nativeOpen:event.target.open});if(holdNative){event.stopImmediatePropagation();nativeCloses.push({node:event.target,delivered:false});wake();}},true);
 new MutationObserver(wake).observe(document.documentElement,{subtree:true,childList:true,attributes:true});
 window.addEventListener('error',()=>record('unexpected-window-error'));window.addEventListener('unhandledrejection',()=>record('unexpected-rejection'));
 globalThis.fetch=Object.assign(async()=>{throw Error('fixture_network_forbidden');},{preconnect(){throw Error('fixture_network_forbidden');}});
 `},
 'bridge-history':{source:`export {historyBoundary as history} from 'close-fixture:bridge';`},
 appNavigation:{source:`import {push,replace} from 'close-fixture:bridge';export const pushState=push,replaceState=replace;export function goto(){throw Error('unexpected_full_navigation');}`},
 api:{source:`import {requests,record,wake} from 'close-fixture:bridge';
 export class ApiError extends Error{constructor(status){super('controlled terminal failure');this.status=status;}}
 export const message=error=>error.message,isFeatureDisabled=error=>error.featureDisabled===true;
 export function api(path,body,method,{signal}){const u=new URL('/api/v1/'+path,location.href);if(u.searchParams.get('enhance')==='true')return Promise.resolve({kind:'screen',data:{item:{id:'controlled-enhancement',title:'Controlled enhancement'},availability:[]}});return new Promise((resolve,reject)=>{requests.push({path,signal,resolve,reject,answered:false});record('base-request');wake();});}
 `},
 context:{source:`const feedback={host:()=>()=>{},activeHost:undefined,current:undefined};export const useClient=()=>({feedback,preview:false});export const reportFailure=()=>{};`},
 player:{runes:true,source:`export const player=$state({visible:false,session:null,browsing:false});`},
 reader:{runes:true,source:`export const reader=$state({visible:false});`},
 visibility:{source:`export const playbackVisible=player=>player.visible;`},
 material:{source:`export const liquidGlass=()=>({update(){},destroy(){}});export const slidingPill=()=>({destroy(){}});`},
 menu:{source:`export function createMenuController(){throw Error('unexpected_menu_in_close_fixture');}`},
 feedback:{source:`export const notifyAction=()=>{};`},
 icon:{svelte:true,source:`<span aria-hidden="true"></span>`},
 presenter:{svelte:true,source:`<script>import {untrack} from 'svelte';import {useDetailSection} from '$lib/ui/detail-section.svelte';import Controls from 'close-fixture:controls';let {data,detailHref}=$props();const host=useDetailSection(),id=$props.id();const section=$derived(new URL(detailHref,location.href).searchParams.get('section'));$effect(()=>{if(section&&host?.active)return untrack(()=>host.attach(id,()=>({title:'Controlled Activity'})));});</script><main><h1 data-fixture-heading>{section?'Controlled Activity':'Controlled movie'}</h1>{#if !section}<a href={detailHref+'?section=activity'}>Open controlled Activity</a>{/if}<Controls/></main>`},
 scheduler:{source:`import {tick} from 'svelte';import {page} from 'close-fixture:route';import {ApiError} from 'close-fixture:api';import {state,requests,traversals,nativeCloses,events,until,record,arrive,forward,setHoldNative,releaseNative,viewer,refresh,snapshot,wake} from 'close-fixture:bridge';import {openMediaDetails} from '$lib/ui/media-navigation';
 const id='00000000-0000-4000-8000-000000000001',href='/media/'+id,activity=href+'?section=activity';
 function check(value,label){if(!value)throw Error(label);}
 const pending=()=>requests.find(item=>!item.answered&&!item.signal.aborted);
 async function next(){await until(()=>!!pending(),'current_base_request');return pending();}
 function answer(request){request.answered=true;request.resolve({kind:'screen',data:{item:{id,title:'Controlled movie',kind:'movie'},availability:[]}});wake();}
 async function show(target=href){check(openMediaDetails(target),'real_media_navigation_admitted');const request=await next();answer(request);await until(()=>document.querySelector('dialog[open]')&&document.querySelector('[data-fixture-heading]')?.textContent===(target.includes('section=activity')?'Controlled Activity':'Controlled movie'),'native_dialog_and_presenter');await tick();}
 async function terminalVisible(){refresh();const request=await next();request.answered=true;request.reject(new ApiError(403));await until(()=>events.some(event=>event.kind==='native-close'),'real_native_close_event');await tick();}
 function click(label){const button=[...document.querySelectorAll('dialog[open] button')].find(node=>node.getAttribute('aria-label')===label);check(button,'real_dialog_button_present');button.click();}
 export async function run(name){if(state.running||state.status!=='idle')return;state.running=true;state.status='running';state.progress=name;let classification='baseline_positive_control';try{
  if(name==='visible-terminal'){
   await show();await terminalVisible();await until(()=>traversals.length>=2,'two_current_baseline_close_requests');check(traversals.length===2&&traversals.every(call=>call.origin==='close'&&call.delta===-1),'same_trail_duplicate_requests');check(!document.querySelector('dialog[open]'),'native_dialog_closed');classification='baseline_duplicate_close_opportunity';
  }else if(name==='never-presented'){
   check(openMediaDetails(href),'initial_target_admitted');const request=await next();check(!document.querySelector('dialog[open]'),'never_native_presented');request.answered=true;request.reject(new ApiError(403));await until(()=>traversals.length>=1,'manual_initial_close');check(traversals.length===1,'single_initial_close');await tick();check(events.every(event=>event.kind!=='native-close'),'no_native_close_event');await arrive();await tick();check(!page.state.mediaDetailHref,'initial_trail_cleared');
  }else if(name==='late-close-after-arrival'){
   await show();setHoldNative(true);await terminalVisible();check(traversals.length===1&&nativeCloses.length===1,'one_manual_one_held_native');await arrive();await tick();check(!page.state.mediaDetailHref,'real_arrival_before_native_delivery');releaseNative();await tick();check(traversals.length===1,'late_close_no_current_trail_is_noop');
  }else if(name==='pending-reopen-old-owner'||name==='pending-reopen-new-account'){
   await show();setHoldNative(true);await terminalVisible();await arrive();await tick();if(name==='pending-reopen-new-account')viewer('controlled-actor-b');check(openMediaDetails(href),'same_href_reopen_admitted');await next();await tick();check(!document.querySelector('dialog[open]'),'new_owner_not_native_presented_yet');releaseNative();await until(()=>traversals.length>=2,'old_native_delivery_requests_new_pending_trail_close');check(traversals.length===2,'exact_stale_close_request_count');classification='baseline_stale_close_owner_opportunity';
  }else if(name==='forward-and-reopened-guard'){
   await show();setHoldNative(true);await terminalVisible();await arrive();await tick();await forward();const request=await next();answer(request);await until(()=>!!document.querySelector('dialog[open]'),'forward_reopens_native_dialog');releaseNative();await tick();check(traversals.length===1,'old_native_close_cannot_dismiss_open_native_dialog');setHoldNative(false);click('Close media details');await until(()=>traversals.length>=2,'fresh_close_after_forward_still_admitted');check(traversals.length===2,'one_fresh_close_after_forward');check(traversals[1].origin==='close','fresh_legitimate_close');
  }else if(name==='successful-held-back'){
   await show();await show(activity);click('Back within media details');check(traversals.length===1&&traversals[0].origin==='back','one_real_back_request');await arrive();const request=await next();await tick();check(page.state.mediaDetailDepth===1&&!!document.querySelector('dialog[open]'),'depth_one_dialog_retained');check(document.querySelector('[data-fixture-heading]')?.textContent==='Controlled Activity','outgoing_activity_retained');check(!document.querySelector('button[aria-label="Back within media details"]'),'no_back_at_depth_one');check(document.querySelector('.detail-content')?.hasAttribute('inert'),'outgoing_content_inert');answer(request);await until(()=>document.querySelector('[data-fixture-heading]')?.textContent==='Controlled movie','fresh_overview_published');check(traversals.length===1&&!!document.querySelector('dialog[open]'),'no_extra_close_after_success');
  }else throw Error('unknown_control');
  check(!events.some(event=>event.kind==='unexpected-window-error'||event.kind==='unexpected-rejection'),'no_unexpected_runtime_error');state.result={case:name,status:'passed',classification,snapshot:snapshot(),events:events.map(({ordinal,kind,delta,origin,depth,hrefPresent,nativeOpen,label})=>({ordinal,kind,delta,origin,depth,hrefPresent,nativeOpen,label})),limits:['Authored isolated integration only; not normal incident reproduction, actual-data, installed-Kit routing or timing proof.','History calls are held at a named I/O boundary, then released through real browser history/popstate. Native modal close is real; held event replay is explicitly controlled.']};state.status='passed';
 }catch(error){state.status=error.message==='controlled_case_cancelled'?'cancelled':'failed';state.result={case:name,status:state.status,failure:error.message,snapshot:snapshot()};}finally{state.running=false;state.progress='Read result, then Reset fixture before another case.';wake();}}
 `},
 controls:{svelte:true,source:`<script>import {state,cancel} from 'close-fixture:bridge';import {run} from 'close-fixture:scheduler';const cases=[['visible-terminal','Run visible terminal baseline'],['never-presented','Run never-presented control'],['late-close-after-arrival','Run late close after arrival'],['pending-reopen-old-owner','Run pending same-href reopen'],['pending-reopen-new-account','Run pending new-account reopen'],['forward-and-reopened-guard','Run Forward and reopened guard'],['successful-held-back','Run successful held Back']];</script><section class="fixture-controls" aria-label="Authored integration controls"><p><strong>Private baseline fixture</strong> — {state.status}: {state.progress}</p><div>{#each cases as item}<button type="button" disabled={state.running||state.status!=='idle'} onclick={()=>void run(item[0])}>{item[1]}</button>{/each}<button type="button" onclick={cancel}>Cancel run</button><button type="button" onclick={()=>location.reload()}>Reset fixture</button></div><pre aria-label="Read-only baseline result">{JSON.stringify(state.result,null,2)}</pre></section>`},
 harness:{svelte:true,source:`<script>import Panel from '${root}/src/lib/media/DetailPanel.svelte';import {mediaDetailLinks} from '$lib/ui/media-navigation';import Controls from 'close-fixture:controls';</script><div use:mediaDetailLinks><h1>Controlled Library</h1><Controls/><Panel/></div>`},
 entry:{source:`import {mount} from 'svelte';import Harness from 'close-fixture:harness';mount(Harness,{target:document.getElementById('fixture')});`},
};
const aliases:Record<string,string>={
 '$app/state':'route','$app/navigation':'appNavigation','$lib/ui/client':'api','$lib/ui/client-context':'context',
 '$lib/playback/client.svelte':'player','$lib/reading/client.svelte':'reader','$lib/playback/visibility':'visibility',
 '$lib/ui/materials/glass':'material','$lib/ui/materials/sliding-pill':'material','$lib/ui/controls/menu.svelte':'menu','$lib/ui/action-feedback.svelte':'feedback',
};
for(const name of ['$lib/media/Details.svelte','$lib/reading/Details.svelte','$lib/games/Details.svelte','$lib/music/Details.svelte','$lib/reading/GroupDetails.svelte','$lib/games/RemoteDetails.svelte','$lib/media/PersonDetails.svelte','$lib/ui/pages/SectionDetails.svelte'])aliases[name]='presenter';
const bundle=await Bun.build({entrypoints:['close-fixture:entry'],target:'browser',conditions:['browser'],plugins:[{name:'private-detail-close-integration',setup(build){
 build.onResolve({filter:/^close-fixture:/},args=>({path:args.path.slice('close-fixture:'.length),namespace:'close-fixture'}));
 build.onResolve({filter:/\/Icon\.svelte$/},()=>({path:'icon',namespace:'close-fixture'}));
 build.onResolve({filter:/^\$app\/|^\$lib\//},args=>aliases[args.path]?{path:aliases[args.path],namespace:'close-fixture'}:{path:Bun.resolveSync(root+'/src/lib/'+args.path.slice('$lib/'.length),root)});
 build.onLoad({filter:/.*/,namespace:'close-fixture'},args=>{const mod=modules[args.path];if(!mod)throw Error('unknown_fixture_module');return{contents:mod.svelte?compile(mod.source,{filename:args.path+'.svelte',generate:'client'}).js.code:mod.runes?compileModule(mod.source,{filename:args.path+'.svelte.js',generate:'client'}).js.code:mod.source,loader:'js',resolveDir:root};});
 build.onLoad({filter:/\.svelte$/},async args=>({contents:compile(await Bun.file(args.path).text(),{filename:args.path,generate:'client'}).js.code,loader:'js',resolveDir:root}));
 build.onLoad({filter:/\.svelte\.ts$/},async args=>({contents:compileModule(typeScript.transformSync(await Bun.file(args.path).text()),{filename:args.path+'.js',generate:'client'}).js.code,loader:'js',resolveDir:root}));
 build.onLoad({filter:/src\/lib\/ui\/media-navigation\.ts$/},async args=>({contents:'import {history} from "close-fixture:bridge-history";\n'+await Bun.file(args.path).text(),loader:'ts',resolveDir:root}));
}}]});
// Named unqualified global-history seam only; the production function body is
// unchanged. This is not the installed Kit router and uses no private keys.
if(!bundle.success)throw new AggregateError(bundle.logs,'private_fixture_bundle_failed');
const javascript=await bundle.outputs[0].text();
const css=`body{font:15px system-ui;margin:16px}button{padding:8px;margin:3px}pre{white-space:pre-wrap}.fixture-controls{border:1px solid #888;padding:8px;margin:8px 0}dialog.dialog{width:min(850px,90vw);max-height:90vh;padding:12px;overflow:auto}.detail-sheet,.detail-expansion-scroll,.detail-expansion-track,.detail-stage,.detail-scroll,.detail-body{height:auto!important;max-height:none!important;overflow:visible!important;position:static!important}.overlay-controls{position:static!important;height:auto!important;pointer-events:auto!important;top:auto!important}.sheet-settle,.expanded-settle{display:none!important}.detail-content[inert]{opacity:.65}`;
const html='<!doctype html><html><head><meta charset="utf-8"><title>Private detail-close baseline</title><link rel="stylesheet" href="/fixture.css"></head><body><main id="fixture"></main><script type="module" src="/fixture.js"></script></body></html>';
for(const [path,hash]of Object.entries(expected))if(sha(await readFile(resolve(root,path),'utf8'))!==hash)throw Error('fixture_source_changed_during_compile');
const port=Number(process.env.COAST_AUDIT_DETAIL_CLOSE_PORT??0);if(!Number.isInteger(port)||port<0||port>65535)throw Error('invalid_fixture_port');
const server=Bun.serve({hostname:'127.0.0.1',port,fetch(request){const url=new URL(request.url);if(request.method!=='GET')return new Response('Method not allowed',{status:405});if(url.pathname==='/fixture.js')return new Response(javascript,{headers:{'Content-Type':'text/javascript','Cache-Control':'no-store'}});if(url.pathname==='/fixture.css')return new Response(css,{headers:{'Content-Type':'text/css','Cache-Control':'no-store'}});if(url.pathname==='/'||url.pathname==='/library')return new Response(html,{headers:{'Content-Type':'text/html','Cache-Control':'no-store'}});return new Response('Fixture route absent',{status:404});}});
console.log(JSON.stringify({kind:'private_authored_detail_close_fixture',origin:server.url.origin,sourcePins:Object.keys(expected).length,noNormalAppOrDatabase:true,instructions:'CUA only: choose one visible baseline control, inspect read-only result, Reset before another. No app evaluator or hidden API.'}));
