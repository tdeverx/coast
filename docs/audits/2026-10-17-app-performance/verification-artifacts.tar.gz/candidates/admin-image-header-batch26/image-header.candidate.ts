/** Bounded admission hint. Unknown/incomplete headers retain native decode admission. */
export const IMAGE_HEADER_BYTES=64*1024;
export const IMAGE_PIXEL_LIMIT=32*1024**2;
export function imageHeaderDimensions(bytes:Uint8Array):{width:number;height:number}|undefined{
 const n=bytes.length,v=new DataView(bytes.buffer,bytes.byteOffset,n);
 if(n>=24&&v.getUint32(0)===0x89504e47&&v.getUint32(4)===0x0d0a1a0a&&v.getUint32(8)===13&&v.getUint32(12)===0x49484452){
  const width=v.getUint32(16),height=v.getUint32(20);return width&&height?{width,height}:undefined;
 }
 if(n>=10&&bytes[0]===71&&bytes[1]===73&&bytes[2]===70&&bytes[3]===56&&(bytes[4]===55||bytes[4]===57)&&bytes[5]===97){
  const width=v.getUint16(6,true),height=v.getUint16(8,true);return width&&height?{width,height}:undefined;
 }
 if(n<4||bytes[0]!==255||bytes[1]!==216)return;
 let p=2;
 while(p<n){
  if(bytes[p++]!==255)return;
  while(p<n&&bytes[p]===255)p++;
  if(p>=n)return;
  const marker=bytes[p++];
  if(marker===0xda||marker===0xd9||marker===0)return;
  if(marker===0x01||(marker>=0xd0&&marker<=0xd7))continue;
  if(p+2>n)return;
  const length=v.getUint16(p);if(length<2||p+length>n)return;
  if([0xc0,0xc1,0xc2,0xc3,0xc5,0xc6,0xc7,0xc9,0xca,0xcb,0xcd,0xce,0xcf].includes(marker)){
   if(length<8)return;
   const height=v.getUint16(p+3),width=v.getUint16(p+5);return width&&height?{width,height}:undefined;
  }
  p+=length;
 }
}
export async function guardImageHeader(blob:Blob,signal:AbortSignal){
 signal.throwIfAborted();
 const bytes=new Uint8Array(await blob.slice(0,IMAGE_HEADER_BYTES).arrayBuffer());
 signal.throwIfAborted();
 const size=imageHeaderDimensions(bytes);
 if(size&&size.width*size.height>IMAGE_PIXEL_LIMIT)throw new Error('This comic page is too large.');
 return size;
}
