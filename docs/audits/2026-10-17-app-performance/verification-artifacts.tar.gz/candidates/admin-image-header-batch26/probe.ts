import {guardImageHeader,IMAGE_HEADER_BYTES,IMAGE_PIXEL_LIMIT}from'./image-header.candidate';
import{readFile,writeFile}from'node:fs/promises';
const bytes=await readFile('/private/tmp/coast-actual-reader-page-26.bin');
const hash=new Bun.CryptoHasher('sha256').update(bytes).digest('hex');
if(hash!=='72746c4dfda2a7494f61aaf8231b07c904fad4407d9650a71440e13e87d68b99')throw Error('actual_input_hash_changed');
const blob=new Blob([bytes]),start=performance.now(),size=await guardImageHeader(blob,new AbortController().signal),elapsed=performance.now()-start;
if(size?.width!==1988||size.height!==3057)throw Error('native_dimensions_mismatch');
const controller=new AbortController();controller.abort();let aborted=false;
try{await guardImageHeader(blob,controller.signal)}catch(e){aborted=e instanceof DOMException&&e.name==='AbortError'}
if(!aborted)throw Error('abort_not_preserved');
const receipt={status:'ordinary-jpeg-header-admission-passed-not-full-acceptance',input:{bytes:bytes.length,sha256:hash,provenance:'Actual signed-in reader encoded page; retained bytes, not fabricated provider response'},header:size,pixels:size.width*size.height,pixelLimit:IMAGE_PIXEL_LIMIT,headerInspectionBytes:Math.min(bytes.length,IMAGE_HEADER_BYTES),singleHeaderElapsedMs:elapsed,default:{predecodeHeaderBytes:0,objectUrls:1,decodeCalls:1},candidateExpectedBrowserOperations:{predecodeHeaderBytes:Math.min(bytes.length,IMAGE_HEADER_BYTES),objectUrls:1,decodeCalls:1},browserOperationsExecuted:false,abortBeforeReadPassed:aborted,displayDimensionReference:'Root DOM native decode1988x3057; candidate browser display not executed',peakDecodeMemoryMeasured:false,resourceConclusion:'This accepted ordinary page avoids no decode; candidate adds bounded65536byte inspection. No measured peak-allocation benefit.',remainingAcceptance:['Actual oversized image rejected before object URL/decode','Actual PNG/GIF/WebP and animated/oriented headers and display','Browser first-page CPU/long tasks/peak memory and close/reopen/failure recovery','Existing PDF renderer actual stress acceptance'],disposition:'not-adopted-deferred-actual-acceptance'};
await writeFile(new URL('./actual.json',import.meta.url),JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify(receipt));
