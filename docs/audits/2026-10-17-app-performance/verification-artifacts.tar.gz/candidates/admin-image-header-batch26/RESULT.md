# PR-13 batch26: private header candidate, not adopted

The retained actual reader JPEG (875294 bytes, SHA72746c4dfda2a7494f61aaf8231b07c904fad4407d9650a71440e13e87d68b99) parses as1988x3057, matching root's native DOM decode. Its6077316pixels are below existing33554432threshold. Candidate inspection copies at most65536bytes; single Bun sample2.157ms. Both paths still require one image decode and one URL for this accepted page: those browser operation counts are source-derived expectations, not executed browser measurements. No decoder allocation or peak-memory saving was demonstrated.

The private helper handles PNG IHDR, GIF logical screen, and JPEG SOF dimensions. Actual ordinary repo logo PNG1254x1254 matches native sips. Unknown/incomplete headers, JPEG DNL zero height, and headers beyond64KiB fall back to the current decoder. WebP has no header parser in this candidate and retains that fallback. GIF/PNG/JPEG recognition does not certify animation/orientation/frame allocation. Four supplementary compatibility checks cover unknown/truncated input and cancellation; they are not actual oversized/animated stress inputs.

The private comic insertion awaits header admission through readerLoad before image creation/object URL, then checks the existing epoch. The existing postdecode check, displayed/pending URL release and failed/late completion ownership remain in the frozen candidate. No production source was edited.

Not adopted: actual oversized rejection before decode, candidate browser display/failure recovery/close-reopen plateau, full format/animation/orientation, first-page CPU/longtasks/peak memory and actual PDF stress acceptance remain absent. Candidate completeness and demonstrated safe resource gain are insufficient. No alternate parser/library or dependency was pursued.

Primary interpretation sources: [PNG IHDR](https://www.w3.org/TR/png-3/#11IHDR), [GIF89a logical screen descriptor](https://www.w3.org/Graphics/GIF/spec-gif89a.txt), [ITU T.81 Annex B.2.2 frame header](https://www.w3.org/Graphics/JPEG/itu-t81.pdf).
