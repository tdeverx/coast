import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {databaseObjectEpoch} from '../../probes/database-object-epoch';
const digest=(s:string)=>createHash('sha256').update(s).digest('hex');
const norm=(s:string)=>s.replace(/\s+/g,' ').trim();
export async function ensure0064(db:any){
 const sql=await readFile(new URL('../../../../../drizzle/0064_user_delete_cleanup.sql',import.meta.url),'utf8');
 const expected=[...sql.matchAll(/CREATE OR REPLACE FUNCTION (\w+)\(\) RETURNS trigger LANGUAGE plpgsql AS \$\$([\s\S]*?)\$\$;/g)].map(m=>({name:m[1],body:norm(m[2])}));
 if(expected.length!==3)throw Error('reviewed-0064-parse');
 async function inspect(){const rows=await db`select p.proname,p.prosrc,l.lanname,p.prorettype::regtype::text as returns from pg_proc p join pg_namespace n on n.oid=p.pronamespace join pg_language l on l.oid=p.prolang where n.nspname='public'and p.proname in('archive_connection_account','social_clean_activity_reactions','social_project_activity')and p.pronargs=0`;const[t]=await db`select t.tgtype::int as type,t.tgoldtable,t.tgnewtable,t.tgenabled,p.proname from pg_trigger t join pg_proc p on p.oid=t.tgfoid where t.tgrelid='public.social_activity'::regclass and t.tgname='social_activity_reactions'`;const functions=expected.map(e=>{const r=rows.find((r:any)=>r.proname===e.name);return{name:e.name,reviewedBodySha256:digest(e.body),installedBodySha256:r?digest(norm(r.prosrc)):null,exact:!!r&&norm(r.prosrc)===e.body&&r.lanname==='plpgsql'&&r.returns==='trigger'}});const trigger={...t,exact:!!t&&t.type===8&&t.tgoldtable==='deleted_activity_rows'&&t.tgnewtable===null&&t.tgenabled==='O'&&t.proname==='social_clean_activity_reactions'};return{functions,trigger,exact:functions.every(f=>f.exact)&&trigger.exact}}
 const beforeEpoch=await databaseObjectEpoch(db),before=await inspect();
 if(!before.exact){for(const statement of sql.split('--> statement-breakpoint'))if(statement.trim())await db.unsafe(statement)}
 const after=await inspect(),afterEpoch=await databaseObjectEpoch(db);if(!after.exact)throw Error('owned-copy-0064-parity-failed');
 return{migrationPath:'drizzle/0064_user_delete_cleanup.sql',migrationSha256:digest(sql),sourceCopyAlreadyCurrent:before.exact,installedExactMigrationOnlyOwnedCopy:!before.exact,before,after,beforeEpoch,afterEpoch};
}
