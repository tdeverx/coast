# PJ-08 final partial batching acceptance

**Recommend the final candidate as a partial SQL batching improvement.** The whole-track transaction remains unchanged; PJ-08's bounded-transaction/checkpoint work stays deferred. Runtime owners were not edited.

The separately frozen `final-candidate.patch` removes unused importer imports and candidate-only prose. It also maps returned rows by deterministic batch ID and emits native webhook events in submitted occurrence order, so emission order does not depend on SQL RETURNING order. Original measured sources, patch, receipt and manifest remain unchanged.

The owned actual-data copy used the real admin, actual Jellyfin account identity and real track. Controlled existing occurrence indices were0,98,99,100,101,199,200 with target205. Both DEFAULT and final candidate inserted exactly198 missing occurrences; all205 retained deterministic source IDs, jellyfin source and unknown-date semantics. This is controlled delta evidence, not observed usage.

A temporary record-only subscription for the actual admin exercised native `emitWebhook` and outbox preparation. All198 new occurrences had exactly one distinct prepared event/outbox row, the complete persisted event equalled its native prepared payload, each payload referenced the correct returned listen/date/unknown flag, and event preparation order matched missing source occurrence order across99/100/101. Existing occurrences emitted no duplicate events. No network or delivery ran.

All205 per-row social projections retained exact listen/source/date associations. The actual trigger inventory confirms music_progress has only content-revision statement triggers; music_listens retains its per-row social trigger and content-revision triggers. Revisions coalesce per transaction: both versions increased admin tracking and social once; global revisions were unchanged. Thus fewer intermediate progress writes omit no authoritative progress row-trigger side effects in this actual schema. Final progress count205 and resume position0 agree.

Failure injected at the100th native webhook preparation/execution boundary rolls back both versions' complete prior history, progress, social projection, outbox and revision state exactly. The candidate failure occurs after entering its second history batch, so earlier batched work also rolls back. All30 acceptance checks pass.

The active-subscription205-occurrence single-run elapsed samples were DEFAULT728.44ms and candidate1012.34ms. This finite run demonstrates correctness, not a universal latency improvement; native per-event webhook work still dominates when subscribed. The earlier no-active-subscription10,000-delta measurements (30,031→10,231 statements and16.29→7.27s) apply to the original batching form; the final candidate additionally performs a bounded batch-ID map/order walk. Full bounded-transaction acceptance remains unsatisfied.

One follow-up harness attempt failed on DEFAULT alone because JSON.stringify compared object property order after JSONB canonicalization. Its exact source/receipt are retained; one correction used structural deep equality and the same final candidate/scenarios passed. The owned-copy marker was verified, the database copy dropped and absence proved, and temporary runtime files removed. Source clone and normal application state were untouched.
