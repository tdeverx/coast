# Exact final-source PJ-08 verification

The original native comparison was run once against the final candidate snapshots, including the deterministic returned-batch-ID event-order map and cleaned importer imports. The new probe differs from the original only in three source snapshot selections. No scenarios, assertions or instrumentation changed; no expanded workload or repeat benchmarking was added.

All43 original checks passed at controlled actual-admin/real-track deltas0/1/100/10000: complete normalized occurrence/progress/sync equivalence, unchanged replay, decrease preserving history, generation/lease rejection, native transaction rollback and no provider traffic. These are controlled counts, not observed usage.

| Controlled delta | Native SQL DEFAULT → final | History INSERTs | Progress writes | Total ms | Longest transaction ms | WAL bytes |
| --- | --- | --- | --- | --- | --- | --- |
| 0 | 26 → 26 | 0 → 0 | 1 → 1 | 24.13 → 19.61 | 13.62 → 11.30 | 14104 → 2512 |
| 1 | 34 → 34 | 1 → 1 | 2 → 2 | 30.61 → 14.91 | 22.51 → 10.54 | 4680 → 3784 |
| 100 | 331 → 133 | 100 → 1 | 101 → 2 | 191.70 → 104.71 | 186.42 → 98.69 | 131264 → 117448 |
| 10000 | 30031 → 10231 | 10000 → 100 | 10001 → 101 | 28579.40 → 19104.60 | 28572.81 → 19094.58 | 13531128 → 11839728 |

These are descriptive single-run local measurements. WAL includes PostgreSQL background effects and timings varied materially from the earlier source run. Native BEGIN/COMMIT and setup/assertion SQL are outside the statement counter. The final source still executes10000 history rows inside one transaction; its100-row INSERT batches do not create a safe checkpoint. Subscription preparation still executes per occurrence, and the separate active-subscription acceptance run was slower for the candidate. Recommend the source only as the verified partial statement-reduction change; the full bounded-transaction fix remains deferred.

Final persistence SHA-256: `049aca51bfd61c2c8fa973e7ce51572ecf1bf2c94a78fb652c58f8fb0d197977`.
Final importer SHA-256: `dcc6b652de5a4f31795a901c09430b16334d1ff9302f9ff6babcf2a961709c11`.
These hashes match the frozen final candidate and the persistence source used by the30-check occurrence/effects run. All prior manifests remain valid. Owned-copy marker verified, copy dropped/absence proved, source clone untouched, temporary runtime removed. Runtime source owners remain unchanged.
