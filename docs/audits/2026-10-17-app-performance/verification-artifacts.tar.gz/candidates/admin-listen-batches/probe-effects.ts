import {getDb,getSql,closeDb} from '../../../../../src/lib/server/db';
import * as s from '../../../../../src/lib/server/db/schema';
import {eq,and,sql as q} from 'drizzle-orm';
import {createHash} from 'node:crypto';
import {isDeepStrictEqual} from 'node:util';
import {readFile,writeFile} from 'node:fs/promises';
const root='/Users/admin/Documents/ChatGPT/coast-new',dir=import.meta.dir,runId=process.env.COAST_AVATAR_RUN_ID!,url=new URL(process.env.DATABASE_URL!);
if(process.env.COAST_AUDIT_MATCHED_AVATAR_COPY!=='1'||url.hostname!=='127.0.0.1'||url.port!=='55432'||!/^\/coast_audit_fix_actual_[a-f0-9]{32}$/.test(url.pathname))throw Error('Owned copy required');
const db=getDb(),sql=getSql(),result:any={runId,status:'running',boundary:'Same frozen candidate; actual admin/catalogue; controlled existing deterministic occurrences and temporary record-only native webhook subscription on owned disposable copy; no delivery.',checks:{},scenarios:[],externalCalls:0};
const check=(v:any,k:string)=>{result.checks[k]=!!v;if(!v)throw Error(k)};const hash=(s:string)=>createHash('sha256').update(s).digest('hex');
const oldFetch=globalThis.fetch;globalThis.fetch=(async()=>{result.externalCalls++;throw Error('External forbidden')})as any;
async function compile(source:string,base:string,name:string){const code=new Bun.Transpiler({loader:'ts'}).transformSync(source).replace(/(from\s*|import\s*\()(['"])([^'"]+)\2/g,(_m,prefix,_quote,p)=>prefix+JSON.stringify(p.startsWith('.')?new URL(p,base).pathname:p.startsWith('$lib/')?root+'/src/lib/'+p.slice(5):import.meta.resolve(p)));const path=process.env.COAST_DATA_DIR+'/'+name+'.js';await Bun.write(path,code);return import(path)}
try{
 const[marker]=await sql`select shobj_description(oid,'pg_database') as marker from pg_database where datname=current_database()`;check(marker.marker==='coast-avatar-copy:'+runId,'owned-marker');
 const[admin]=await sql`select id from users where username='admin' and role='admin' and not disabled`;check(admin,'actual-admin');
 const[account]=await sql`select id,sync_account_id as account from provider_connections where user_id=${admin.id} and instance_id in(select id from provider_instances where provider='jellyfin') order by id limit 1`;check(account,'actual-account');const accountId=account.account??account.id;
 const[track]=await sql`select id from music_works where kind='track' order by id limit 1`;check(track,'actual-track');
 const[api]=await sql`select coast_feature_enabled(${admin.id}::uuid,'api') as enabled`;check(api.enabled,'actual-api-enabled');
 const triggers=await sql`select c.relname,t.tgname,pg_get_triggerdef(t.oid) as trigger,pg_get_functiondef(t.tgfoid) as function from pg_trigger t join pg_class c on c.oid=t.tgrelid where c.relname in ('music_listens','music_progress') and not t.tgisinternal order by c.relname,t.tgname`;
 result.triggerInventory=triggers.map(t=>({table:t.relname,name:t.tgname,triggerHash:hash(t.trigger),functionHash:hash(t.function)}));
 await writeFile(dir+'/effects-trigger-inventory.sql.txt',triggers.map(t=>t.trigger+';\n'+t.function).join('\n\n'));
 check(triggers.filter(t=>t.relname==='music_progress').every(t=>t.function.includes('FUNCTION public.coast_content_revision_trigger()')),'progress-only-content-revision-triggers');
 const modules:any={};result.frozenSourceHashes={};for(const version of ['default','candidate']){const source=await readFile(dir+'/persistence.'+(version==='default'?'before':'final-candidate')+'.ts.txt','utf8');result.frozenSourceHashes[version]=hash(source);modules[version]=await compile(source,new URL('../../../../../src/lib/music/persistence.server.ts',import.meta.url).href,'effects-'+version)}
 const seed=[0,98,99,100,101,199,200],end=205,missing=Array.from({length:end},(_,i)=>i).filter(i=>!seed.includes(i));
 const batchToIndex=new Map(Array.from({length:end},(_,i)=>[modules.default.importedListenBatch(accountId,track.id,i),i]));
 const subscription=crypto.randomUUID(),token=crypto.randomUUID();
 await sql`update api_webhooks set enabled=false where user_id=${admin.id}`;
 await sql`insert into api_tokens(id,user_id,name,token_hash,scopes,expires_at) values(${token},${admin.id},'private-candidate-record-only',${crypto.randomUUID()},'[]'::jsonb,now()+interval '1 hour')`;
 await sql`insert into api_webhooks(id,user_id,token_id,url,secret,events,enabled) values(${subscription},${admin.id},${token},'https://example.invalid/no-delivery','record-only-not-deliverable','["music.listened"]'::jsonb,true)`;
 const revisions=()=>sql`select scope,domain,revision::text as revision from content_revisions where scope in('global',${admin.id}::text) order by scope,domain`;
 const state=async()=>({listens:await sql`select * from music_listens where user_id=${admin.id} and track_id=${track.id} order by batch_id`,progress:await sql`select * from music_progress where user_id=${admin.id} and track_id=${track.id}`,social:await sql`select a.* from social_activity a join music_listens l on a.source_key='music_listens:'||l.id where l.user_id=${admin.id} and l.track_id=${track.id} order by a.source_key`,outbox:await sql`select * from outbox_actions where user_id=${admin.id} and payload->>'subscriptionId'=${subscription} order by id`,revisions:await revisions()});
 async function reset(){await sql`delete from outbox_actions where user_id=${admin.id} and payload->>'subscriptionId'=${subscription}`;await sql`delete from music_listens where user_id=${admin.id} and track_id=${track.id}`;await sql`delete from music_progress where user_id=${admin.id} and track_id=${track.id}`;await db.transaction(async tx=>{for(const i of seed)await modules.default.recordMusicListen(tx,admin.id,track.id,modules.default.importedListenBatch(accountId,track.id,i),'jellyfin',undefined,false)});await sql`delete from outbox_actions where user_id=${admin.id} and payload->>'subscriptionId'=${subscription}`;await sql`update music_progress set position_seconds=99 where user_id=${admin.id} and track_id=${track.id}`}
 for(const mode of ['commit','rollback-mid-event']){
  const pair:any[]=[];
  for(const version of ['default','candidate']){
   await reset();const before=await state(),prepared:any[]=[];let caught=false,added=0,nativeEventWrites=0;const start=performance.now();
   try{await db.transaction(async tx=>{
    const insert=tx.insert.bind(tx);(tx as any).insert=(table:any)=>{const builder=insert(table);if(table!==s.outboxActions)return builder;const values=builder.values.bind(builder);builder.values=(input:any)=>{const rows=Array.isArray(input)?input:[input];for(const row of rows)if(row.payload?.subscriptionId===subscription){prepared.push(row.payload.event);nativeEventWrites++}return values(input)};return builder};
    const session=(tx as any).session,logger=session.logger;session.logger={logQuery(text:string,params:any[]){logger.logQuery(text,params);if(mode==='rollback-mid-event'&&text.startsWith('insert into "outbox_actions"')&&nativeEventWrites===100)throw Error('controlled-mid-webhook-rollback')}};
    if(version==='default'){for(let i=0;i<end;i++)if(await modules.default.recordMusicListen(tx,admin.id,track.id,modules.default.importedListenBatch(accountId,track.id,i),'jellyfin',undefined,false))added++}
    else added=await modules.candidate.recordImportedMusicListens(tx,admin.id,track.id,accountId,0,end);
    // Exact final native importMusic assignment.
    await tx.insert(s.musicProgress).values({userId:admin.id,trackId:track.id,playCount:end}).onConflictDoUpdate({target:[s.musicProgress.userId,s.musicProgress.trackId],set:{playCount:end,updatedAt:new Date()}});
   })}catch(e:any){if(e.message==='controlled-mid-webhook-rollback'||e.cause?.message==='controlled-mid-webhook-rollback')caught=true;else throw e}
   const after=await state(),elapsedMs=performance.now()-start;
   if(mode==='rollback-mid-event'){
    check(caught,version+'-midway-failure-triggered');check(prepared.length===100,version+'-midway-100-prepared');check(JSON.stringify(before)===JSON.stringify(after),version+'-midway-full-state-and-revision-rollback');pair.push({version,elapsedMs,preparedBeforeRollback:prepared.length,exactRollback:true});continue;
   }
   check(!caught&&added===missing.length,version+'-mixed-id-exact-added-count');check(after.listens.length===end&&after.progress[0]?.play_count===end&&after.progress[0]?.position_seconds===0,version+'-final-source-count-progress');
   const listens=new Map(after.listens.map(l=>[l.id,l]));const preparedOrder=prepared.map(e=>batchToIndex.get(listens.get(e.data.listenId)?.batch_id));
   check(JSON.stringify(preparedOrder)===JSON.stringify(missing),version+'-native-webhook-preparation-order');
   check(prepared.every(e=>e.type==='music.listened'&&e.data.workId===track.id&&!e.data.occurredAtKnown&&e.data.occurredAt===listens.get(e.data.listenId)?.occurred_at.toISOString()),version+'-per-event-listen-source-date-association');
   check(new Set(prepared.map(e=>e.id)).size===missing.length,version+'-event-identities-unique');
   const nativeEvents=after.outbox.map(o=>o.payload.event);check(nativeEvents.length===missing.length,version+'-one-native-outbox-per-new-occurrence');
   check(nativeEvents.every(e=>prepared.some(p=>isDeepStrictEqual(e,p))),version+'-full-event-payload-persisted');
   check(after.social.length===end&&after.social.every(a=>{const l=listens.get(a.source_key.slice('music_listens:'.length));return l&&a.source==='jellyfin'&&a.event_kind==='listen'&&!a.date_known&&a.occurred_at.getTime()===l.occurred_at.getTime()}),version+'-complete-social-trigger-source-association');
   const delta=after.revisions.map(r=>({scope:r.scope==='global'?'global':'admin',domain:r.domain,delta:Number(r.revision)-Number(before.revisions.find(b=>b.scope===r.scope&&b.domain===r.domain)?.revision??0)}));
   const normalized={occurrences:after.listens.map(l=>({index:batchToIndex.get(l.batch_id),source:l.source,known:l.occurred_at_known})).sort((a,b)=>a.index-b.index),eventOrder:preparedOrder,eventTypes:prepared.map(e=>({type:e.type,known:e.data.occurredAtKnown})),progress:after.progress.map(p=>({count:p.play_count,position:p.position_seconds,duration:p.duration_seconds})),social:after.social.map(a=>({index:batchToIndex.get(listens.get(a.source_key.slice('music_listens:'.length)).batch_id),kind:a.event_kind,source:a.source,known:a.date_known})).sort((a,b)=>a.index-b.index),revisionDelta:delta};
   pair.push({version,elapsedMs,seedIndices:seed,inserted:added,preparedEvents:prepared.length,fullNormalizedHash:hash(JSON.stringify(normalized)),eventAssociationOrderHash:hash(JSON.stringify(preparedOrder)),revisionDelta:delta,maxBatchRows:version==='candidate'?100:1});
  }
  if(mode==='commit')check(pair[0].fullNormalizedHash===pair[1].fullNormalizedHash,'complete-events-social-progress-revisions-equivalent');result.scenarios.push({mode,versions:pair});
 }
 check(result.externalCalls===0,'zero-network-or-delivery');result.status='passed';result.assessment='Same frozen candidate passes finite mixed-occurrence, native webhook preparation association/order, trigger/revision and mid-event rollback acceptance. This supports partial SQL batching adoption only; whole-track transaction remains unchanged.';
}catch(e:any){result.status='failed';result.failure={message:String(e.message).split('\nparams:')[0],cause:e.cause?.message,code:e.cause?.code??e.code};process.exitCode=1}
finally{globalThis.fetch=oldFetch;await writeFile(process.argv[2],JSON.stringify(result,null,2));await closeDb()}
