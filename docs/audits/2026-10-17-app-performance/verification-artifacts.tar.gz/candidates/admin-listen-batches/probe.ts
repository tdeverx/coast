import {getDb,getSql,closeDb} from '../../../../../src/lib/server/db';
import {jobExecution,JobYield} from '../../../../../src/lib/server/queue/execution';
import {createHash} from 'node:crypto';
import {writeFile,readFile} from 'node:fs/promises';
const root='/Users/admin/Documents/ChatGPT/coast-new',dir=import.meta.dir,runId=process.env.COAST_AVATAR_RUN_ID!,url=new URL(process.env.DATABASE_URL!);
if(process.env.COAST_AUDIT_MATCHED_AVATAR_COPY!=='1'||url.hostname!=='127.0.0.1'||url.port!=='55432'||!/^\/coast_audit_fix_actual_[a-f0-9]{32}$/.test(url.pathname))throw Error('Owned copy required');
const db=getDb(),sql=getSql(),result:any={runId,status:'running',boundary:'Controlled private-copy deltas on actual admin and actual catalogue track. Native extracted importMusic function and reconciliation/persistence; no provider response substitutes. Candidate batching remains one whole-track transaction.',checks:{},comparisons:[],sourceHashes:{},externalCalls:0};
const check=(v:any,k:string)=>{result.checks[k]=!!v;if(!v)throw Error(k)};
const hash=(s:string)=>createHash('sha256').update(s).digest('hex');
const originalTx=db.transaction.bind(db),session=(db as any).session,oldLogger=session.logger;let meter:any=null;
session.options.logger=session.logger={logQuery(q:string,p:any[]){if(meter){meter.statements++;meter.maxParameters=Math.max(meter.maxParameters,p.length);if(q.startsWith('insert into "music_listens"'))meter.listenInserts++;if(q.startsWith('insert into "music_progress"'))meter.progressWrites++;}}};
(db as any).transaction=(fn:any)=>originalTx(async tx=>{const start=performance.now();try{return await fn(tx)}finally{if(meter){meter.transactions++;meter.longestTransactionMs=Math.max(meter.longestTransactionMs,performance.now()-start)}}});
const oldFetch=globalThis.fetch;globalThis.fetch=(async()=>{result.externalCalls++;throw Error('External forbidden')})as any;
async function compile(source:string,base:string,name:string){
 const code=new Bun.Transpiler({loader:'ts'}).transformSync(source).replace(/(from\s*|import\s*\()(['"])([^'"]+)\2/g,(_m,prefix,_quote,p)=>prefix+JSON.stringify(p.startsWith('.')?new URL(p,base).pathname:p.startsWith('$lib/')?root+'/src/lib/'+p.slice(5):import.meta.resolve(p)));
 const path=process.env.COAST_DATA_DIR+'/'+name+'.js';await Bun.write(path,code);return import(path);
}
try{
 const[marker]=await sql`select shobj_description(oid,'pg_database') as marker from pg_database where datname=current_database()`;check(marker.marker==='coast-avatar-copy:'+runId,'owned-marker');
 const[admin]=await sql`select id from users where username='admin' and role='admin' and not disabled`;check(admin,'actual-admin');
 const[connection]=await sql`select id,account_generation as "accountGeneration",sync_account_id as "syncAccountId" from provider_connections where user_id=${admin.id} and instance_id in(select id from provider_instances where provider='jellyfin') order by id limit 1`;check(connection,'actual-jellyfin-account');
 const[track]=await sql`select id from music_works where kind='track' order by id limit 1`;check(track,'actual-track');
 // Private-copy controlled account availability only; generation identity stays actual.
 await sql`update provider_connections set status='connected' where id=${connection.id}`;
 const jf=await readFile(dir+'/jellyfin.before.ts.txt','utf8');const a=jf.indexOf('  async function importMusic('),b=jf.indexOf('  // Like screen copies',a);check(a>=0&&b>a,'native-function-extraction');
 const body=jf.slice(a,b),modules:any={};
 for(const version of ['default','candidate']){
  const p=await readFile(dir+'/persistence.'+(version==='default'?'before':'candidate')+'.ts.txt','utf8');result.sourceHashes[version+'Persistence']=hash(p);
  const pm=await compile(p,new URL('../../../../../src/lib/music/persistence.server.ts',import.meta.url).href,'persistence-'+version);
  const j=await readFile(dir+'/jellyfin.'+(version==='default'?'before':'candidate')+'.ts.txt','utf8');result.sourceHashes[version+'Importer']=hash(j);
  const native=j.slice(j.indexOf('  async function importMusic('),j.indexOf('  // Like screen copies',j.indexOf('  async function importMusic(')));
  const nativeCode=`import {reconcileProviderValue,localSyncValue} from '${root}/src/lib/sync/values.server.ts';import {syncValues,musicProgress} from '${root}/src/lib/server/db/schema.ts';import {and,eq} from 'drizzle-orm';export function owner(userId,connectionId,connection,recordMusicListen,importedListenBatch,recordImportedMusicListens){const userScope=true,importPlayback=true;${native};return importMusic}`;
  const mod=await compile(nativeCode,import.meta.url,'importer-'+version);modules[version]=mod.owner(admin.id,connection.id,connection,pm.recordMusicListen,pm.importedListenBatch,pm.recordImportedMusicListens);
 }
 for(const relative of ['src/lib/sync/values.server.ts','src/lib/server/queue/execution.ts','src/lib/server/public-api/webhooks.server.ts'])result.sourceHashes[relative]=hash(await readFile(root+'/'+relative,'utf8'));
 // Reuse a real native job identity solely to test exact lease fencing in rollback.
 const[job]=await sql`select id,attempts from outbox_actions where user_id=${admin.id} order by created_at limit 1`;check(job,'actual-admin-job');
 async function reset(){
  await sql`delete from music_listens where user_id=${admin.id} and track_id=${track.id}`;
  await sql`delete from music_progress where user_id=${admin.id} and track_id=${track.id}`;
  await sql`delete from sync_values where media_id=${track.id} and connection_id in(select id from provider_connections where user_id=${admin.id})`;
  await sql`delete from outbox_actions where user_id=${admin.id} and payload->>'mediaId'=${track.id}`;
 }
 const state=async()=>{
  const listens=await sql`select batch_id,source,occurred_at_known,occurred_at,created_at from music_listens where user_id=${admin.id} and track_id=${track.id} order by batch_id`;
  const progress=await sql`select play_count,position_seconds,duration_seconds from music_progress where user_id=${admin.id} and track_id=${track.id}`;
  const sync=await sql`select category,remote,agreed,conflict from sync_values where connection_id=${connection.id} and media_id=${track.id} order by category`;
  const[outbox]=await sql`select count(*)::int as count from outbox_actions where user_id=${admin.id} and payload->>'mediaId'=${track.id}`;
  return{listens: listens.map(r=>({batch:r.batch_id,source:r.source,known:r.occurred_at_known})),progress,sync,outbox,unknownDatesPresent:listens.every(r=>r.occurred_at instanceof Date&&r.created_at instanceof Date)};
 };
 const item=(count:number)=>({id:track.id,kind:'track',playCount:count,positionSeconds:0,durationSeconds:0});
 for(const count of [0,1,100,10000]){
  const pair:any[]=[];
  for(const version of ['default','candidate']){
   await reset();const before=await state();const[walBefore]=await sql`select pg_current_wal_insert_lsn() as lsn`;
   meter={statements:0,listenInserts:0,progressWrites:0,maxParameters:0,transactions:0,longestTransactionMs:0};const start=performance.now();await modules[version]({workId:track.id},item(count));const elapsedMs=performance.now()-start,resources=meter;meter=null;
   const after=await state();const[wal]=await sql`select pg_wal_lsn_diff(pg_current_wal_insert_lsn(),${walBefore.lsn})::text as bytes`;
   check(after.listens.length===count,version+count+'-exact-history-count');check(after.listens.every(r=>r.source==='jellyfin'&&!r.known)&&after.unknownDatesPresent,version+count+'-unknown-date-evidence');
   const beforeReplay=JSON.stringify(after);await modules[version]({workId:track.id},item(count));const replay=await state();check(JSON.stringify(replay)===beforeReplay,version+count+'-idempotent-replay');
   pair.push({version,elapsedMs,resources,walBytes:Number(wal.bytes),rowsInHistoryTransaction:count,beforeHash:hash(JSON.stringify(before)),afterHash:hash(JSON.stringify(after)),afterSummary:{listens:after.listens.length,progress:after.progress,sync:after.sync,outbox:after.outbox},fullNormalizedEventHash:hash(JSON.stringify(after.listens))});
  }
  check(pair[0].afterHash===pair[1].afterHash,'delta'+count+'-complete-normalized-native-equivalence');result.comparisons.push({controlledDelta:count,observedUsage:false,versions:pair});
 }
 for(const version of ['default','candidate']){
  await reset();await modules[version]({workId:track.id},item(100));const before=await state();
  await modules[version]({workId:track.id},item(1));const decrease=await state();check(decrease.listens.length===100&&decrease.progress[0]?.play_count===1,version+'-decrease-preserves-history');
  // Native generation rejection rolls back all work without changing actual generation.
  const wrong={...connection,accountGeneration:crypto.randomUUID()};
  const p=await readFile(dir+'/jellyfin.'+(version==='default'?'before':'candidate')+'.ts.txt','utf8');
  // The connection object captured by extracted function is shared; restore in finally.
  const generation=connection.accountGeneration;connection.accountGeneration=wrong.accountGeneration;let rejected=false;
  try{await modules[version]({workId:track.id},item(101))}catch{rejected=true}finally{connection.accountGeneration=generation}
  check(rejected&&JSON.stringify(await state())===JSON.stringify(decrease),version+'-generation-reject-exact-state');
  // Force an actual transaction exception after owner apply; native DB rollback must remove every listen and derived change.
  const txNow=(db as any).transaction;(db as any).transaction=(fn:any)=>originalTx(async tx=>{await fn(tx);throw Error('controlled-rollback')});let rolled=false;
  try{await modules[version]({workId:track.id},item(101))}catch{rolled=true}finally{(db as any).transaction=txNow}
  check(rolled&&JSON.stringify(await state())===JSON.stringify(decrease),version+'-rollback-exact-state');
  let leaseRejected=false;try{await jobExecution.run({id:job.id,attempts:job.attempts+99999,purpose:'background',started:performance.now(),checkpoints:0},()=>modules[version]({workId:track.id},item(101)))}catch(e){leaseRejected=e instanceof JobYield}
  check(leaseRejected&&JSON.stringify(await state())===JSON.stringify(decrease),version+'-lease-reject-exact-state');
 }
 check(result.externalCalls===0,'no-provider-traffic');result.status='measured-design-blocked';result.designDecision='Candidate reduces SQL round trips while preserving exact per-listen evidence, but all 10000 rows remain in one reconciliation transaction. Splitting commits exposes partial playCount and sync agreement to user writes/conflict classification; existing item cursor only advances after entire importMusic. Need explicit approval of resumable partial-history semantics/checkpoint contract before bounded transaction repair.';
}catch(e:any){result.status='failed';result.failure={message:String(e.message).split('\nparams:')[0],cause:e.cause?.message,code:e.cause?.code??e.code};process.exitCode=1}
finally{meter=null;(db as any).transaction=originalTx;session.options.logger=session.logger=oldLogger;globalThis.fetch=oldFetch;await writeFile(process.argv[2],JSON.stringify(result,null,2));await closeDb()}
