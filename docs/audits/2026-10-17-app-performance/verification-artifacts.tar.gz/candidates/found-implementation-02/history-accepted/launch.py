import fcntl,pathlib,hashlib,json,sys,subprocess,os
folder=pathlib.Path('/private/tmp/coast-history-found-v2');expected=sys.argv[1]
assert hashlib.sha256((folder/'plan.json').read_bytes()).hexdigest()==expected
plan=json.loads((folder/'plan.json').read_text());assert hashlib.sha256(pathlib.Path('/private/tmp/coast-fixes-run.py').read_bytes()).hexdigest()==plan['approvedRunnerSha256']
with open('/private/tmp/coast-actual-clone-execution.lock','a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 result=subprocess.run(['python3','/private/tmp/coast-fixes-run.py',str(folder/'pilot.ts'),str(folder/'pilot-actual.json')],env={**os.environ,'COAST_AUDIT_PUBLIC_EDGES_LEASE':'1','COAST_AUDIT_PUBLIC_EDGES_PLAN_SHA':expected})
 print(json.dumps({'exit':result.returncode,'leaseReleasedAtParentExit':True}));raise SystemExit(result.returncode)
