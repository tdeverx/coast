from pathlib import Path
root=Path('/Users/admin/Documents/ChatGPT/coast-new');p=root/'src/lib/core/tracking/service.server.ts';s=p.read_text();old='''      .where(
        and(
          eq(upNext.userId, userId),
          sql`${upNext.mediaId} in (
      with recursive parents(id) as (
        select ${input.mediaId}::uuid
        union select r.parent_id from media_relationships r join parents p on r.child_id = p.id
      )
      select id from parents
      union select show_id from episodes where media_id = ${input.mediaId}
      union select season_id from episodes where media_id = ${input.mediaId}
    )`
        )
      )'''
assert s.count(old)==1
helper='''/** Exact queue consumption membership shared by tracking and Continue Undo snapshots. */
export function consumedQueueCondition(userId: string, mediaId: string) {
  return and(
    eq(upNext.userId, userId),
    sql`${upNext.mediaId} in (
      with recursive parents(id) as (
        select ${mediaId}::uuid
        union select r.parent_id from media_relationships r join parents p on r.child_id = p.id
      )
      select id from parents
      union select show_id from episodes where media_id = ${mediaId}
      union select season_id from episodes where media_id = ${mediaId}
    )`
  );
}
'''
s=s.replace(old,'      .where(consumedQueueCondition(userId, input.mediaId))');at=s.index('async function ensureProjection(');s=s[:at]+helper+s[at:];p.write_text(s)
p=root/'src/lib/core/tracking/continue.server.ts';s=p.read_text().replace("import { trackInTransaction } from './service.server';","import { consumedQueueCondition, trackInTransaction } from './service.server';");needle='const queued = await tx.select().from(s.upNext).where(eq(s.upNext.userId, userId));';assert s.count(needle)==1;s=s.replace(needle,'const queued = await tx.select().from(s.upNext).where(consumedQueueCondition(userId, mediaId));');p.write_text(s)
