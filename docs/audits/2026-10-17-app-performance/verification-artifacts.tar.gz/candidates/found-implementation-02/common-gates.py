from pathlib import Path
s=Path('/private/tmp/coast-library-membership-gates.py').read_text().replace('implementation-20261018-library-membership','implementation-found-02');exec(compile(s,'found-02-gates','exec'))
