from pathlib import Path
p=Path('src/lib/ui/client.ts');s=p.read_text();s=s.replace('  return { api, change };','  const changeMany = <T = unknown>(paths: readonly string[], body?: unknown, method = \'POST\') => orderedChanges<T>(api, afterChange, paths, body, method);\n  return { api, change, changeMany };',1)
anchor='/** A failed page refresh cannot turn an acknowledged command into a failed write. */'
add='''/** Keep each command acknowledgement, with one completion refresh for a same-domain action. */
export function changeMany<T = unknown>(paths: readonly string[], body?: unknown, method = 'POST') {
  return orderedChanges<T>(api, refreshAfterChange, paths, body, method);
}
async function orderedChanges<T>(
  deliver: typeof api,
  afterChange: (path: string) => Promise<void>,
  paths: readonly string[],
  body: unknown,
  method: string
): Promise<T[]> {
  const commands = [...paths];
  if (!commands.length) return [];
  const domain = commands[0].split('/')[0];
  if (commands.some(path => path.split('/')[0] !== domain))
    throw new Error('A grouped action must use one command domain.');
  const results: T[] = [];
  try {
    for (const path of commands) results.push(await deliver<T>(path, body, method));
    return results;
  } finally {
    // A failed later command still leaves acknowledged earlier commands visible.
    if (results.length) await acknowledgeRefresh(() => afterChange(commands[0]));
  }
}
'''
assert s.count(anchor)==1;s=s.replace(anchor,add+anchor);p.write_text(s)
p=Path('src/lib/ui/client-context.ts');s=p.read_text().replace('api, change, createApiClient','api, change, changeMany, createApiClient').replace('change: typeof change;','change: typeof change; changeMany: typeof changeMany;').replace('?? { api, change, fetch:','?? { api, change, changeMany, fetch:');p.write_text(s)
p=Path('src/lib/ui/components/WorkActions.svelte');s=p.read_text().replace('const {change}=useClient();','const {changeMany}=useClient();');needle="async()=>{for(const id of recommendationIds)await change(`social/recommendations/${id}`,{action});}";assert s.count(needle)==1;s=s.replace(needle,"()=>changeMany(recommendationIds.map(id=>`social/recommendations/${id}`),{action})");p.write_text(s)
