import os,json,subprocess,pathlib,urllib.parse,fcntl,uuid
root=pathlib.Path('/Users/admin/Documents/ChatGPT/coast-new')
with open('/private/tmp/coast-actual-clone-execution.lock','w')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 source=pathlib.Path('/private/tmp/coast-app-fixes-clone-name').read_text().strip()
 info=json.loads(subprocess.check_output(['container','inspect','coast-new-test-db']))[0]
 settings=dict(v.split('=',1)for v in info['configuration']['initProcess']['environment']if'='in v)
 url='postgresql://'+urllib.parse.quote(settings['POSTGRES_USER'],safe='')+':'+urllib.parse.quote(settings['POSTGRES_PASSWORD'],safe='')+'@127.0.0.1:55432/'+source
 run_id=str(uuid.uuid4())
 env={**os.environ,'DATABASE_URL':url,'COAST_AVATAR_PARENT_DATABASE':source,'COAST_AVATAR_RUN_ID':run_id}
 with open('/private/tmp/coast-finalization-rollback-private.log','w')as log:
  result=subprocess.run([str(root/'.tools/bun-1.4.3/bun-darwin-aarch64/bun'),str(root/'docs/audits/2026-10-17-app-performance/candidates/admin-jellyfin-finalization/wrapper-rollback.ts')],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 try:receipt=json.loads(pathlib.Path(root/'docs/audits/2026-10-17-app-performance/candidates/admin-jellyfin-finalization/actual-rollback.json').read_text());fresh=receipt.get('runId')==run_id
 except Exception:fresh=False
 print(json.dumps({'exit':result.returncode,'freshReceipt':fresh,'runId':run_id}))
 raise SystemExit(result.returncode)
