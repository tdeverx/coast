// Isolated harness pool pin: TEMP evidence tables and native commands share one connection.
globalThis[Symbol.for('coast.database.pool')]=new Bun.SQL(process.env.DATABASE_URL!,{max:1,idleTimeout:0,connectionTimeout:10,connection:{jit:'off'}});
await import('./probe.ts');
