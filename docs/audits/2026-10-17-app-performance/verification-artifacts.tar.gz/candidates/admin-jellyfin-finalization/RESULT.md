# PJ-07 one-candidate native finalization evidence

**Disposition: resource-positive/deferred-concurrency-acceptance. The candidate is not adopted.** Bounded local preparation is verified, but concurrent-edit acceptance exposes a preexisting deadlock in both DEFAULT and candidate. No runtime owner was edited. No alternative lock architecture was implemented. The adopted imported-listen function is byte-for-byte unchanged; baseline importer is the adopted PJ-08 final source `dcc6b652de5a4f31795a901c09430b16334d1ff9302f9ff6babcf2a961709c11`.

## Exact candidate

The existing `jellyfinScanProgressSchema` gets optional finalization subphase/cursor fields. The existing finalizing UI stage remains. Screen/music seeding reads at most100 rows and bulk-inserts their exact intents with ON CONFLICT DO NOTHING, preserving native changes. Enqueue reads/locks at most100 intents ordered by `(workId,category)`, retaining native enqueue/compaction. Each phase/cursor commits with its effects via the existing progress writer; `jobCheckpoint` runs only after commit. Completion and negative availability stay after required setup. Account-generation/reset/feature/attempt checks remain native at every transaction.

The same candidate includes the root-requested narrow version admission guard: stale/missing **versioned backfill** intent returns before adapter identity. Unversioned and manual command semantics remain unchanged. It does not promise exactly-once remote delivery or fence a remote write after admission.

## Actual dataset and controlled state

Before controls, the actual admin had62 nonempty screen rows,797 music-progress rows and0 reconciliation intents for the chosen real Jellyfin account. That does not claim natural reconcileTracking enablement or production pain. Controls used650 mapped real screen works (one held out from initial state), one genuinely unmapped actual movie, and121 mapped actual tracks. Controlled tracking/progress values and scan/settings/checkpoint/job state existed only in exact-marker owned copies. No users, catalogue identities or provider responses were fabricated.

Native DEFAULT/candidate finalization, report, fences, enqueue and checkpoint functions were executed on those records; the full scanner's provider traversal was not executed. Both produced771 exact normalized intents,770 mapped pending backfills, identical normalized completion/availability output, preserved unknown mappings/music counts, and one pending current-version backfill per intent.

| Resource | DEFAULT | Candidate |
| --- | ---: | ---: |
| Native ORM statements | 3102 | 2434 |
| Intent seed INSERT statements | 771 | 9 |
| Outbox INSERT statements | 770 | 770 |
| Maximum selected source rows | 650 | 100 |
| Maximum selected intent rows | 770 | 100 |
| Maximum ORM statements per transaction | 3087 | 305 |
| Transactions | 2 | 18 |
| Committed finalization checkpoints | 0 | 17 |
| Native checkpoint yields | 0 | 3 |
| Maximum observed progress JSON bytes at yield | — | 433 |
| Elapsed ms | 2558.83 | 1542.56 |
| Longest transaction ms | 1843.94 | 921.00 |
| WAL bytes over invocation | 78223552 | 55474784 |

These are single-run local samples. ORM counts exclude BEGIN/COMMIT, raw checkpoint/policy SQL (two per checkpoint), harness/setup/assertion SQL. WAL is not isolated from PostgreSQL background effects. Longest transaction is an upper bound on the account row-lock span, not a direct lock-hold measurement. Completion still performs its existing set-based negative-availability update;100 is the source/intent SELECT bound, not a claim that every final transaction changes at most100 total rows. The full account contained40380 availability rows; final unavailable count39586 agrees in both runs. Native compaction can also touch preexisting pending jobs/notifications per selected intent.

## Finite acceptance and rollback

The primary run passed56 assertions before its last harness comparison:17 committed pages/3 yields, open census/no premature negative evidence at each yield, lost response after a committed first page without reseeding/version rotation, insertion below an already committed cursor through the native intent owner, same-value edit version replacement, stale/deleted versioned-backfill identity rejection, current-version/manual/unversioned admission controls, and generation/reset/feature/attempt rejection before finalization effects.

The final primary assertion incorrectly compared pre-entry progress metadata with post-page rollback. The native entry report initializes the finalizing label/cursor metadata before entering the first page transaction; that is not page advancement. A rollback-only supplemental captured the exact state at native transaction admission after that initialization and passed all12 checks: full intent/outbox/progress/checkpoint/availability state hashes match after injected page failure, and entry report advances no cursor or setup/completion effect. No performance workload was repeated for that correction.

Version tests used a real `JellyfinAdapter` with its identity method trapped to throw at invocation; no response was returned and no transport ran. The obsolete DEFAULT reached that boundary once; final candidate reached it zero times. Current-version, versioned manual and unversioned controls each reached the disabled boundary once. Deleting the current intent also produced zero identity calls.

## Required concurrency result: existing lock cycle

One finite two-session schedule ran native manual intent/enqueue against the native finalization transaction on one actual mapped work. Primary paused after its account fence before intent selection. The independently connected native manual writer upserted the intent and reached the native outbox preparation; PostgreSQL proved that writer was waiting on the primary before release. After release:

| Version | Primary finalization | Native manual writer | Remaining intent/backfill |
| --- | --- | --- | --- |
| Candidate | completed | aborted:40P01 deadlock detected | 1 /1 |
| DEFAULT | completed | aborted:40P01 deadlock detected | 1 /1 |

The same schedule therefore demonstrates a **preexisting** account-row/advisory/FK lock cycle, rather than a new candidate-only failure. It does not establish clean concurrent-edit behavior. Statement and lock timeouts bounded the test. No lock redesign or alternate candidate was attempted. Root retained DEFAULT: required concurrent-edit acceptance is not clean and the candidate adds durable phase/cursor ownership. Return PJ-07 to the investigation backlog. This is not a slower candidate or a newly introduced deadlock. No isolated guard/lock alternative is adopted and no further redesign is attempted in this run.

## Limits and provenance

No provider replies, remote delivery or live queue-worker lane lifecycle were executed. Native committed checkpoint/JobYield behavior was executed; worker release is source-owned in `queue/index.ts` finally blocks and was not independently certified here. An edit after version admission but before a provider write remains an in-flight race unless the provider offers fencing. Local pending rows cannot establish exactly-once remote delivery.

Harness failures are retained separately: attempt1 used an invalid string method before native execution; attempt2 used connection-local TEMP evidence with an unpinned pool, after DEFAULT completed; the corrected single-connection run retained all completed comparison data and exposed only the progress-baseline assertion described above. Parent authorized correcting that test wiring. Separate bootstrap pins the pool before imports; peer/observer connections are explicitly independent only for the concurrency schedule. No tests fabricated network replies.

All owned database copies had exact run markers verified and were dropped with absence proven; source clone and normal application state stayed untouched. Candidate owner snapshots, exact patch, native harnesses, receipts and copied supporting owners accompany this note. Root owns adoption, integrated gates and central documentation.
