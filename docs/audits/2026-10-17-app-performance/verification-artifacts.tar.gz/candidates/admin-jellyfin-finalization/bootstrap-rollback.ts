globalThis[Symbol.for('coast.database.pool')]=new Bun.SQL(process.env.DATABASE_URL!,{max:1,idleTimeout:0,connectionTimeout:10,connection:{jit:'off'}});
await import('./probe-rollback.ts');
