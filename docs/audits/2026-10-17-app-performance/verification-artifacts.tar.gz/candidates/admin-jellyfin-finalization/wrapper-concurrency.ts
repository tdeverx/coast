import {mkdtemp,rm,readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
const root='/Users/admin/Documents/ChatGPT/coast-new',runId=process.env.COAST_AVATAR_RUN_ID??crypto.randomUUID(),source=process.env.COAST_AVATAR_PARENT_DATABASE!;
if(!/^coast_audit_fix_actual_[a-f0-9]{32}$/.test(source)||!/^[a-f0-9-]{36}$/.test(runId))throw Error('Invalid clone/run guard.');
const base=new URL(process.env.DATABASE_URL!);
if(base.hostname!=='127.0.0.1'||base.port!=='55432'||base.pathname!=='/'+source)throw Error('Invalid clone server.');
const name='coast_audit_fix_actual_'+crypto.randomUUID().replaceAll('-',''),output='/private/tmp/coast-finalization-concurrency-attempt-'+runId+'.json',finalOutput=join(root,'docs/audits/2026-10-17-app-performance/candidates/admin-jellyfin-finalization/actual-concurrency.json');
const journalPath='/private/tmp/coast-avatar-copy-run-'+runId+'.json',data=await mkdtemp('/private/tmp/coast-avatar-commit-runtime-');
const journal:any={runId,createdAt:new Date().toISOString(),copyDatabase:name,sourceDatabase:source,phase:'prepared',createAcknowledged:false,copyAbsent:false,dropped:false};
const persist=()=>writeFile(journalPath,JSON.stringify(journal,null,2)+'\n',{mode:0o600});
await persist();base.pathname='/postgres';
const connect=(seconds=10)=>new Bun.SQL(base.href,{max:1,idleTimeout:0,connectionTimeout:seconds,connection:{statement_timeout:'60000',lock_timeout:'5000'}});
const admin=connect();let status=1,driverFailure:string|undefined;
try{
 const[active]=await admin`select count(*)::int as count from pg_stat_activity where datname=${source}`;
 if(Number(active.count))throw Error('source_clone_has_active_clients');
 journal.phase='creating';await persist();
 await admin.unsafe(`create database "${name}" template "${source}"`);journal.createAcknowledged=true;journal.phase='created';await persist();
 await admin.unsafe(`comment on database "${name}" is 'coast-avatar-copy:${runId}'`);
 const url=new URL(process.env.DATABASE_URL!);url.pathname='/'+name;
 const probe=join(root,'docs/audits/2026-10-17-app-performance/candidates/admin-jellyfin-finalization/bootstrap-concurrency.ts');journal.phase='probe_running';await persist();
 status=await Bun.spawn([process.execPath,'--tsconfig-override',join(root,'tsconfig.json'),probe,output],{cwd:root,env:{...process.env,DATABASE_URL:url.href,COAST_DATA_DIR:data,COAST_AUDIT_MATCHED_AVATAR_COPY:'1',COAST_AVATAR_RUN_ID:runId},stdout:'inherit',stderr:'inherit'}).exited;
 journal.phase='probe_terminal';journal.probeExit=status;await persist();
}catch(error){driverFailure=(error as any)?.code??(error instanceof Error&&/^[a-z_]+$/.test(error.message)?error.message:'private_driver_failure');}
finally{
 await admin.close().catch(()=>{});journal.phase='cleanup';await persist();
 for(let attempt=0;attempt<10&&!journal.copyAbsent;attempt++){
  const cleanup=connect(2);
  try{
   const[database]=await cleanup`select d.datname,shobj_description(d.oid,'pg_database')as marker from pg_database d where d.datname=${name}`;
   if(!database){journal.copyAbsent=true;break;}
   journal.markerVerified=database.marker===`coast-avatar-copy:${runId}`;
   if(database.marker&&database.marker!==`coast-avatar-copy:${runId}`){journal.cleanupFailure='ownership_marker_mismatch';break;}
   const[active]=await cleanup`select count(*)::int as count from pg_stat_activity where datname=${name}and backend_type='client backend'`;
   if(Number(active.count)){journal.cleanupFailure='owned_copy_has_live_client';break;}
   await cleanup.unsafe(`drop database "${name}"`);journal.dropped=true;journal.copyAbsent=true;
  }catch(error){journal.cleanupFailure=(error as any)?.code??'cleanup_connection_failure';}
  finally{await cleanup.close().catch(()=>{});}
  if(!journal.copyAbsent)await Bun.sleep(500);
 }
 await rm(data,{recursive:true,force:true});
 let report:any;
 try{report=JSON.parse(await readFile(output,'utf8'));if(report.runId!==runId)throw Error('wrong_run_receipt');}
 catch{report={runId,status:'failed',failureCode:driverFailure??'probe_did_not_emit_this_run_receipt'};}
 if(status!==0||driverFailure||!journal.copyAbsent){report.status='failed';status=1;}
 report.wrapperExit=status;report.driverFailure=driverFailure;report.matchedCopy={created:journal.createAcknowledged,dropped:journal.dropped,absent:journal.copyAbsent,exactRunMarker:journal.markerVerified===true,sourceDatabaseUntouched:true,privateFilesRemoved:true};
 journal.phase=journal.copyAbsent?'cleaned':'cleanup_blocked';journal.finalStatus=report.status;await persist();
 await writeFile(output,JSON.stringify(report,null,2)+'\n',{mode:0o600});await writeFile(finalOutput,JSON.stringify(report,null,2)+'\n',{mode:0o600});
 console.log(JSON.stringify({runId,status:report.status,copyAbsent:journal.copyAbsent,checks:report.checks?.length??0}));
}
process.exitCode=status;
