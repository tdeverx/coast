import {drizzle} from 'drizzle-orm/bun-sql';
import {getDb,getSql,closeDb} from '../../../../../src/lib/server/db';
import * as s from '../../../../../src/lib/server/db/schema';
import {jobExecution,JobYield} from '../../../../../src/lib/server/queue/execution';
import {enqueueSyncValueInTransaction} from '../../../../../src/lib/sync/changes.server';
import {JellyfinAdapter} from '../../../../../src/lib/providers/jellyfin/adapter.server';
import {instanceTransport} from '../../../../../src/lib/providers/instances.server';
import {getFeatureConfig} from '../../../../../src/lib/server/features';
import {featureValues} from '../../../../../src/lib/features';
import {createHash} from 'node:crypto';
import {readFile,writeFile} from 'node:fs/promises';
import {eq,and,sql as q} from 'drizzle-orm';
const root='/Users/admin/Documents/ChatGPT/coast-new',dir=import.meta.dir,runId=process.env.COAST_AVATAR_RUN_ID!,url=new URL(process.env.DATABASE_URL!);
if(process.env.COAST_AUDIT_MATCHED_AVATAR_COPY!=='1'||url.hostname!=='127.0.0.1'||url.port!=='55432'||!/^\/coast_audit_fix_actual_[a-f0-9]{32}$/.test(url.pathname))throw Error('Owned copy required');
const db=getDb(),sql=getSql(),hash=(x:any)=>createHash('sha256').update(typeof x==='string'?x:JSON.stringify(x)).digest('hex'),result:any={runId,status:'running',boundary:'Controlled actual-admin finalization on real catalogue/mappings, native extracted finalization/report/fences/checkpoint/enqueue, actual adapter identity trapped before invocation; no provider replies/delivery.',checks:{},comparisons:[],schedules:[],sourceHashes:{},externalCalls:0};
const check=(v:any,k:string)=>{result.checks[k]=!!v;if(!v)throw Error(k)};
const oldFetch=globalThis.fetch;globalThis.fetch=(async()=>{result.externalCalls++;throw Error('Network forbidden')})as any;
const originalTx=db.transaction.bind(db),session=(db as any).session,oldLogger=session.logger,oldOptionsLogger=session.options.logger;let ownerPid=0,beforeNativeIntentSelect:(()=>Promise<void>)|null=null;let peerClient:any,observer:any;let meter:any=null,transactionMeter:any=null,failInside=false,loseAfterCommit=false,afterCommitHook:(()=>Promise<void>)|null=null;
session.options.logger=session.logger={logQuery(text:string,params:any[]){if(meter){meter.ormStatements++;meter.maxParameters=Math.max(meter.maxParameters,params.length);if(transactionMeter)transactionMeter.statements++;if(text.startsWith('insert into "reconciliation_intents"'))meter.seedInsertStatements++;if(text.startsWith('insert into "outbox_actions"'))meter.outboxInsertStatements++;}}};
(db as any).transaction=async(fn:any)=>{const start=performance.now(),per={statements:0,sourceRows:0,intentRows:0};transactionMeter=per;const value=await originalTx(async tx=>{const ss=(tx as any).session,prepare=ss.prepareQuery.bind(ss);ss.prepareQuery=(...args:any[])=>{const query=prepare(...args),execute=query.execute.bind(query),text=args[0].sql;query.execute=async(...params:any[])=>{if(beforeNativeIntentSelect&&text.startsWith('select')&&text.includes('from "reconciliation_intents"')){const hook=beforeNativeIntentSelect;beforeNativeIntentSelect=null;await hook()}const rows=await execute(...params);if(meter&&Array.isArray(rows)){if(text.includes('from "tracking_state"')||text.includes('from "music_progress"'))per.sourceRows=Math.max(per.sourceRows,rows.length);if(text.includes('from "reconciliation_intents"'))per.intentRows=Math.max(per.intentRows,rows.length)}return rows};return query};await tx.execute(q`set local statement_timeout='5s'`);await tx.execute(q`set local lock_timeout='2s'`);ownerPid=(await tx.execute<any>(q`select pg_backend_pid() as pid`))[0].pid;const value=await fn(tx);if(failInside){failInside=false;throw Error('controlled-chunk-rollback')}return value});transactionMeter=null;if(meter){meter.transactions++;meter.maxTransactionStatements=Math.max(meter.maxTransactionStatements,per.statements);meter.maxSelectedSourceRows=Math.max(meter.maxSelectedSourceRows,per.sourceRows);meter.maxSelectedIntentRows=Math.max(meter.maxSelectedIntentRows,per.intentRows);meter.longestTransactionMs=Math.max(meter.longestTransactionMs,performance.now()-start)}if(loseAfterCommit){loseAfterCommit=false;throw Error('controlled-lost-ack')}if(afterCommitHook)await afterCommitHook();return value};
async function compile(source:string,base:string,name:string){const code=new Bun.Transpiler({loader:'ts'}).transformSync(source).replace(/(from\s*|import\s*\()(['"])([^'"]+)\2/g,(_m,prefix,_quote,p)=>prefix+JSON.stringify(p.startsWith('.')?new URL(p,base).pathname:p.startsWith('$lib/')?root+'/src/lib/'+p.slice(5):import.meta.resolve(p)));const path=process.env.COAST_DATA_DIR+'/'+name+'.js';await Bun.write(path,code);return import(path)}
const measure=()=>({ormStatements:0,seedInsertStatements:0,outboxInsertStatements:0,maxParameters:0,transactions:0,maxTransactionStatements:0,maxSelectedSourceRows:0,maxSelectedIntentRows:0,longestTransactionMs:0,committedCheckpoints:0,yields:0});
try{
 const[marker]=await sql`select shobj_description(oid,'pg_database') as marker from pg_database where datname=current_database()`;check(marker.marker==='coast-avatar-copy:'+runId,'owned-marker');
 const[admin]=await sql`select id from users where username='admin' and role='admin' and not disabled`;check(admin,'actual-admin');
 const[account]=await sql`select c.id from provider_connections c join provider_instances i on i.id=c.instance_id where c.user_id=${admin.id} and i.provider='jellyfin' order by c.id limit 1`;check(account,'actual-account');
 const[observed]=await sql`select (select count(*)::int from tracking_state where user_id=${admin.id} and(favourite or watched or position_seconds>0)) as screen,(select count(*)::int from music_progress where user_id=${admin.id}) as music,(select count(*)::int from reconciliation_intents where connection_id=${account.id}) as intents`;result.actualBeforeControlledState=observed;
 await sql`create temporary table pj07_screen as select distinct a.media_id as id from availability a join works w on w.id=a.media_id where a.connection_id=${account.id} and w.category='screen' order by id limit 650`;
 await sql`create temporary table pj07_unmapped as select w.id from works w where w.category='screen' and w.kind='movie' and not exists(select 1 from availability a where a.connection_id=${account.id} and a.media_id=w.id) order by w.id limit 1`;
 await sql`create temporary table pj07_music as select distinct a.media_id as id from availability a join music_works w on w.id=a.media_id where a.connection_id=${account.id} and w.kind='track' order by id limit 121`;
 const[selection]=await sql`select(select count(*)::int from pj07_screen) as screen,(select count(*)::int from pj07_unmapped) as unmapped,(select count(*)::int from pj07_music) as music`;check(selection.screen===650&&selection.unmapped===1&&selection.music===121,'finite-real-catalogue-mapped-unmapped-selection');result.controlledCardinality=selection;
 const[held]=await sql`select id from pj07_screen order by id offset 50 limit 1`;const[sameValueTarget]=await sql`select id from pj07_screen order by id limit 1`;
 await sql`create temporary table pj07_availability as select id,state,verified_at,scan_id from availability where connection_id=${account.id}`;
 const[job]=await sql`select id,attempts from outbox_actions where user_id=${admin.id} and kind='jellyfin.sync' order by created_at limit 1`;check(job,'actual-admin-scan-job');let attempt=Number(job.attempts)+1;
 const scanId=crypto.randomUUID(),resetId=crypto.randomUUID(),startedAt=new Date().toISOString();
 const modules:any={},schemas:any={},full:any={};
 for(const version of ['default','candidate']){
  const source=await readFile(dir+'/jellyfin.'+(version==='default'?'before':'candidate')+'.ts.txt','utf8'),progress=await readFile(dir+'/progress.'+(version==='default'?'before':'candidate')+'.ts.txt','utf8');result.sourceHashes[version+'Importer']=hash(source);result.sourceHashes[version+'Progress']=hash(progress);
  schemas[version]=await compile(progress,new URL('../../../../../src/lib/sync/jellyfin-progress.ts',import.meta.url).href,'progress-'+version);
  const report=source.slice(source.indexOf('  async function report('),source.indexOf('  // Mark traversal',source.indexOf('  async function report(')));
  const ensure=source.slice(source.indexOf('  async function ensureConnected('),source.indexOf('  let importPlayback =',source.indexOf('  async function ensureConnected(')));
  const start=version==='default'?source.indexOf("  await report(processed, total, 'finalizing'"):source.indexOf('  let finalizationPhase=');const end=source.indexOf('\n}\n\nexport async function executeJellyfinUserState',start);check(start>0&&end>start,version+'-native-finalization-extraction');
  const imports=`import {getDb} from '${root}/src/lib/server/db';import {getFeatureConfig} from '${root}/src/lib/server/features';import {featureValues} from '${root}/src/lib/features';import {defaultConfig} from '${root}/src/lib/server/config';import {jobCheckpoint,assertJobLease,JobYield} from '${root}/src/lib/server/queue/execution';import {PermanentActionError} from '${root}/src/lib/server/queue';import {enqueueInTransaction} from '${root}/src/lib/sync/changes.server';import * as schema from '${root}/src/lib/server/db/schema';import {and,eq,isNull,ne,or,sql,desc,asc,inArray,lte} from 'drizzle-orm';const {availability,providerItems,syncCheckpoints,providerConnections,trackingState,outboxActions,providerInstances,media,users,works,musicProgress,reconciliationIntents,syncValues}=schema;`;
  const code=imports+`export async function run(context){const {userId,connectionId,connection,instance,scanId,startedAt,resetId,resume,featureConfig}=context;const db=getDb(),scope='user',kind='jellyfin-user',userScope=true,changes=undefined,progressKey='userSync',full=true,count=0;let phase=resume?.phase??'finalizing',processed=0,total=null;const onStage=()=>{};const signatureOf=(values)=>['screen','music','book','comic'].map(key=>Number(values[key])).join('');const featureSignature=signatureOf(featureConfig.features);${report}${ensure}${source.slice(start,end)}\n}`;
  modules[version]=await compile(code,new URL('../../../../../src/lib/sync/jellyfin.server.ts',import.meta.url).href,'finalization-'+version);
  full[version]=await compile(source,new URL('../../../../../src/lib/sync/jellyfin.server.ts',import.meta.url).href,'full-importer-'+version);
 }
 async function rawContext(version:string,overrides:any={}){const[current]=await db.select({connection:s.providerConnections,instance:s.providerInstances}).from(s.providerConnections).innerJoin(s.providerInstances,eq(s.providerInstances.id,s.providerConnections.instanceId)).where(eq(s.providerConnections.id,account.id));const featureConfig=await getFeatureConfig(admin.id,sql);const parse=schemas[version].jellyfinScanProgressSchema;const v=await import('valibot');const resume=v.parse(parse,current.connection.settings.userSync);return{userId:admin.id,connectionId:account.id,...current,scanId,startedAt,resetId,resume,featureConfig,...overrides}}
 async function reset(){
  await sql`delete from tracking_state where user_id=${admin.id}`;await sql`delete from music_progress where user_id=${admin.id}`;
  await sql`insert into tracking_state(user_id,media_id,watched,play_count) select ${admin.id}::uuid,id,true,1 from pj07_screen where id<>${held.id}::uuid union all select ${admin.id}::uuid,id,true,1 from pj07_unmapped`;
  await sql`insert into music_progress(user_id,track_id,play_count,position_seconds) select ${admin.id}::uuid,id,2,0 from pj07_music`;
  await sql`delete from reconciliation_intents where connection_id=${account.id}`;
  await sql`delete from outbox_actions where connection_id=${account.id} and kind in('jellyfin.reconcile','jellyfin.user-state')`;
  await sql`update availability a set state=b.state,verified_at=b.verified_at,scan_id=b.scan_id from pj07_availability b where a.id=b.id`;
  await sql`update availability set scan_id=${scanId},state='available',verified_at=${startedAt}::timestamptz where connection_id=${account.id} and media_id in(select id from pj07_screen union all select id from pj07_music)`;
  const progress={processed:0,total:null,startedAt,scanId,phase:'finalizing',accountGeneration:null,resetId,stageProcessed:0,stageTotal:null};
  await sql`update provider_connections set status='connected',settings=settings||jsonb_build_object('reconcileTracking',true,'userSyncResetId',${resetId}::text,'userSync',${progress}::jsonb||jsonb_build_object('accountGeneration',account_generation)) where id=${account.id}`;
  await sql`insert into sync_checkpoints(connection_id,kind,scan_id,cursor,completed_at) values(${account.id},'jellyfin-user',${scanId},'0',null) on conflict(connection_id,kind)do update set scan_id=excluded.scan_id,cursor='0',completed_at=null`;
  await sql`update outbox_actions set state='running',attempts=${attempt},kind='jellyfin.sync',compaction_key=null,payload='{}'::jsonb where id=${job.id}`;
 }
 const state=async()=>{
  const intents=await sql`select work_id,category,value,version from reconciliation_intents where connection_id=${account.id} order by work_id,category`;
  const pending=await sql`select kind,compaction_key,payload from outbox_actions where connection_id=${account.id} and kind in('jellyfin.reconcile','jellyfin.user-state') and state='pending' order by compaction_key`;
  const[a]=await sql`select count(*)::int as total,count(*)filter(where state='unavailable')::int as unavailable from availability where connection_id=${account.id}`;
  const[c]=await sql`select scan_id,cursor,completed_at from sync_checkpoints where connection_id=${account.id} and kind='jellyfin-user'`;
  const[p]=await sql`select settings->'userSync' as progress from provider_connections where id=${account.id}`;
  return{intents,pending,availability:a,checkpoint:c,progress:p.progress};
 };
 const normalized=(v:any)=>({intents:v.intents.map(i=>({work:i.work_id,category:i.category,value:i.value})),pending:v.pending.map(j=>({kind:j.kind,key:j.compaction_key,payload:{...j.payload,intentVersion:undefined}})),availability:v.availability,completed:!!v.checkpoint.completed_at,clearedScan:v.checkpoint.scan_id===null,phase:v.progress.phase});
 async function assertCurrentJobs(v:any,label:string){check(v.pending.filter(j=>j.kind==='jellyfin.reconcile').every(j=>v.intents.some(i=>i.work_id===j.payload.mediaId&&i.category===(j.payload.field==='watched'?'history':j.payload.field)&&i.version===j.payload.intentVersion)),label+'-pending-backfill-current-version');check(new Set(v.pending.filter(j=>j.kind==='jellyfin.reconcile').map(j=>j.compaction_key)).size===v.pending.filter(j=>j.kind==='jellyfin.reconcile').length,label+'-one-pending-backfill-per-intent')}
 async function runAttempt(version:string,ctx?:any){const execution={id:job.id,attempts:attempt,purpose:'scheduled' as const,started:performance.now(),checkpoints:0,userId:admin.id,kind:'jellyfin.sync',payload:{}};try{await jobExecution.run(execution,()=>modules[version].run(ctx??rawContext(version)))}finally{if(meter)meter.committedCheckpoints+=execution.checkpoints}}
 // rawContext is asynchronous; keep native invocation input fully resolved.
 async function invoke(version:string,ctx?:any){return runAttempt(version,ctx??await rawContext(version))}

 peerClient=new Bun.SQL(process.env.DATABASE_URL!,{max:1,idleTimeout:0,connectionTimeout:5,connection:{jit:'off'}});observer=new Bun.SQL(process.env.DATABASE_URL!,{max:1,idleTimeout:0,connectionTimeout:5});const peerDb=drizzle({client:peerClient,schema:s});
 function latch(){let release!:()=>void;return{promise:new Promise<void>(r=>release=r),release}}
 const error=(e:any)=>({message:String(e?.cause?.message??e?.message??e).split('\n')[0],code:e?.cause?.code??e?.code,errno:e?.cause?.errno??e?.errno});
 for(const version of ['candidate','default']){
  await reset();await sql`delete from tracking_state where user_id=${admin.id}`;await sql`delete from music_progress where user_id=${admin.id}`;
  await sql`insert into tracking_state(user_id,media_id,watched,play_count)values(${admin.id},${sameValueTarget.id},true,1)`;
  await sql`insert into reconciliation_intents(connection_id,work_id,category,value)values(${account.id},${sameValueTarget.id},'history','{"value":true}'::jsonb)`;
  if(version==='candidate')await sql`update provider_connections set settings=jsonb_set(settings,'{userSync}',settings->'userSync'||'{"finalizationPhase":"enqueue","finalizationCursor":null,"finalizationCategory":null}'::jsonb)where id=${account.id}`;
  const entered=latch(),release=latch(),peerAtOutbox=latch();let peerPid=0;
  beforeNativeIntentSelect=async()=>{entered.release();await release.promise};
  const primary=invoke(version).then(()=>({ok:true}),e=>({ok:false,error:error(e)}));
  await Promise.race([entered.promise,Bun.sleep(6000).then(()=>{throw Error('primary-native-intent-select-not-reached')})]);
  const peer=peerDb.transaction(async tx=>{
   await tx.execute(q`set local statement_timeout='5s'`);await tx.execute(q`set local lock_timeout='2s'`);peerPid=(await tx.execute<any>(q`select pg_backend_pid() as pid`))[0].pid;
   const ss=(tx as any).session;ss.logger={logQuery(text:string){if(text.startsWith('insert into "outbox_actions"'))peerAtOutbox.release()}};
   await enqueueSyncValueInTransaction(tx,admin.id,sameValueTarget.id,'history',{value:true});
  }).then(()=>({ok:true}),e=>({ok:false,error:error(e)}));
  try{
   await Promise.race([peerAtOutbox.promise,Bun.sleep(6000).then(()=>{throw Error('peer-native-outbox-not-reached')})]);
   let blocking=false;for(let poll=0;poll<40;poll++){const[row]=await observer`select ${ownerPid}=any(pg_blocking_pids(${peerPid}))as blocked`;if(row.blocked){blocking=true;break}await Bun.sleep(10)}
   check(ownerPid!==peerPid,version+'-distinct-native-write-sessions');check(blocking,version+'-native-manual-waits-on-owner-before-release');
   release.release();const[primaryResult,peerResult]=await Promise.all([primary,peer]);
   const v=await state();const outcome={scenario:'overlapping-native-manual-edit-and-enqueue-page',version,peerBlockedByOwnerBeforeRelease:blocking,primary:primaryResult,peer:peerResult,pendingJobs:v.pending.length,intents:v.intents.length,progressPhase:v.progress.phase};result.schedules.push(outcome);await writeFile(process.argv[2],JSON.stringify(result,null,2));
  }finally{release.release();beforeNativeIntentSelect=null;await Promise.allSettled([primary,peer])}
 }
 result.assessment='Finite overlap results retained; compare candidate/default failures before adoption. No alternate lock architecture implemented.';
 check(result.externalCalls===0,'zero-network-and-provider-delivery');result.status='measured-concurrency';result.limits='No provider replies/delivery or queue-worker lane lifecycle executed. Version admission rejects obsolete/missing backfill before identity; an edit after admission and before remote write remains an unavoidable in-flight race without provider fencing. Local pending rows do not prove exactly-once remote delivery.';
}catch(e:any){result.status='failed';result.failure={message:String(e.message).split('\nparams:')[0],cause:e.cause?.message,code:e.cause?.code??e.code};process.exitCode=1}
finally{await peerClient?.close().catch(()=>{});await observer?.close().catch(()=>{});meter=null;(db as any).transaction=originalTx;session.options.logger=oldOptionsLogger;session.logger=oldLogger;globalThis.fetch=oldFetch;await writeFile(process.argv[2],JSON.stringify(result,null,2));await closeDb()}
