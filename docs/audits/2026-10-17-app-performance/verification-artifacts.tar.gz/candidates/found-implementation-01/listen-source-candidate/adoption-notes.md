# Existing Listen leads — bounded safe-fix preparation

**Private, unadopted, unexecuted.** This is preparation for the user's instruction to finish already-known safe shared fixes and move unchecked areas to a separate roadmap. It performs no new audit, runtime/DB/provider/browser execution, test or repository edit. Only the previously identified Listen leads are considered.

## Candidate: final page-count metadata from final observations

The one-line patch changes only `musicBrowseData`'s returned `pages`:

```diff
-    pages: Math.max(page, pages),
+    pages: Math.max(page, ...results.map((result) => Math.ceil(result.total / 50))),
```

The function initially reads requested page R and calculates P from those source totals. If R>P and no initial source failed, it browses page P again. Items/total/failure then come from the second source observations, but the old return uses the first P. The candidate calculates the displayed upper page bound from those same final source observations, with the existing current-page floor. It benefits both ordinary Library Listen and dedicated Music because both call this owner. It adds no provider/DB requests, persistence operations, source reorder, new helper/dependency or client change.

**Exact retained contract.** `page` is always a positive integer: requested page is validated, and initial P is at least1. With no re-browse, `results` is the original collection, and `max(page, 1, source page counts)` equals `max(page, source page counts)`. Thus all first-pass success, empty and partial/error behavior is unchanged. A static clamp re-browse also returns the same metadata. If final source page counts grow beyond the initial clamped page, the new upper bound reflects that growth instead of keeping the old ceiling. If they shrink, `max(page, ...)` preserves the existing floor and behavior. Each selected source has one result; no-result arrays still produce `pages=page`.

This is a **final-observation metadata correction**, not a complete solution to changing remote catalogues. Further shrink during the clamp re-browse can still leave the already-observed page beyond the newest total. Repeated clamping, retry/deadline policy or a stable remote snapshot is not included. Do not mark general pagination instability resolved or claim the natural race was reproduced.

### Minimal adoption requirements

- Root reviews the exact preimage SHA `ffbe941015a8bf0c8d77e2db12111b01a5b8b13c09f8206fbc4e9ef18ae08c46` and one-line patch, and checks current source drift before adoption.
- Typecheck/build with the current installed dependencies. No synthetic provider fixture or new mirrored test is proposed.
- Use the already-authorized normal signed-in ordinary Listen cohort for a bounded regression check: unchanged actual first page and a last/beyond-end request derived from observed pagination, plus existing partial/error behavior only if naturally encountered. Root must account for ordinary browse observations/writes as it already planned. Compare the same visible owner/filter/identity/page/total/failure semantics; do not transfer saved Collection evidence.
- Record algebraic equivalence above separately from actual runtime verification. If final-observation growth is not naturally observed, mark that specific dynamic race unverified; do not construct fake provider responses and call them actual data.
- Keep the remaining remote-snapshot/shrink/resource/provider-generation acceptance on the new unchecked-area roadmap. Common gates are regression evidence, not proof that this natural race occurred.

## Short nonfinal source pages: no equally contract-preserving fix

The existing validator accepts a nonempty source page shorter than its requested limit even when more records are advertised. The adapter's `nextOffset` follows actual length; ordinary `musicBrowseData` ignores it and computes each numbered page's start as `(page-1)*50`. That is the existing source-proven conditional coverage concern; this preparation adds no runtime evidence.

There is **no short-page patch in this package**. Rejecting accepted short nonfinal pages would replace usable data with source failure, changing the current partial/error contract. Tightening the shared Jellyfin validator would also affect callers that correctly use actual-length traversal, including previews/scans, rather than just the fixed numbered browse. Filling a page until50 results/end would add potentially many remote reads and ordinary observation writes, with new duplicate/order/cancellation/timeout/resource and failure semantics. Reducing numbered offsets from actual length requires cursor/checkpoint ownership; a later arbitrary page cannot derive all previous lengths from its current input alone.

These options require a concrete failure/read-budget choice and actual-provider evidence before adoption. Do not add filling, cursor state or a generic strict-validator flag merely to finish this pass. Put this known conditional contract concern and its missing natural short-page cohort on the deferred roadmap; it is not silently fixed by the metadata correction.

## Deterministic source ordering: explicit decision, deferred

`listProviders` currently reads instances without ORDER BY, and music browsing preserves that result's source-block order. A particular repeated observed order is not a specified contract. Choosing ID, name or creation time would establish a new visible ordering; adding ORDER BY to the shared provider listing would also reorder other consumers. None is uniquely implied by the existing source.

Treat this as an existing undefined-behavior/policy decision for the roadmap, **not a safe root-only incidental fix**. No sort or production candidate is included. If later selected, bind the order explicitly and verify multi-source page blocks/identities in the intended UI, without claiming that source-ID order preserves a prior user preference.

## Scope and reproducibility

`music.before.ts.txt` is the exact source preimage; `music.final-page-metadata.ts.txt` is derived by the single replacement above; `final-page-metadata.patch` targets only `src/lib/server/queries/music.ts`. `manifest.json` records their hashes and the already-reviewed related sources. No source generator/framework or additional test harness is necessary for a one-line candidate. Root owns subsequent adoption and bounded verification. Previous runtime coverage proposal remains historical preparation at `/private/tmp/coast-listen-runtime-coverage-next.md`.
