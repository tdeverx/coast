import fcntl,subprocess,os
with open('/private/tmp/coast-actual-clone-execution.lock','a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 r=subprocess.run(['python3','/private/tmp/coast-fixes-run.py','/private/tmp/coast-found-list-check.ts','/Users/admin/Documents/ChatGPT/coast-new/docs/audits/2026-10-17-app-performance/evidence/implementation-found-lists-actual.json'],env={**os.environ,'COAST_AUDIT_LIST_LEASE':'1'})
 raise SystemExit(r.returncode)
