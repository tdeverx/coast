import {createHash} from 'node:crypto';
import {resolve} from 'node:path';
const root='/Users/admin/Documents/ChatGPT/coast-new',output=process.argv[2];
const hash=(text:string)=>createHash('sha256').update(text).digest('hex');
const assert=(value:unknown,message:string)=>{if(!value)throw Error(message)};
const key=Symbol.for('coast.database.pool'),g=globalThis as any,old=g[key];
const report:any={status:'running',scope:'Actual existing catalogue and user identities, read-only empty-list/header and SQL planning checks. No fabricated lists/items. Positive mutation/ordering remains unverified until a real list exists.',plans:[],cases:[]};
let pool:Bun.SQL|undefined,c:any,tx=false;
try {
 const clone=(await Bun.file('/private/tmp/coast-app-fixes-clone-name').text()).trim(),url=new URL(process.env.DATABASE_URL!);
 assert(process.env.COAST_AUDIT_REAL_DATA_CLONE==='1'&&/^coast_audit_fix_actual_[a-f0-9]{32}$/.test(clone)&&url.hostname==='127.0.0.1'&&url.port==='55432'&&url.pathname==='/'+clone,'actual_clone_only');
 assert(process.env.COAST_AUDIT_LIST_LEASE==='1','exclusive_parent_lease');
 const paths=['src/lib/core/lists/service.server.ts','src/lib/server/api/lists.server.ts'];report.sourceBefore=Object.fromEntries(await Promise.all(paths.map(async p=>[p,hash(await Bun.file(root+'/'+p).text())])));
 pool=new Bun.SQL(url.href,{max:1,idleTimeout:0,connection:{jit:'off',statement_timeout:'30000',lock_timeout:'1000'}});c=await pool.reserve();await c`BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY`;tx=true;
 const[s]=await c`select current_setting('transaction_read_only') as read_only,current_setting('transaction_isolation') as isolation,current_setting('statement_timeout') as statement_timeout,current_setting('lock_timeout') as lock_timeout,current_setting('jit') as jit`;
 assert(s.read_only==='on'&&s.isolation==='repeatable read'&&s.statement_timeout==='30s'&&s.lock_timeout==='1s'&&s.jit==='off','session_settings');report.session=s;
 const[count]=await c`select (select count(*)::int from lists) as lists,(select count(*)::int from list_items) as items`;
 assert(count.lists===0&&count.items===0,'natural_list_cohort_changed_review_before_continuing');report.actualCensus=count;
 const owners=await c`select id from users where not disabled order by id`,works=await c`select id from works order by id limit 64`;assert(owners.length>0&&works.length===64,'actual_inputs');
 g[key]=c;const{getListHeader,getList,getLists}=await import(root+'/src/lib/core/lists/service.server.ts');
 for(const actor of owners){assert((await getLists(actor.id)).length===0,'actual_empty_lists');for(const[name,fn]of [['header',getListHeader],['full',getList]]as const){let caught=false;try{await fn(actor.id,works[0].id);}catch(e:any){assert(e.code==='not_found'&&e.status===404,'exact_existing_404');caught=true;}assert(caught,'absent_list_rejected');report.cases.push({ownerOrdinal:report.cases.length/2|0,read:name,notFound404:true});}}
 const{sql}=await import(root+'/node_modules/drizzle-orm/index.js');const{PgDialect}=await import(root+'/node_modules/drizzle-orm/pg-core/dialect.js');const {listItems}=await import(root+'/src/lib/server/db/schema.ts');const dialect=new PgDialect();
 const source=await Bun.file(root+'/src/lib/core/lists/service.server.ts').text();const remove=source.match(/await tx\.execute\(sql`(with positions as \([\s\S]*?positions\.position)`\);/);const reorder=source.match(/await tx\.execute\(sql`(update \$\{listItems\} as target[\s\S]*?ordinal - 1\)::int)`\);/);assert(remove&&reorder,'exact_native_mutation_templates');
 for(const[label,template]of [['compact',remove![1]],['reorder',reorder![1]]]as const){const fragment=new Function('sql','listItems','listId','entryIds','return sql`'+template+'`;')(sql,listItems,works[0].id,Array.from(works,(w:any)=>w.id));const q=dialect.sqlToQuery(fragment);const result=await c.unsafe('EXPLAIN (FORMAT JSON) '+q.sql,q.params);assert(result.length===1,'native_plan');report.plans.push({label,querySha256:hash(q.sql),parameterHash:hash(JSON.stringify(q.params)),parameters:q.params.length,node:result[0]['QUERY PLAN'][0].Plan['Node Type'],noAnalyzeNoMutation:true});}
 const[after]=await c`select (select count(*)::int from lists) as lists,(select count(*)::int from list_items) as items`;assert(after.lists===0&&after.items===0,'no_data_changed');await c`ROLLBACK`;tx=false;report.rolledBack=true;report.status='passed_actual_empty_list_header_and_native_plan_checks_positive_mutation_gap';
} catch(e:any){report.status='failed';report.failure=/^[a-z0-9_]+$/.test(e.message)?e.message:'private_diagnostic_only';process.exitCode=1;}
finally{g[key]=old;if(tx)try{await c`ROLLBACK`;report.failureRolledBack=true;}catch{report.rollbackFailed=true;process.exitCode=1;}try{c?.release();report.released=true;}catch{process.exitCode=1;}try{await pool?.close();report.poolClosed=true;}catch{process.exitCode=1;}
 const paths=['src/lib/core/lists/service.server.ts','src/lib/server/api/lists.server.ts'];report.sourceAfter=Object.fromEntries(await Promise.all(paths.map(async p=>[p,hash(await Bun.file(root+'/'+p).text())])));report.sourceUnchanged=JSON.stringify(report.sourceBefore)===JSON.stringify(report.sourceAfter);if(!report.sourceUnchanged)process.exitCode=1;await Bun.write(output,JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({status:report.status,failure:report.failure,cases:report.cases.length,plans:report.plans.length,poolClosed:report.poolClosed}));}
