import subprocess, os, json, pathlib, urllib.parse, tempfile, sys
root = pathlib.Path('/Users/admin/Documents/ChatGPT/coast-new')
name = pathlib.Path('/private/tmp/coast-app-fixes-clone-name').read_text().strip()
assert name.startswith('coast_audit_fix_actual_')
info = json.loads(subprocess.check_output(['container','inspect','coast-new-test-db']))[0]
settings = dict(value.split('=',1) for value in info['configuration']['initProcess']['environment'] if '=' in value)
url = 'postgresql://' + urllib.parse.quote(settings['POSTGRES_USER'],safe='') + ':' + urllib.parse.quote(settings['POSTGRES_PASSWORD'],safe='') + '@127.0.0.1:55432/' + name
private = tempfile.mkdtemp(prefix='coast-fixes-actual-runtime-')
os.chmod(private,0o700)
env = {**os.environ,'DATABASE_URL':url,'COAST_DATA_DIR':private,'COAST_AUDIT_REAL_DATA_CLONE':'1','COAST_AUDIT_EXPLAIN':'1','PGOPTIONS':'-c statement_timeout=30000 -c lock_timeout=5000'}
script = pathlib.Path(sys.argv[1]).resolve()
output = pathlib.Path(sys.argv[2]).resolve()
log = pathlib.Path('/private/tmp/coast-fixes-'+script.stem+'.log')
with log.open('w') as stream:
    result = subprocess.run([str(root/'.tools/bun-1.4.3/bun-darwin-aarch64/bun'),'--tsconfig-override',str(root/'tsconfig.json'),str(script),str(output)],cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT)
print(json.dumps({'probe':script.name,'exit':result.returncode,'evidencePresent':output.exists(),'privateLog':str(log)}))
sys.exit(result.returncode)
